from __future__ import annotations

from typing import Any, Optional

import torch

from modules.pipeline.conditioning_utils import resolve_step_conditioning
from modules.pipeline.sampler_trace_mixin import SamplerTraceMixin

from modules.contracts import SamplerCapabilities, SamplerOutput


meta = {
    "name": "dpmpp_2m",
    "label": "DPM++ 2M",
    "description": "Pipeline-facing DPM++ 2M-style deterministic sampler for standard fixed-step schedules.",
    "config_key": "shared",
}

required_args = {
    "guided_model_fn": "callable",
    "latents": "torch.Tensor",
    "schedule": "SchedulerOutput-like object with sigmas",
    "conditioning": "ConditioningOutput-like object with cond/uncond",
    "request": "request object with steps/cfg_scale",
}

optional_args = {
    "state": "shared pipeline state",
}


class DPMPlusPlus2MSampler(SamplerTraceMixin):
    """
    Standard sampler implementation.

    Design goals:
    - uses pipeline-owned CFG via guided_model_fn(...)
    - supports stepwise conditioning through conditioning_utils
    - assumes schedule is already compatible with a standard sampler
    - does not interpret KES-specific tail/expansion semantics on its own
    """

    SAMPLER_NAME = "dpmpp_2m"

    SAMPLER_CAPABILITIES = SamplerCapabilities(
        sampler_name=SAMPLER_NAME,
        guidance_owner="pipeline",
        uses_raw_model_fn=False,
        uses_guided_model_fn=True,
        supports_step_expansion=False,
        supports_tail_metadata=False,
        requires_requested_step_schedule=True,
        strict_validation=True,
        forced_pipeline_mode="fixed_steps",
    )
    SAMPLER_SCHEDULE_CAPABILITIES = SAMPLER_CAPABILITIES

    @staticmethod
    def _resolve_solver_dtype(request: Any, latent_dtype: torch.dtype) -> torch.dtype:
        sampler_kwargs = dict(getattr(request, "sampler_kwargs", {}) or {})
        selected = str(sampler_kwargs.get("solver_dtype", "latent")).strip().lower()
        aliases = {
            "latent": latent_dtype,
            "model": latent_dtype,
            "input": latent_dtype,
            "float16": torch.float16,
            "fp16": torch.float16,
            "float32": torch.float32,
            "fp32": torch.float32,
        }
        if selected not in aliases:
            raise ValueError(
                "DPM++ 2M sampler_kwargs.solver_dtype must be one of: "
                "latent, float16, or float32."
            )
        return aliases[selected]

    @staticmethod
    def _scalar(value: Any) -> float | None:
        if value is None:
            return None
        try:
            if hasattr(value, "detach"):
                value = value.detach()
            if hasattr(value, "cpu"):
                value = value.cpu()
            if hasattr(value, "item"):
                value = value.item()
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _tensor_trace_stats(value: torch.Tensor) -> dict[str, float]:
        finite = value.detach().to(device="cpu", dtype=torch.float32)
        return {
            "min": float(finite.min().item()),
            "max": float(finite.max().item()),
            "mean": float(finite.mean().item()),
            "std": float(finite.std(unbiased=False).item()),
            "norm": float(torch.linalg.vector_norm(finite).item()),
        }

    def _coefficient_trace(
        self,
        *,
        sigma: torch.Tensor,
        sigma_next: torch.Tensor,
        previous_t: Optional[torch.Tensor],
    ) -> dict[str, float | None]:
        if float(sigma_next.detach().cpu()) <= 0.0:
            return {"t": None, "t_next": None, "h": None, "h_last": None, "r": None}
        t = self._sigma_to_t(sigma)
        t_next = self._sigma_to_t(sigma_next)
        h = t_next - t
        h_last = None
        r = None
        if previous_t is not None:
            h_last_tensor = t - previous_t.to(device=t.device, dtype=t.dtype)
            r_tensor = h_last_tensor / torch.clamp(h, min=torch.finfo(t.dtype).eps)
            r_tensor = torch.clamp(r_tensor, min=torch.finfo(t.dtype).eps)
            h_last = self._scalar(h_last_tensor)
            r = self._scalar(r_tensor)
        return {
            "t": self._scalar(t),
            "t_next": self._scalar(t_next),
            "h": self._scalar(h),
            "h_last": h_last,
            "r": r,
        }

    def sample(
        self,
        raw_model_fn,   # accepted for contract consistency; unused here
        guided_model_fn,
        latents: torch.Tensor,
        schedule,
        conditioning,
        request,
        state: Optional[Any] = None,
    ) -> SamplerOutput:
        if latents is None:
            raise ValueError("DPMPlusPlus2MSampler.sample requires `latents`.")

        model_input_dtype = latents.dtype
        solver_dtype = self._resolve_solver_dtype(request, model_input_dtype)
        x = latents.to(dtype=solver_dtype)
        sigmas = self._materialize_sigmas(schedule, x)
        timesteps = self._materialize_timesteps(schedule, x)
        if sigmas.numel() < 2:
            raise ValueError("DPMPlusPlus2MSampler.sample requires at least 2 sigma values.")
        
        cfg_scale = float(getattr(request, "cfg_scale", 1.0))

        old_denoised = None
        previous_t = None
        stepwise_conditioning_used = False
        trace_recorder = self._get_trace_recorder(request)
        trace_enabled = bool(
            trace_recorder is not None and getattr(trace_recorder, "enabled", False)
        )

        requested_steps, effective_steps = self._resolve_effective_steps(
            request=request,
            schedule=schedule,
            sigmas=sigmas,
        )

        for i in range(sigmas.numel() - 1):
            sigma = sigmas[i]
            sigma_next = sigmas[i + 1]
            timestep = timesteps[i]

            latent_before = x.detach()
            model_x = x.to(dtype=model_input_dtype)
            
            cond, uncond = resolve_step_conditioning(
                conditioning=conditioning,
                step_index=i,
                latents=model_x,
                state=state,
            )

            if i == 0:
                conditioning_extra = getattr(conditioning, "extra", {}) or {}
                resolver = conditioning_extra.get("resolver")
                stepwise_conditioning_used = resolver is not None

            guided_epsilon_model = guided_model_fn(
                model_x,
                sigma,
                timestep,
                cond,
                uncond,
                cfg_scale,
            )
            guided_epsilon = guided_epsilon_model.to(dtype=solver_dtype)
            denoised = x - sigma * guided_epsilon

            trace_extra = {
                "integration_mode": self.SAMPLER_NAME,
                "used_old_denoised": old_denoised is not None,
                "model_input_dtype": str(model_input_dtype),
                "solver_dtype": str(solver_dtype),
                "timestep": self._scalar(timestep),
            }
            if trace_enabled:
                trace_extra.update(
                    {
                        "epsilon": self._tensor_trace_stats(guided_epsilon),
                        "denoised": self._tensor_trace_stats(denoised),
                        **self._coefficient_trace(
                            sigma=sigma,
                            sigma_next=sigma_next,
                            previous_t=previous_t,
                        ),
                    }
                )

            x = self._dpmpp_2m_update(
                x=x,
                denoised=denoised,
                old_denoised=old_denoised,
                previous_t=previous_t,
                sigma=sigma,
                sigma_next=sigma_next,
            )
            self._trace_step(
                request,
                step_index=i,
                sigma=sigma,
                sigma_next=sigma_next,
                latent_before=latent_before,
                latent_after=x,
                noise_pred=guided_epsilon,
                guided_noise=guided_epsilon,
                cfg_scale=cfg_scale,
                extra=trace_extra,
            )

            old_denoised = denoised
            previous_t = self._sigma_to_t(sigma)
       
        self._trace_sampler_summary(
            request,
            requested_steps=requested_steps,
            effective_steps=effective_steps,
        )
        
        
        return SamplerOutput(
            latents=x.to(dtype=model_input_dtype),
            extra={
                "sampler_name": self.SAMPLER_NAME,
                
                "requested_steps": requested_steps,
                "effective_steps": effective_steps,
                "scheduler_step_override_applied": effective_steps != requested_steps,
                "integration_mode_used": self.SAMPLER_NAME,
                "model_prediction_type": "epsilon",
                "integration_prediction_type": "denoised",
                "schedule_transitions": int(sigmas.numel() - 1),
                "stepwise_conditioning_used": stepwise_conditioning_used,
                "model_input_dtype": str(model_input_dtype),
                "solver_dtype": str(solver_dtype),
                "solver_state_return_dtype": str(model_input_dtype),
                
            },
        )

    
    def _sigma_to_t(self, sigma: torch.Tensor) -> torch.Tensor:
        sigma = torch.clamp(sigma, min=1e-12)
        return sigma.log().neg()

    def _dpmpp_2m_update(
        self,
        x: torch.Tensor,
        denoised: torch.Tensor,
        old_denoised: Optional[torch.Tensor],
        previous_t: Optional[torch.Tensor],
        sigma: torch.Tensor,
        sigma_next: torch.Tensor,
    ) -> torch.Tensor:
        """Apply the deterministic DPM++ 2M update in denoised space."""
        sigma_val = torch.as_tensor(sigma, device=x.device, dtype=x.dtype)
        sigma_next_val = torch.as_tensor(sigma_next, device=x.device, dtype=x.dtype)

        if float(sigma_next_val.detach().cpu()) <= 0.0:
            return denoised

        t = self._sigma_to_t(sigma_val)
        t_next = self._sigma_to_t(sigma_next_val)
        h = t_next - t

        if old_denoised is None or previous_t is None:
            denoised_d = denoised
        else:
            h_last = t - previous_t.to(device=x.device, dtype=x.dtype)
            r = h_last / torch.clamp(h, min=torch.finfo(x.dtype).eps)
            r = torch.clamp(r, min=torch.finfo(x.dtype).eps)
            denoised_d = (
                (1.0 + 1.0 / (2.0 * r)) * denoised
                - (1.0 / (2.0 * r)) * old_denoised
            )

        sigma_ratio = sigma_next_val / torch.clamp(
            sigma_val,
            min=torch.finfo(x.dtype).eps,
        )
        return sigma_ratio * x - torch.expm1(-h) * denoised_d



class DPMPlusPlus2MSamplerAdapter:
    SAMPLER_CAPABILITIES = DPMPlusPlus2MSampler.SAMPLER_CAPABILITIES

    """
    Thin adapter matching the pipeline sampler contract.
    """

    def __init__(self):
        self.sampler = DPMPlusPlus2MSampler()

    def sample(
        self,
        raw_model_fn,
        guided_model_fn,
        latents,
        schedule,
        conditioning,
        request,
        state=None,
    ):
        return self.sampler.sample(
            raw_model_fn=raw_model_fn,
            guided_model_fn=guided_model_fn,
            latents=latents,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
            state=state,
        )

SAMPLER_NAME = "DPM++ 2M"
SAMPLER_CLASS = DPMPlusPlus2MSampler
SAMPLER_ADAPTER_CLASS = DPMPlusPlus2MSamplerAdapter

PLUGIN_DESCRIPTOR = {
    "plugin_id": "sampler.dpmpp_2m",
    "kind": "sampler",
    "name": "dpmpp_2m",
    "label": "DPM++ 2M",
    "description": meta["description"],
    "version": "1",
    "module": __name__,
    "adapter_class": "DPMPlusPlus2MSamplerAdapter",
    "aliases": ['dpm++ 2m', 'dpmpp2m', 'dpm plus plus 2m'],
    "capabilities": DPMPlusPlus2MSamplerAdapter.SAMPLER_CAPABILITIES.to_serializable_dict(),
    "config_schema": {
        "type": "object",
        "properties": {
            "solver_dtype": {
                "type": "string",
                "enum": ["latent", "float16", "float32"],
                "default": "latent",
                "description": "Internal DPM++ 2M solver precision. Phase 8A uses float32 diagnostically without changing the default."
            }
        },
        "required": [],
        "additionalProperties": True,
    },
}
