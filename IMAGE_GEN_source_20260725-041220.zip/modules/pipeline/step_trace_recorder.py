from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import json
import math
import os
import tempfile


@dataclass
class TraceRequest:
    enabled: bool = True
    export_json: bool = False
    export_csv: bool = False
    export_txt_summary: bool = True
    keep_in_memory: bool = True
    cleanup_after_export: bool = False

    capture_latents: bool = False
    capture_latent_every_n: int = 0
    capture_first_step: bool = True
    capture_last_step: bool = True

    run_name: str = "generation_run"
    output_dir: str = "modules/pipeline/image_generation_data"


@dataclass
class StepTraceRecord:
    step_index: int
    sigma: Optional[float] = None
    sigma_next: Optional[float] = None
    sigma_delta: Optional[float] = None
    latent_norm_before: Optional[float] = None
    latent_norm_after: Optional[float] = None
    noise_pred_norm: Optional[float] = None
    guided_noise_norm: Optional[float] = None
    cfg_scale: Optional[float] = None
    stopping_candidate: Optional[bool] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TraceSummary:
    run_name: str
    total_steps_recorded: int
    requested_steps: Optional[int] = None
    effective_steps: Optional[int] = None
    stopping_index: Optional[int] = None
    sampler_name: Optional[str] = None
    scheduler_name: Optional[str] = None
    schedule_extra: Dict[str, Any] = field(default_factory=dict)
    exported_files: Dict[str, str] = field(default_factory=dict)


class StepTraceRecorder:
    """
    Shared runtime trace recorder for pipeline-managed, sampler-fed step logging.

    Intended flow:
    1. Pipeline creates one recorder per generation run.
    2. Pipeline passes recorder into the sampler.
    3. Sampler calls record_step(...) inside its iteration loop.
    4. Pipeline calls export_requested_artifacts(...) after sampling.

    Notes:
    - This class is intentionally in-memory first.
    - CSV export is optional and disabled by default.
    - Full latent retention is opt-in and should be used sparingly.
    """

    def __init__(
        self,
        request: Optional[TraceRequest] = None,
        schedule_extra: Optional[Dict[str, Any]] = None,
        sampler_name: Optional[str] = None,
        scheduler_name: Optional[str] = None,
    ) -> None:
        self.request = request or TraceRequest()
        self.schedule_extra: Dict[str, Any] = dict(schedule_extra or {})
        self.sampler_name = sampler_name
        self.scheduler_name = scheduler_name

        self.records: list[StepTraceRecord] = []
        self.latents: dict[int, Any] = {}
        self.exported_files: Dict[str, str] = {}

        self.requested_steps: Optional[int] = self._coerce_int(self.schedule_extra.get("requested_steps"))
        self.effective_steps: Optional[int] = self._coerce_int(self.schedule_extra.get("effective_steps"))
        self.stopping_index: Optional[int] = self._coerce_int(self.schedule_extra.get("predicted_stop_step"))

    @property
    def enabled(self) -> bool:
        return bool(self.request.enabled)

    def seed_schedule_metadata(self, schedule_extra: Optional[Dict[str, Any]]) -> None:
        if not schedule_extra:
            return
        self.schedule_extra.update(schedule_extra)

        if self.requested_steps is None:
            self.requested_steps = self._coerce_int(schedule_extra.get("requested_steps"))
        if self.effective_steps is None:
            self.effective_steps = self._coerce_int(schedule_extra.get("effective_steps"))
        if self.stopping_index is None:
            self.stopping_index = self._coerce_int(schedule_extra.get("predicted_stop_step"))

    def record_step(
        self,
        *,
        step_index: int,
        sigma: Any = None,
        sigma_next: Any = None,
        latent_before: Any = None,
        latent_after: Any = None,
        noise_pred: Any = None,
        guided_noise: Any = None,
        cfg_scale: Any = None,
        stopping_candidate: Optional[bool] = None,
        extra: Optional[Dict[str, Any]] = None,
        latent_snapshot: Any = None,
    ) -> None:
        if not self.enabled:
            return

        sigma_value = self._coerce_float(sigma)
        sigma_next_value = self._coerce_float(sigma_next)
        sigma_delta = None
        if sigma_value is not None and sigma_next_value is not None:
            sigma_delta = sigma_next_value - sigma_value

        record = StepTraceRecord(
            step_index=int(step_index),
            sigma=sigma_value,
            sigma_next=sigma_next_value,
            sigma_delta=sigma_delta,
            latent_norm_before=self._tensor_norm(latent_before),
            latent_norm_after=self._tensor_norm(latent_after),
            noise_pred_norm=self._tensor_norm(noise_pred),
            guided_noise_norm=self._tensor_norm(guided_noise),
            cfg_scale=self._coerce_float(cfg_scale),
            stopping_candidate=stopping_candidate,
            extra=dict(extra or {}),
        )
        self.records.append(record)

        snapshot = latent_snapshot if latent_snapshot is not None else latent_after
        if self._should_capture_latent(step_index):
            self.latents[int(step_index)] = self._detach_for_storage(snapshot)

    def set_runtime_summary(
        self,
        *,
        requested_steps: Optional[int] = None,
        effective_steps: Optional[int] = None,
        stopping_index: Optional[int] = None,
    ) -> None:
        if requested_steps is not None:
            self.requested_steps = int(requested_steps)
        if effective_steps is not None:
            self.effective_steps = int(effective_steps)
        if stopping_index is not None:
            self.stopping_index = int(stopping_index)

    def build_summary(self) -> TraceSummary:
        return TraceSummary(
            run_name=self.request.run_name,
            total_steps_recorded=len(self.records),
            requested_steps=self.requested_steps,
            effective_steps=self.effective_steps,
            stopping_index=self.stopping_index,
            sampler_name=self.sampler_name,
            scheduler_name=self.scheduler_name,
            schedule_extra=dict(self.schedule_extra),
            exported_files=dict(self.exported_files),
        )

    def export_requested_artifacts(self) -> Dict[str, str]:
        if not self.enabled:
            return {}

        output_dir = Path(self.request.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        base_name = self._safe_run_name(self.request.run_name)

        if self.request.export_json:
            json_path = output_dir / f"{base_name}_step_trace.json"
            self._export_json(json_path)
            self.exported_files["json"] = str(json_path)

        if self.request.export_csv:
            csv_path = output_dir / f"{base_name}_step_trace.csv"
            self._export_csv(csv_path)
            self.exported_files["csv"] = str(csv_path)

        if self.request.export_txt_summary:
            txt_path = output_dir / f"{base_name}_trace_summary.txt"
            self._export_txt_summary(txt_path)
            self.exported_files["summary"] = str(txt_path)

        if self.request.cleanup_after_export:
            self.cleanup()

        return dict(self.exported_files)

    def cleanup(self) -> None:
        self.records.clear()
        self.latents.clear()
        if not self.request.keep_in_memory:
            self.schedule_extra.clear()

    @staticmethod
    def _json_safe(value: Any) -> Any:
        # Import lazily to avoid a module-import cycle: DiagnosticsSystem imports
        # StepTraceRecorder while the diagnostics package is still initializing.
        from image_gen.systems.diagnostics.serialization import json_safe

        return json_safe(value)

    def _export_json(self, path: Path) -> None:
        payload = self._json_safe(
            {
                "summary": asdict(self.build_summary()),
                "records": [asdict(record) for record in self.records],
            }
        )
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _export_csv(self, path: Path) -> None:
        import csv

        fieldnames = [
            "step_index",
            "sigma",
            "sigma_next",
            "sigma_delta",
            "latent_norm_before",
            "latent_norm_after",
            "noise_pred_norm",
            "guided_noise_norm",
            "cfg_scale",
            "stopping_candidate",
            "extra_json",
        ]

        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for record in self.records:
                writer.writerow(
                    {
                        "step_index": record.step_index,
                        "sigma": record.sigma,
                        "sigma_next": record.sigma_next,
                        "sigma_delta": record.sigma_delta,
                        "latent_norm_before": record.latent_norm_before,
                        "latent_norm_after": record.latent_norm_after,
                        "noise_pred_norm": record.noise_pred_norm,
                        "guided_noise_norm": record.guided_noise_norm,
                        "cfg_scale": record.cfg_scale,
                        "stopping_candidate": record.stopping_candidate,
                        "extra_json": json.dumps(
                            self._json_safe(record.extra),
                            ensure_ascii=False,
                        ),
                    }
                )

    def _export_txt_summary(self, path: Path) -> None:
        summary = self.build_summary()
        lines = [
            f"run_name: {summary.run_name}",
            f"sampler_name: {summary.sampler_name}",
            f"scheduler_name: {summary.scheduler_name}",
            f"requested_steps: {summary.requested_steps}",
            f"effective_steps: {summary.effective_steps}",
            f"stopping_index: {summary.stopping_index}",
            f"total_steps_recorded: {summary.total_steps_recorded}",
            "schedule_extra:",
        ]

        if summary.schedule_extra:
            for key, value in summary.schedule_extra.items():
                lines.append(f"  {key}: {value}")
        else:
            lines.append("  <none>")

        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def _should_capture_latent(self, step_index: int) -> bool:
        if not self.request.capture_latents:
            return False

        if step_index == 0 and self.request.capture_first_step:
            return True

        if (
            self.effective_steps is not None
            and step_index == max(0, self.effective_steps - 1)
            and self.request.capture_last_step
        ):
            return True

        every_n = int(self.request.capture_latent_every_n or 0)
        return every_n > 0 and step_index % every_n == 0

    @staticmethod
    def _safe_run_name(value: str) -> str:
        cleaned = value.strip().replace(" ", "_")
        return "".join(ch for ch in cleaned if ch.isalnum() or ch in {"_", "-"}) or "generation_run"

    @staticmethod
    def _coerce_int(value: Any) -> Optional[int]:
        if value is None:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _coerce_float(value: Any) -> Optional[float]:
        if value is None:
            return None
        try:
            if hasattr(value, "item"):
                value = value.item()
            result = float(value)
            if math.isnan(result) or math.isinf(result):
                return None
            return result
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _tensor_norm(value: Any) -> Optional[float]:
        if value is None:
            return None

        try:
            if hasattr(value, "detach"):
                value = value.detach()
            if hasattr(value, "float"):
                value = value.float()
            if hasattr(value, "norm"):
                norm_value = value.norm()
                if hasattr(norm_value, "item"):
                    norm_value = norm_value.item()
                return float(norm_value)
        except Exception:
            return None

        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _detach_for_storage(value: Any) -> Any:
        if value is None:
            return None

        try:
            if hasattr(value, "detach"):
                value = value.detach()
            if hasattr(value, "cpu"):
                value = value.cpu()
            return value
        except Exception:
            return None


def create_step_trace_recorder(
    *,
    enabled: bool = True,
    run_name: str = "generation_run",
    output_dir: str = "modules/pipeline/image_generation_data",
    schedule_extra: Optional[Dict[str, Any]] = None,
    sampler_name: Optional[str] = None,
    scheduler_name: Optional[str] = None,
    export_json: bool = False,
    export_csv: bool = False,
    export_txt_summary: bool = True,
    capture_latents: bool = False,
    capture_latent_every_n: int = 0,
    cleanup_after_export: bool = False,
) -> StepTraceRecorder:
    request = TraceRequest(
        enabled=enabled,
        export_json=export_json,
        export_csv=export_csv,
        export_txt_summary=export_txt_summary,
        run_name=run_name,
        output_dir=output_dir,
        capture_latents=capture_latents,
        capture_latent_every_n=capture_latent_every_n,
        cleanup_after_export=cleanup_after_export,
    )
    return StepTraceRecorder(
        request=request,
        schedule_extra=schedule_extra,
        sampler_name=sampler_name,
        scheduler_name=scheduler_name,
    )
