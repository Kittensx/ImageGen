from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from modules.contracts import GenerationRequest
from modules.txt2img.infotext_parser import parse_infotext
from modules.txt2img.manifest_adapters import manifest_to_request_kwargs
from modules.txt2img.manifest_io import load_manifest_json

try:
    import yaml
except Exception:  # pragma: no cover
    yaml = None


GENERATION_REQUEST_KEYS = {
    "positive_prompt",
    "negative_prompt",
    "width",
    "height",
    "steps",
    "cfg_scale",
    "batch_size",
    "seed",
    "scheduler_name",
    "sampler_name",
    "scheduler_kwargs",
    "sampler_kwargs",
    "parser_kwargs",
    "diagnostics",
    "return_latents",
    "save_images",
    "output_dir",
    "output_prefix",
}

PAYLOAD_ALIASES = {
    "prompt": "positive_prompt",
    "negative_prompt": "negative_prompt",

    # Runtime-facing names (used if explicitly provided)
    "sampler": "sampler_name",
    "scheduler": "scheduler_name",

    # A1111 compatibility → preserve labels, do NOT overwrite runtime name
    "schedule_type": "scheduler_label",

    "sampler_label": "sampler_label",
    "scheduler_label": "scheduler_label",
}

EXTRA_REQUEST_KEYS = {
    "model_path",
    "model_name",
    "model_hash",
    "model_version",

    # A1111 import fields
    "sampler_label",
    "scheduler_label",
    "infotext_source",
    "infotext_raw",
    
    
    "vae_path",
    "vae_name",
    "vae_hash",
    "compatibility_mode",
    "clip_skip",
    "guidance_rescale",
    "tiling",
    "lora_paths",
    "loras",
    
}


def _normalize_payload_keys(payload: dict[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    for key, value in dict(payload or {}).items():
        target_key = PAYLOAD_ALIASES.get(key, key)
        normalized[target_key] = value
    return normalized



def _load_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8")



def load_request_from_yaml(path: str | Path) -> dict[str, Any]:
    if yaml is None:
        raise RuntimeError("PyYAML is required to load YAML request files.")
    payload = yaml.safe_load(_load_text(path)) or {}
    if not isinstance(payload, dict):
        raise TypeError("YAML request payload must be a mapping.")
    return _normalize_payload_keys(payload)



def load_request_from_json(path: str | Path) -> dict[str, Any]:
    payload = json.loads(_load_text(path))
    if not isinstance(payload, dict):
        raise TypeError("JSON request payload must be a mapping.")
    return _normalize_payload_keys(payload)



def load_request_from_manifest_json(path: str | Path) -> dict[str, Any]:
    manifest = load_manifest_json(path)
    payload = manifest_to_request_kwargs(manifest)
    return _normalize_payload_keys(payload)



def load_request_from_infotext(path: str | Path) -> dict[str, Any]:
    text = _load_text(path)
    payload = parse_infotext(text)
    payload["infotext_source"] = str(path)
    payload["infotext_raw"] = text

    # Pre-normalized lookup helpers
    if "sampler_label" in payload:
        payload["_sampler_label_norm"] = str(payload["sampler_label"]).strip().lower()

    if "scheduler_label" in payload:
        payload["_scheduler_label_norm"] = str(payload["scheduler_label"]).strip().lower()
    
    return _normalize_payload_keys(payload)



def merge_cli_overrides(base: dict[str, Any], overrides: dict[str, Any] | None) -> dict[str, Any]:
    merged = dict(base or {})
    for key, value in dict(overrides or {}).items():
        if value is None:
            continue
        if key in {"scheduler_kwargs", "sampler_kwargs", "parser_kwargs", "diagnostics"}:
            current = dict(merged.get(key, {}) or {})
            current.update(dict(value or {}))
            merged[key] = current
        else:
            merged[key] = value
    return merged



def split_request_payload(payload: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    normalized = _normalize_payload_keys(payload)
    request_kwargs = {
        k: v for k, v in normalized.items()
        if k in GENERATION_REQUEST_KEYS and k not in {"sampler_label", "scheduler_label"}
    }

    extras = {
        k: v for k, v in normalized.items()
        if k not in request_kwargs
    }
    return request_kwargs, extras



def payload_to_generation_request(payload: dict[str, Any]) -> tuple[GenerationRequest, dict[str, Any]]:
    request_kwargs, extras = split_request_payload(payload)
    request_kwargs.setdefault("positive_prompt", "")
    request = GenerationRequest(**request_kwargs)
    return request, extras



def request_to_payload(request: GenerationRequest, extras: dict[str, Any] | None = None) -> dict[str, Any]:
    if is_dataclass(request):
        payload = asdict(request)
    else:
        payload = dict(vars(request))
    payload.update(dict(extras or {}))
    return payload



def load_request_payload(
    *,
    config_path: str | Path | None = None,
    manifest_path: str | Path | None = None,
    infotext_path: str | Path | None = None,
    cli_overrides: dict[str, Any] | None = None,
    base_payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    sources = [config_path, manifest_path, infotext_path]
    active_count = sum(1 for item in sources if item)
    if active_count > 1:
        raise ValueError("Choose only one of config_path, manifest_path, or infotext_path.")

    payload: dict[str, Any] = _normalize_payload_keys(dict(base_payload or {}))
    source_payload: dict[str, Any] = {}
    if config_path:
        suffix = Path(config_path).suffix.lower()
        if suffix in {".yaml", ".yml"}:
            source_payload = load_request_from_yaml(config_path)
        elif suffix == ".json":
            source_payload = load_request_from_json(config_path)
        else:
            raise ValueError(f"Unsupported config extension: {suffix}")
    elif manifest_path:
        source_payload = load_request_from_manifest_json(manifest_path)
    elif infotext_path:
        source_payload = load_request_from_infotext(infotext_path)

    payload = merge_cli_overrides(payload, source_payload)
    return merge_cli_overrides(payload, cli_overrides)
