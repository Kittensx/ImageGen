from __future__ import annotations
from typing import Any


def prompt_with_default(label: str, default: Any) -> Any:
    raw = input(f"{label} [{default}]: ").strip()
    return default if raw == "" else raw


def choose_from_registry(title: str, registry_map: dict[str, Any]) -> dict[str, Any]:
    entries = [(key, value) for key, value in registry_map.items() if isinstance(value, dict)]
    if not entries:
        raise RuntimeError(f"No entries available for {title}.")

    print(f"\n=== {title} ===")
    for idx, (_, entry) in enumerate(entries, start=1):
        label = entry.get("label") or entry.get("name") or str(idx)
        name = entry.get("name") or ""
        if name and name != label:
            print(f"{idx}. {label} ({name})")
        else:
            print(f"{idx}. {label}")

    while True:
        raw = input(f"Choose {title} [1-{len(entries)}]: ").strip()
        try:
            index = int(raw)
            if 1 <= index <= len(entries):
                return entries[index - 1][1]
        except ValueError:
            pass
        print("Invalid selection.")


def build_interactive_overrides() -> dict[str, Any]:
    print("\n=== Generation Settings ===")

    prompt = input("Positive prompt: ").strip()
    negative = input("Negative prompt []: ").strip()

    steps = int(prompt_with_default("Steps", 20))
    cfg_scale = float(prompt_with_default("CFG Scale", 7.0))
    seed = int(prompt_with_default("Seed", -1))
    width = int(prompt_with_default("Width", 640))
    height = int(prompt_with_default("Height", 960))
    batch_size = int(prompt_with_default("Batch size", 1))
    model_path = prompt_with_default("Model path", "")

    return {
        "positive_prompt": prompt,
        "negative_prompt": negative,
        "steps": steps,
        "cfg_scale": cfg_scale,
        "seed": seed,
        "width": width,
        "height": height,
        "batch_size": batch_size,
        "model_path": model_path,
    }