from image_gen.systems.diagnostics.serialization import json_safe
from modules.txt2img.generation_manifest import (
    GenerationManifest,
    RequiredForRerun,
)


def build_generation_manifest(
    positive_prompt: str,
    negative_prompt: str,
    seed: int,
    width: int,
    height: int,
    steps: int,
    cfg_scale: float,
    sampler_name: str,
    scheduler_name: str,
    model_path: str,
    request=None,
    compatibility_mode: str | None = None,
    effective_steps: int | None = None,
    scheduler_step_override_applied: bool | None = None,
    active_blend_methods: list[str] | None = None,
    active_blend_weights: list[float] | None = None,
    tail_features_used: dict | None = None,
    predicted_stop_step: int | None = None,
    device_name: str | None = None,
    generation_time_sec: float | None = None,
) -> GenerationManifest:
    
    
    
    manifest = GenerationManifest(
        required_for_rerun=RequiredForRerun(
            prompt=positive_prompt,
            negative_prompt=negative_prompt,
            seed=seed,
            width=width,
            height=height,
            steps=steps,
            cfg_scale=cfg_scale,
            sampler_name=sampler_name,
            scheduler_name=scheduler_name,
            model_path=model_path,
        )
    )

    scheduler_kwargs = getattr(request, "scheduler_kwargs", {}) if request is not None else {}
    sampler_kwargs = getattr(request, "sampler_kwargs", {}) if request is not None else {}

    manifest.optional_for_rerun.scheduler_kwargs = dict(
        json_safe(scheduler_kwargs or {})
    )
    manifest.optional_for_rerun.sampler_kwargs = dict(
        json_safe(sampler_kwargs or {})
    )
    manifest.optional_for_rerun.compatibility_mode = compatibility_mode

    manifest.runtime_info.effective_steps = effective_steps
    manifest.runtime_info.scheduler_step_override_applied = scheduler_step_override_applied
    manifest.runtime_info.active_blend_methods = list(active_blend_methods or [])
    manifest.runtime_info.active_blend_weights = list(active_blend_weights or [])
    manifest.runtime_info.tail_features_used = dict(tail_features_used or {})
    manifest.runtime_info.predicted_stop_step = predicted_stop_step
    manifest.runtime_info.device = device_name
    manifest.runtime_info.generation_time_sec = generation_time_sec
    

    return manifest