from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Sequence

import torch
from PIL import Image

from modules.txt2img.generation_manifest import GenerationManifest
from modules.txt2img.manifest_io import save_manifest_json, save_manifest_txt


@dataclass
class SavedImageRecord:
    image_path: str
    txt_path: str | None = None
    json_path: str | None = None
    index: int | None = None


class GenerationOutputSaver:
    """
    Centralized save helper for txt2img outputs.

    Responsibilities:
    - support BCHW tensors or PIL images
    - auto-increment file numbering to avoid overwrite
    - optional sidecar txt/json manifest save
    - update manifest runtime paths per saved image
    """

    def __init__(
        self,
        output_dir: str | Path,
        prefix: str = "img",
        image_ext: str = ".png",
    ):
        self.output_dir = Path(output_dir)
        self.prefix = self._clean_prefix(prefix)
        self.image_ext = self._normalize_ext(image_ext)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _clean_prefix(prefix: str) -> str:
        value = str(prefix or "img").strip()
        return value or "img"

    @staticmethod
    def _normalize_ext(image_ext: str) -> str:
        value = str(image_ext or ".png").strip().lower()
        if not value.startswith("."):
            value = f".{value}"
        return value

    @staticmethod
    def tensor_to_pil_images(images: torch.Tensor) -> list[Image.Image]:
        if images.ndim != 4:
            raise ValueError(f"Expected BCHW tensor, got shape {tuple(images.shape)}")

        batch = images.detach().float().cpu().clamp(0, 1)
        pil_images: list[Image.Image] = []
        for image in batch:
            image_hwc = image.permute(1, 2, 0)
            image_uint8 = (image_hwc * 255.0).round().to(torch.uint8).numpy()
            pil_images.append(Image.fromarray(image_uint8).convert("RGB"))
        return pil_images

    @staticmethod
    def _coerce_pil_images(images: torch.Tensor | Sequence[Image.Image]) -> list[Image.Image]:
        if torch.is_tensor(images):
            return GenerationOutputSaver.tensor_to_pil_images(images)

        output: list[Image.Image] = []
        for idx, image in enumerate(images):
            if not isinstance(image, Image.Image):
                raise TypeError(f"Item {idx} is not a PIL image: {type(image)}")
            output.append(image.convert("RGB"))
        return output

    def _existing_indices(self) -> list[int]:
        pattern = f"{self.prefix}_*{self.image_ext}"
        found: list[int] = []
        for path in self.output_dir.glob(pattern):
            stem = path.stem
            prefix_with_sep = f"{self.prefix}_"
            if not stem.startswith(prefix_with_sep):
                continue
            suffix = stem[len(prefix_with_sep):]
            if suffix.isdigit():
                found.append(int(suffix))
        return sorted(found)

    def next_index(self) -> int:
        existing = self._existing_indices()
        if not existing:
            return 1
        return existing[-1] + 1

    def build_base_path(self, index: int) -> Path:
        return self.output_dir / f"{self.prefix}_{index:07d}"

    def save_batch(
        self,
        images: torch.Tensor | Sequence[Image.Image],
        manifest: GenerationManifest | None = None,
        save_txt: bool = True,
        save_json: bool = True,
        image_kwargs: dict[str, Any] | None = None,
    ) -> list[SavedImageRecord]:
        pil_images = self._coerce_pil_images(images)
        image_kwargs = dict(image_kwargs or {})

        records: list[SavedImageRecord] = []
        next_idx = self.next_index()

        for image in pil_images:
            base_path = self.build_base_path(next_idx)
            image_path = base_path.with_suffix(self.image_ext)
            image.save(image_path, **image_kwargs)

            txt_path: Path | None = None
            json_path: Path | None = None

            if manifest is not None:
                manifest.runtime_info.output_image_path = str(image_path)
                if save_txt:
                    txt_path = base_path.with_suffix(".txt")
                    save_manifest_txt(manifest, txt_path)
                    manifest.runtime_info.output_txt_path = str(txt_path)
                if save_json:
                    json_path = base_path.with_suffix(".json")
                    save_manifest_json(manifest, json_path)
                    manifest.runtime_info.output_json_path = str(json_path)

            records.append(
                SavedImageRecord(
                    image_path=str(image_path),
                    txt_path=None if txt_path is None else str(txt_path),
                    json_path=None if json_path is None else str(json_path),
                    index=next_idx,
                )
            )
            next_idx += 1

        return records


def save_generation_batch(
    images: torch.Tensor | Sequence[Image.Image],
    output_dir: str | Path,
    prefix: str = "img",
    manifest: GenerationManifest | None = None,
    save_txt: bool = True,
    save_json: bool = True,
    image_ext: str = ".png",
    image_kwargs: dict[str, Any] | None = None,
) -> list[SavedImageRecord]:
    saver = GenerationOutputSaver(
        output_dir=output_dir,
        prefix=prefix,
        image_ext=image_ext,
    )
    return saver.save_batch(
        images=images,
        manifest=manifest,
        save_txt=save_txt,
        save_json=save_json,
        image_kwargs=image_kwargs,
    )
