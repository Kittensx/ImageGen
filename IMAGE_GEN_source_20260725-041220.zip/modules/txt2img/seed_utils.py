from __future__ import annotations

import secrets

import torch


MAX_SEED = 2**31 - 1


def resolve_seed(seed: int | None) -> int:
    """Resolve the final generation seed.

    ``None`` and negative values request a fresh random seed. Non-negative
    values are preserved exactly so repeated requests remain reproducible.
    """
    if seed is None:
        return secrets.randbelow(MAX_SEED + 1)

    resolved = int(seed)
    if resolved < 0:
        return secrets.randbelow(MAX_SEED + 1)
    return resolved


def create_torch_generator(
    seed: int,
    device: str | torch.device = "cpu",
) -> torch.Generator:
    """Create a device-local ``torch.Generator`` for deterministic sampling."""
    resolved_device = torch.device(device)
    generator = torch.Generator(device=resolved_device)
    generator.manual_seed(int(seed))
    return generator


def prepare_generation_seed(
    seed: int | None,
    device: str | torch.device = "cpu",
) -> tuple[int, torch.Generator]:
    """Resolve a seed and construct the matching deterministic generator."""
    resolved_seed = resolve_seed(seed)
    generator = create_torch_generator(resolved_seed, device=device)
    return resolved_seed, generator
