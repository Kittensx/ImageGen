from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional
import json
import os

import torch
from diffusers import UNet2DConditionModel, AutoencoderKL
from transformers import CLIPTextConfig, CLIPTextModel

from modules.frozenclip.modules import FrozenCLIPEmbedder

from modules.config_resolver import ResolvedConfigs
from modules.state_dict_mapper import MappedStateDict
from modules.state_dict_converter import StateDictConverter
from modules.config_deriver import ConfigDeriver
from modules.ldm_vae_builder import LDMVAEBuilder, LDMVAEBuildResult

@dataclass
class ComponentLoadResult:
    name: str
    loaded_keys: int
    expected_keys: int = 0
    matched_keys: int = 0
    missing_keys: list[str] = field(default_factory=list)
    unexpected_keys: list[str] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def success(self) -> bool:
        return self.error is None

    @property
    def coverage_ratio(self) -> float:
        if self.expected_keys <= 0:
            return 0.0
        return self.matched_keys / self.expected_keys

    def to_validation_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "success": self.success,
            "provided_keys": self.loaded_keys,
            "expected_keys": self.expected_keys,
            "matched_keys": self.matched_keys,
            "coverage_ratio": self.coverage_ratio,
            "missing_key_count": len(self.missing_keys),
            "unexpected_key_count": len(self.unexpected_keys),
            "missing_key_samples": self.missing_keys[:25],
            "unexpected_key_samples": self.unexpected_keys[:25],
            "error": self.error,
        }


@dataclass
class BuiltComponents:
    unet: UNet2DConditionModel
    vae: Any
    text_encoder: Any

    unet_result: ComponentLoadResult
    vae_result: Any
    text_encoder_result: ComponentLoadResult


class ComponentBuilder:
    """
    Builds local model components from local config files and mapped checkpoint state.

    Responsibilities:
    - load JSON configs from disk
    - instantiate component classes locally
    - load split checkpoint weights into those components
    - return structured results
    """

    def __init__(self, device: str | None = None, dtype: torch.dtype | None = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = dtype
        self.converter = StateDictConverter()
        self.deriver = ConfigDeriver()
        self.ldm_vae_builder = LDMVAEBuilder(device=self.device, dtype=self.dtype)

    def build_components(
        self,
        configs: ResolvedConfigs,
        mapped_state: MappedStateDict,
    ) -> BuiltComponents:
        converted = self.converter.convert_all(
            unet_state=mapped_state.unet,
            vae_state=mapped_state.vae,
            text_state=mapped_state.text_encoder,
        )

        unet = self._build_unet(configs.unet_config_path)
       

        unet_result = self._load_component_state(
            component=unet,
            state_dict=converted.unet,
            name="unet",
        )
        vae_result = self.ldm_vae_builder.build_and_load(mapped_state.vae)
        vae = vae_result.model
        
        text_encoder = self._build_text_encoder(configs.text_encoder_config_path)

        text_encoder_result = self._load_component_state(
            component=text_encoder,
            state_dict=converted.text_encoder,
            name="text_encoder",
        )

        self._move_component(unet)
        self._move_component(text_encoder)
       

        return BuiltComponents(
            unet=unet,
            vae=vae,
            text_encoder=text_encoder,
            unet_result=unet_result,
            vae_result=vae_result,
            text_encoder_result=text_encoder_result,
           
        )

    def _build_text_encoder(self, config_path: str) -> CLIPTextModel:
        config_dict = self._load_json(config_path)
        text_config = CLIPTextConfig(**config_dict)
        return CLIPTextModel(text_config)
        
    def _build_unet(self, config_path: str) -> UNet2DConditionModel:
        config = self._load_json(config_path)
        return UNet2DConditionModel.from_config(config)

    def _build_vae(self, config_path: str, mapped_vae_state: dict[str, Any]) -> AutoencoderKL:
        derived = self.deriver.derive_vae_config(mapped_vae_state)
        print(f"Derived VAE block_out_channels: {derived.block_out_channels}")
        config = derived.to_diffusers_config()
        return AutoencoderKL.from_config(config)
    
    def _load_component_state(
        self,
        component: torch.nn.Module,
        state_dict: dict[str, Any],
        name: str,
    ) -> ComponentLoadResult:
        expected = set(component.state_dict().keys())
        provided = set(state_dict.keys())
        matched = expected.intersection(provided)
        if not state_dict:
            return ComponentLoadResult(
                name=name,
                loaded_keys=0,
                expected_keys=len(expected),
                matched_keys=0,
                error=f"No state_dict entries found for component '{name}'.",
            )

        try:
            incompatible = component.load_state_dict(state_dict, strict=False)

            missing_keys = list(getattr(incompatible, "missing_keys", []))
            unexpected_keys = list(getattr(incompatible, "unexpected_keys", []))

            return ComponentLoadResult(
                name=name,
                loaded_keys=len(state_dict),
                expected_keys=len(expected),
                matched_keys=len(matched),
                missing_keys=missing_keys,
                unexpected_keys=unexpected_keys,
                error=None,
            )
        except Exception as e:
            return ComponentLoadResult(
                name=name,
                loaded_keys=len(state_dict),
                expected_keys=len(expected),
                matched_keys=len(matched),
                error=str(e),
            )

    def _move_component(self, component: torch.nn.Module) -> None:
        if self.dtype is not None:
            component.to(device=self.device, dtype=self.dtype)
        else:
            component.to(device=self.device)

    def _load_json(self, path: str) -> dict[str, Any]:
        if not os.path.exists(path):
            raise FileNotFoundError(f"Missing config file: {path}")

        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)