# IMAGE_GEN Canonical Runtime Contracts

## Purpose

Phase 02 establishes one authoritative contract package for all pipeline-facing request, component, conditioning, schedule, sampler, result, adapter, and compatibility objects.

New code must import these contracts from:

```python
from modules.contracts import ...
```

The historical paths remain temporary compatibility facades so later phases can migrate callers without breaking the project all at once.

## Canonical package

```text
modules/contracts/
|-- __init__.py
|-- runtime.py
|-- protocols.py
`-- compatibility.py
```

## Runtime objects

### `GenerationRequest`

Contains prompts, dimensions, step count, CFG scale, seed, selected sampler and scheduler, adapter settings, and output behavior.

`to_serializable_dict()` produces a JSON-safe request description. Devices and dtypes are rendered as strings.

### `PipelineComponents`

Contains the live UNet, VAE, text encoder, and tokenizer used by a composed runtime. These are intentionally runtime objects and are never embedded directly in serialized generation output.

### `ConditioningOutput`

Contains conditional and unconditional embeddings, optional pooled embeddings, prompt schedules, and conditioning metadata.

### `SchedulerOutput`

Owns:

- `sigmas`
- `timesteps`
- `requested_steps`
- `effective_steps`
- `scheduler_step_override_applied`
- `compatibility_mode`
- scheduler-owned `metadata`

Requested and effective step values are no longer informal keys scattered through arbitrary metadata. The legacy `extra` property projects the canonical fields into a dictionary for older code, but the authoritative values remain typed fields.

### `SamplerOutput`

Contains final latents and sampler-owned metadata.

### `GenerationResult`

Contains the request, decoded images, final latents, conditioning result, scheduler result, sampler result, trace exports, saved paths, and result metadata.

The result supports a temporary dictionary-style compatibility view, but new callers should use attributes.

`to_serializable_dict()` replaces tensors and other live runtime values with JSON-safe summaries. It does not serialize model modules, callbacks, adapters, or arbitrary Python objects.

## Adapter protocols

The canonical adapter interfaces are:

```text
PromptAdapterProtocol.encode(
    components,
    request,
    state=None,
)

SchedulerAdapterProtocol.build_schedule(
    request,
    state=None,
)

SamplerAdapterProtocol.sample(
    raw_model_fn,
    guided_model_fn,
    latents,
    schedule,
    conditioning,
    request,
    state=None,
)
```

Registry registration validates exact parameter names and requires `state` to remain optional. A malformed adapter therefore fails during registration instead of failing halfway through a generation.

## Denoising callback ownership

### KES path

KES declares:

```text
guidance_owner = sampler
uses_raw_model_fn = true
uses_guided_model_fn = false
```

KES receives raw model prediction access and owns cond/uncond mixing and CFG behavior.

### Baseline path

Simple Euler and DPM++ 2M declare:

```text
guidance_owner = pipeline
uses_raw_model_fn = false
uses_guided_model_fn = true
```

They receive pipeline-guided predictions and do not interpret KES tail semantics.

The callback protocols require sigma and timestep explicitly. Updating the two baseline sampler loops to pass the timestep is the Phase 03 correctness repair; Phase 02 defines and validates the contract without claiming that the existing baseline math is repaired.

## Sampler capabilities

`SamplerCapabilities` is the single capability model for:

- CFG ownership
- raw versus guided callback use
- step expansion
- scheduler tail metadata
- requested-step schedule requirements
- strict compatibility validation
- forced scheduler pipeline mode

The old `SamplerScheduleCapabilities` name is an alias to this canonical class.

## Scheduler compatibility

`SchedulerCompatibilityResult` is the single compatibility result model for both policy decisions and validation results. It records:

- sampler name
- compatibility state
- pipeline mode
- fixed-schedule requirement
- expansion and tail support
- requested and effective steps
- sigma transition count
- warnings and incompatibility reasons

The old `ScheduleCompatibilityDecision` and `ScheduleValidationResult` names are aliases to this class.

## Compatibility paths

The following imports remain supported during migration:

```python
from modules.pipeline_builder import GenerationRequest
from modules.pipeline.pipeline_builder import SamplerOutput
from modules.adapters.base import SamplerAdapter
```

They re-export canonical contracts and do not define new dataclasses or protocols.
