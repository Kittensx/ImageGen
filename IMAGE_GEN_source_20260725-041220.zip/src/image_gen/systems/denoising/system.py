from __future__ import annotations

from typing import Any

import torch


class DenoisingSystem:
    """Own the canonical UNet call, sigma input scaling, and CFG combination."""

    MODEL_PREDICTION_TYPE = "epsilon"

    def __init__(self, unet: torch.nn.Module) -> None:
        self.unet = unet

    @staticmethod
    def _normalize_sigma(latents: torch.Tensor, sigma: torch.Tensor | float) -> torch.Tensor:
        value = torch.as_tensor(sigma, device=latents.device, dtype=latents.dtype).flatten()
        if value.numel() == 1 and latents.shape[0] > 1:
            value = value.expand(latents.shape[0])
        if value.numel() not in {1, latents.shape[0]}:
            raise ValueError("sigma must be scalar or provide one value per latent batch item.")
        return value

    @staticmethod
    def _normalize_timestep(latents: torch.Tensor, timestep: torch.Tensor | float) -> torch.Tensor:
        value = torch.as_tensor(timestep, device=latents.device, dtype=torch.float32).flatten()
        if value.numel() == 1 and latents.shape[0] > 1:
            value = value.expand(latents.shape[0])
        if value.numel() not in {1, latents.shape[0]}:
            raise ValueError("timestep must be scalar or provide one value per latent batch item.")
        return value

    @staticmethod
    def extract_model_tensor(model_output: Any, *, owner: str) -> torch.Tensor:
        value = model_output
        if hasattr(value, "sample"):
            value = value.sample
        elif isinstance(value, (tuple, list)):
            if not value:
                raise TypeError(f"{owner} returned an empty sequence.")
            value = value[0]
        if not torch.is_tensor(value):
            raise TypeError(f"{owner} must return a tensor, tuple, or object with .sample.")
        return value

    @staticmethod
    def scale_model_input(latents: torch.Tensor, sigma_tensor: torch.Tensor) -> torch.Tensor:
        sigma_b = sigma_tensor
        while sigma_b.ndim < latents.ndim:
            sigma_b = sigma_b.unsqueeze(-1)
        return latents / torch.sqrt(sigma_b.square() + 1.0)

    def predict_raw_noise(
        self,
        latents: torch.Tensor,
        sigma: torch.Tensor | float,
        timestep: torch.Tensor | float,
        cond: torch.Tensor,
        extra_cond_kwargs: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        sigma_tensor = self._normalize_sigma(latents, sigma)
        timestep_tensor = self._normalize_timestep(latents, timestep)
        model_input = self.scale_model_input(latents, sigma_tensor)
        model_out = self.unet(
            sample=model_input,
            timestep=timestep_tensor,
            encoder_hidden_states=cond,
            **(extra_cond_kwargs or {}),
        )
        epsilon = self.extract_model_tensor(model_out, owner="UNet")
        if epsilon.shape != latents.shape:
            raise ValueError(
                f"UNet prediction shape {tuple(epsilon.shape)} does not match latents {tuple(latents.shape)}."
            )
        if not torch.isfinite(epsilon).all():
            raise ValueError("UNet returned non-finite values.")
        return epsilon

    def predict_guided_noise(
        self,
        latents: torch.Tensor,
        sigma: torch.Tensor | float,
        timestep: torch.Tensor | float,
        cond: torch.Tensor,
        uncond: torch.Tensor,
        cfg_scale: float,
        extra_cond_kwargs: dict[str, Any] | None = None,
    ) -> torch.Tensor:
        noise_uncond = self.predict_raw_noise(latents, sigma, timestep, uncond, extra_cond_kwargs)
        noise_cond = self.predict_raw_noise(latents, sigma, timestep, cond, extra_cond_kwargs)
        return noise_uncond + float(cfg_scale) * (noise_cond - noise_uncond)
