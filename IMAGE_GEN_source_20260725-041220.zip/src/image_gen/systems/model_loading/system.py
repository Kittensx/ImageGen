from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

import torch

from image_gen.contracts import PipelineComponents
from image_gen.systems.validation.capabilities import capability_for

if TYPE_CHECKING:
    from modules.load_safetensors_model import LoadModel


@dataclass
class LoadedModel:
    components: PipelineComponents
    load_plan: Any
    built_components: Any


class ModelLoadingSystem:
    """Checkpoint loading boundary preserving the existing loader implementation."""

    def __init__(self, loader: Any) -> None:
        self.loader = loader

    @property
    def default_model_path(self) -> str | None:
        value = getattr(self.loader, "MODEL_PATH", None)
        return str(value) if value else None

    def load(
        self,
        model_path: str,
        *,
        tokenizer: Any,
        dtype: torch.dtype | None = None,
    ) -> LoadedModel:
        plan = self.loader.prepare_load_plan(model_path)
        checkpoint_report = getattr(plan, "report", None)
        if checkpoint_report is not None:
            capability = capability_for(getattr(checkpoint_report, "architecture", "unknown"))
            if not capability.generation_supported:
                raise RuntimeError(
                    f"Checkpoint architecture {capability.architecture!r} is not enabled: "
                    f"{capability.reason}"
                )
        built = self.loader.build_components_from_plan(plan, dtype=dtype)
        failures = []
        for label, result in (
            ("UNet", built.unet_result),
            ("Text encoder", built.text_encoder_result),
            ("VAE", built.vae_result),
        ):
            if not result.success:
                failures.append(f"{label} failed: {result.error}")
        if failures:
            raise RuntimeError("; ".join(failures))
        return LoadedModel(
            components=PipelineComponents(
                unet=built.unet,
                vae=built.vae,
                text_encoder=built.text_encoder,
                tokenizer=tokenizer,
            ),
            load_plan=plan,
            built_components=built,
        )
