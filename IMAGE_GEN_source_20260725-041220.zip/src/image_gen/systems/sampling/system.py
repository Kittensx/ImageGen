from __future__ import annotations

from typing import Any

import torch

from image_gen.contracts import (
    ConditioningOutput,
    GenerationRequest,
    GuidedModelFnProtocol,
    RawModelFnProtocol,
    SamplerAdapterProtocol,
    SamplerOutput,
    SchedulerOutput,
)
from modules.txt2img.seed_utils import prepare_generation_seed


class LatentPreparationSystem:
    """Own deterministic initial-noise creation in scheduler sigma space."""

    def __init__(
        self,
        *,
        latent_scale_factor: int = 8,
        device: torch.device,
        dtype: torch.dtype,
        latent_channels: int = 4,
    ) -> None:
        self.latent_scale_factor = int(latent_scale_factor)
        self.device = device
        self.dtype = dtype
        self.latent_channels = int(latent_channels)
        if self.latent_scale_factor < 1:
            raise ValueError("latent_scale_factor must be at least 1.")

    def prepare(self, request: GenerationRequest, schedule: SchedulerOutput) -> torch.Tensor:
        if request.width <= 0 or request.height <= 0:
            raise ValueError("Generation width and height must be positive.")
        if request.width % self.latent_scale_factor or request.height % self.latent_scale_factor:
            raise ValueError(
                "Generation dimensions must be divisible by latent_scale_factor "
                f"({self.latent_scale_factor})."
            )
        if request.batch_size < 1:
            raise ValueError("batch_size must be at least 1.")
        resolved_seed, generator = prepare_generation_seed(request.seed, device=self.device)
        request.seed = resolved_seed
        shape = (
            request.batch_size,
            self.latent_channels,
            request.height // self.latent_scale_factor,
            request.width // self.latent_scale_factor,
        )
        latents = torch.randn(shape, generator=generator, device=self.device, dtype=self.dtype)
        if schedule.initial_sigma <= 0:
            raise ValueError("The first scheduler sigma must be greater than zero.")
        return latents * float(schedule.initial_sigma)


class SamplingSystem:
    """Own sampler invocation and validate its latent output boundary."""

    def __init__(self, adapter: SamplerAdapterProtocol) -> None:
        self.adapter = adapter

    def sample(
        self,
        *,
        raw_model_fn: RawModelFnProtocol,
        guided_model_fn: GuidedModelFnProtocol,
        latents: torch.Tensor,
        schedule: SchedulerOutput,
        conditioning: ConditioningOutput,
        request: GenerationRequest,
        state: Any | None = None,
    ) -> SamplerOutput:
        output = self.adapter.sample(
            raw_model_fn=raw_model_fn,
            guided_model_fn=guided_model_fn,
            latents=latents,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
            state=state,
        )
        if not isinstance(output, SamplerOutput):
            raise TypeError("Sampler adapter must return SamplerOutput.")
        if output.latents.shape != latents.shape:
            raise ValueError("Sampler output latent shape changed unexpectedly.")
        if not torch.isfinite(output.latents).all():
            raise ValueError("Sampler returned non-finite latents.")
        return output
