from __future__ import annotations

from typing import Any

import torch

from image_gen.contracts import (
    ConditioningOutput,
    GenerationRequest,
    GenerationResult,
    PipelineComponents,
    PromptAdapterProtocol,
    SamplerAdapterProtocol,
    SchedulerAdapterProtocol,
    SchedulerOutput,
)
from image_gen.runtime.composition import GenerationSystems, PipelineCompositionRoot
from image_gen.systems.diagnostics import DiagnosticSession, PipelineStageError
from modules.pipeline.conditioning_utils import resolve_step_conditioning as resolve_step_conditioning_util


class GenerationPipeline:
    """Ordered, file-system-free composition of the generation systems."""

    MODEL_PREDICTION_TYPE = "epsilon"

    def __init__(
        self,
        *,
        components: PipelineComponents,
        systems: GenerationSystems,
        state: Any | None = None,
        device: torch.device,
        dtype: torch.dtype,
        latent_scale_factor: int = 8,
        vae_scaling_factor: float = 0.18215,
    ) -> None:
        self.components = components
        self.systems = systems
        self.state = state
        self.device = device
        self.dtype = dtype
        self.latent_scale_factor = int(latent_scale_factor)
        self.vae_scaling_factor = float(vae_scaling_factor)

        # Temporary compatibility attributes while historical callers migrate.
        self.prompt_adapter = getattr(systems.conditioning, "adapter", None)
        self.scheduler_adapter = getattr(systems.scheduling, "adapter", None)
        self.sampler_adapter = getattr(systems.sampling, "adapter", None)

    def prepare_latents(
        self,
        request: GenerationRequest,
        schedule: SchedulerOutput | None = None,
    ) -> torch.Tensor:
        if schedule is None:
            schedule = self.systems.scheduling.build(request, self.state)
        return self.systems.latent_preparation.prepare(request, schedule)

    def predict_raw_noise(self, *args: Any, **kwargs: Any) -> torch.Tensor:
        return self.systems.denoising.predict_raw_noise(*args, **kwargs)

    def predict_guided_noise(self, *args: Any, **kwargs: Any) -> torch.Tensor:
        return self.systems.denoising.predict_guided_noise(*args, **kwargs)

    def decode_latents(self, latents: torch.Tensor) -> torch.Tensor:
        return self.systems.decoding.decode(latents)

    def resolve_step_conditioning(
        self,
        conditioning: ConditioningOutput,
        step_index: int,
        latents: torch.Tensor | None = None,
        state: Any | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        return resolve_step_conditioning_util(
            conditioning=conditioning,
            step_index=step_index,
            latents=latents,
            state=state or self.state,
        )

    @staticmethod
    def _validate_result(request: GenerationRequest, result: GenerationResult) -> GenerationResult:
        if result.latents is None or not torch.is_tensor(result.latents):
            raise TypeError("GenerationResult.latents must be a tensor.")
        if not torch.isfinite(result.latents).all():
            raise ValueError("GenerationResult.latents contains non-finite values.")
        if not request.return_latents:
            if result.images is None or not torch.is_tensor(result.images):
                raise TypeError("GenerationResult.images must be a tensor unless return_latents is enabled.")
            expected = (request.batch_size, request.height, request.width)
            actual = (result.images.shape[0], result.images.shape[-2], result.images.shape[-1])
            if actual != expected:
                raise ValueError(
                    f"Decoded image dimensions must be {expected}, got {actual}."
                )
            if not torch.isfinite(result.images).all():
                raise ValueError("GenerationResult.images contains non-finite values.")
        return result

    @torch.no_grad()
    def generate(
        self,
        request: GenerationRequest,
        *,
        diagnostic_session: DiagnosticSession | None = None,
    ) -> GenerationResult:
        diagnostics = self.systems.diagnostics
        owns_session = diagnostic_session is None
        session = diagnostic_session or diagnostics.start(
            request,
            components=self.components,
        )
        diagnostics.update_components(session, self.components)

        try:
            conditioning = diagnostics.run_stage(
                session,
                "conditioning",
                "encode",
                lambda: self.systems.conditioning.encode(
                    self.components, request, self.state
                ),
            )
            diagnostics.record_tensor(
                session,
                "conditioning.cond",
                conditioning.cond,
                system="conditioning",
                operation="encode",
            )
            diagnostics.record_tensor(
                session,
                "conditioning.uncond",
                conditioning.uncond,
                system="conditioning",
                operation="encode",
            )

            schedule = diagnostics.run_stage(
                session,
                "scheduling",
                "build",
                lambda: self.systems.scheduling.build(request, self.state),
            )
            diagnostics.update_schedule(session, schedule)

            latents = diagnostics.run_stage(
                session,
                "latent_preparation",
                "prepare",
                lambda: self.systems.latent_preparation.prepare(request, schedule),
            )
            diagnostics.record_tensor(
                session,
                "latent_preparation.latents",
                latents,
                system="latent_preparation",
                operation="prepare",
            )

            raw_model_fn = diagnostics.wrap_callable(
                session,
                "denoising",
                "predict_raw_noise",
                self.systems.denoising.predict_raw_noise,
            )
            guided_model_fn = diagnostics.wrap_callable(
                session,
                "denoising",
                "predict_guided_noise",
                self.systems.denoising.predict_guided_noise,
            )
            sample_output = diagnostics.run_stage(
                session,
                "sampling",
                "sample",
                lambda: self.systems.sampling.sample(
                    raw_model_fn=raw_model_fn,
                    guided_model_fn=guided_model_fn,
                    latents=latents,
                    schedule=schedule,
                    conditioning=conditioning,
                    request=request,
                    state=self.state,
                ),
            )
            diagnostics.update_sampler(session, sample_output)
            trace_exports = diagnostics.finish(session, sample_output)

            images = None
            if not request.return_latents:
                images = diagnostics.run_stage(
                    session,
                    "decoding",
                    "decode",
                    lambda: self.systems.decoding.decode(sample_output.latents),
                )
                diagnostics.record_tensor(
                    session,
                    "decoding.images",
                    images,
                    system="decoding",
                    operation="decode",
                )

            result = GenerationResult(
                request=request,
                images=images,
                latents=sample_output.latents,
                conditioning=conditioning,
                schedule=schedule,
                sampler=sample_output,
                trace_exports=trace_exports,
                metadata={
                    "model_prediction_type": self.MODEL_PREDICTION_TYPE,
                    "initial_noise_sigma": schedule.initial_sigma,
                    "output_owner": "txt2img.output_saver",
                    "output_system": "image_gen.systems.output.OutputSystem",
                    "runtime": "image_gen.runtime.GenerationPipeline",
                },
            )
            result = diagnostics.run_stage(
                session,
                "runtime",
                "result_validation",
                lambda: self._validate_result(request, result),
            )
            result.metadata["diagnostics"] = diagnostics.summary(session)
            if owns_session:
                result.metadata["diagnostics"] = diagnostics.complete(
                    session, result=result
                )
            return result
        except PipelineStageError:
            raise
        except Exception as exc:
            raise diagnostics.fail_unassigned(
                session, exc, system="runtime", operation="generate"
            ) from exc


class CustomSDPipeline(GenerationPipeline):
    """Historical constructor preserved while delegating to system composition."""

    def __init__(
        self,
        components: PipelineComponents,
        prompt_adapter: PromptAdapterProtocol,
        scheduler_adapter: SchedulerAdapterProtocol,
        sampler_adapter: SamplerAdapterProtocol,
        state: Any | None = None,
        latent_scale_factor: int = 8,
        vae_scaling_factor: float = 0.18215,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
        system_overrides: dict[str, Any] | None = None,
    ) -> None:
        root = PipelineCompositionRoot(
            components=components,
            prompt_adapter=prompt_adapter,
            scheduler_adapter=scheduler_adapter,
            sampler_adapter=sampler_adapter,
            latent_scale_factor=latent_scale_factor,
            vae_scaling_factor=vae_scaling_factor,
            device=device,
            dtype=dtype,
            system_overrides=system_overrides,
        )
        systems = root.create_systems()
        super().__init__(
            components=components,
            systems=systems,
            state=state,
            device=root.device,
            dtype=root.dtype,
            latent_scale_factor=latent_scale_factor,
            vae_scaling_factor=vae_scaling_factor,
        )
