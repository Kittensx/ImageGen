from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import torch

from image_gen.contracts import ConditioningOutput, GenerationRequest, SchedulerOutput
from modules.pipeline.step_trace_recorder import StepTraceRecorder, TraceRequest
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSampler,
)
from scripts.validation.phase08a_sampler_matrix import write_report
from scripts.validation.phase08a_support import (
    MODEL_BOUNDED_KARRAS,
    Phase8ASchedulerAdapter,
    analyze_schedule,
    build_phase8a_variants,
)


class _FakeBaseSchedulerAdapter:
    def build_schedule(self, request, state=None):
        return SchedulerOutput(
            sigmas=torch.tensor([53.0, 20.0, 1.0, 0.01, 0.0]),
            timesteps=torch.tensor([999.0, 999.0, 500.0, 0.0, 0.0]),
            requested_steps=4,
            effective_steps=4,
            compatibility_mode="fixed_steps",
            metadata={
                "scheduler_name": "simple_kes",
                "schedule_mode": "smooth_blend",
                "timestep_mapping": {
                    "type": "test",
                    "num_train_timesteps": 1000,
                    "beta_start": 0.00085,
                    "beta_end": 0.012,
                    "training_sigma_min": 0.029167158151720367,
                    "training_sigma_max": 14.614641229333639,
                    "clipped_low_count": 1,
                    "clipped_high_count": 2,
                },
            },
        )


class Phase08ASamplerIsolationTests(unittest.TestCase):
    def test_variant_matrix_runs_all_registered_samplers_and_dpm_isolation(self) -> None:
        variants = build_phase8a_variants(
            ["future_sampler", "dpmpp_2m", "kes", "simple_euler"]
        )
        keys = [variant.key for variant in variants]

        self.assertEqual(
            keys[:4],
            [
                "simple_euler_native",
                "kes_native",
                "dpmpp_2m_A_native_latent",
                "future_sampler_native",
            ],
        )
        self.assertEqual(
            keys[-3:],
            [
                "dpmpp_2m_B_bounded_latent",
                "dpmpp_2m_C_native_float32",
                "dpmpp_2m_D_bounded_float32",
            ],
        )

    def test_bounded_scheduler_preserves_candidate_and_builds_valid_execution_schedule(self) -> None:
        request = GenerationRequest(
            positive_prompt="test",
            steps=4,
            scheduler_name="simple_kes",
            sampler_name="dpmpp_2m",
            scheduler_kwargs={
                "phase8a": {"schedule_mode": MODEL_BOUNDED_KARRAS}
            },
        )
        adapter = Phase8ASchedulerAdapter(base_adapter=_FakeBaseSchedulerAdapter())
        schedule = adapter.build_schedule(request, state=SimpleNamespace(extra={}))
        analysis = analyze_schedule(schedule)
        phase8a = schedule.metadata["phase8a"]

        self.assertEqual(schedule.sigmas.numel(), 5)
        self.assertEqual(schedule.sigmas[-1].item(), 0.0)
        self.assertTrue(analysis["non_increasing"])
        self.assertTrue(analysis["strictly_decreasing_positive"])
        self.assertEqual(analysis["clipped_high_count"], 0)
        self.assertEqual(analysis["clipped_low_count"], 0)
        self.assertEqual(analysis["duplicate_positive_timestep_count"], 0)
        self.assertEqual(phase8a["candidate_schedule"]["clipped_high_count"], 2)
        self.assertEqual(phase8a["candidate_schedule"]["clipped_low_count"], 1)
        self.assertEqual(phase8a["execution_schedule"]["clipped_high_count"], 0)
        self.assertEqual(phase8a["execution_schedule"]["clipped_low_count"], 0)

    def test_dpm_float32_solver_keeps_model_boundary_in_latent_dtype(self) -> None:
        sampler = DPMPlusPlus2MSampler()
        latents = torch.ones((1, 4, 2, 2), dtype=torch.float16)
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0], dtype=torch.float32),
            timesteps=torch.tensor([800.0, 400.0, 0.0], dtype=torch.float32),
            requested_steps=2,
            effective_steps=2,
            compatibility_mode="fixed_steps",
        )
        conditioning = ConditioningOutput(
            cond=torch.zeros((1, 2, 3), dtype=torch.float16),
            uncond=torch.zeros((1, 2, 3), dtype=torch.float16),
        )
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        request = GenerationRequest(
            positive_prompt="test",
            steps=2,
            cfg_scale=7.0,
            sampler_name="dpmpp_2m",
            sampler_kwargs={
                "solver_dtype": "float32",
                "trace_recorder": recorder,
            },
        )
        observed_dtypes: list[torch.dtype] = []
        observed_conditioning_dtypes: list[tuple[torch.dtype, torch.dtype]] = []

        def guided_model_fn(x, sigma, timestep, cond, uncond, cfg_scale):
            observed_dtypes.append(x.dtype)
            observed_conditioning_dtypes.append((cond.dtype, uncond.dtype))
            return torch.full_like(x, 0.125)

        output = sampler.sample(
            raw_model_fn=None,
            guided_model_fn=guided_model_fn,
            latents=latents,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
            state=None,
        )

        self.assertEqual(observed_dtypes, [torch.float16, torch.float16])
        self.assertEqual(
            observed_conditioning_dtypes,
            [
                (torch.float16, torch.float16),
                (torch.float16, torch.float16),
            ],
        )
        self.assertEqual(output.latents.dtype, torch.float16)
        self.assertEqual(output.extra["solver_dtype"], "torch.float32")
        self.assertEqual(output.extra["model_input_dtype"], "torch.float16")
        self.assertEqual(len(recorder.records), 2)
        self.assertEqual(recorder.records[0].extra["solver_dtype"], "torch.float32")
        self.assertIn("denoised", recorder.records[0].extra)
        self.assertTrue(recorder.records[1].extra["used_old_denoised"])

    def test_native_schedule_analysis_reports_clipped_and_duplicate_regions(self) -> None:
        schedule = _FakeBaseSchedulerAdapter().build_schedule(None)
        analysis = analyze_schedule(schedule)

        self.assertEqual(analysis["clipped_high_count"], 2)
        self.assertEqual(analysis["clipped_low_count"], 1)
        self.assertEqual(analysis["duplicate_positive_timestep_count"], 1)

    def test_trace_exports_normalize_torch_device_and_dtype_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            recorder = StepTraceRecorder(
                request=TraceRequest(
                    enabled=True,
                    export_json=True,
                    export_csv=True,
                    export_txt_summary=True,
                    run_name="phase08a_device_metadata",
                    output_dir=temp_dir,
                ),
                schedule_extra={
                    "scheduler_settings": {
                        "device": torch.device("cpu"),
                        "dtype": torch.float16,
                    }
                },
                sampler_name="simple_euler",
                scheduler_name="simple_kes",
            )
            recorder.record_step(
                step_index=0,
                sigma=torch.tensor(1.0),
                sigma_next=torch.tensor(0.0),
                extra={
                    "model_device": torch.device("cpu"),
                    "model_dtype": torch.float16,
                },
            )

            exports = recorder.export_requested_artifacts()

            json_payload = json.loads(
                Path(exports["json"]).read_text(encoding="utf-8")
            )
            self.assertEqual(
                json_payload["summary"]["schedule_extra"]["scheduler_settings"]["device"],
                "cpu",
            )
            self.assertEqual(
                json_payload["summary"]["schedule_extra"]["scheduler_settings"]["dtype"],
                "torch.float16",
            )
            self.assertEqual(
                json_payload["records"][0]["extra"]["model_device"],
                "cpu",
            )
            self.assertEqual(
                json_payload["records"][0]["extra"]["model_dtype"],
                "torch.float16",
            )

            with Path(exports["csv"]).open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            csv_extra = json.loads(rows[0]["extra_json"])
            self.assertEqual(csv_extra["model_device"], "cpu")
            self.assertEqual(csv_extra["model_dtype"], "torch.float16")

    def test_matrix_report_normalizes_runtime_metadata(self) -> None:
        report = {
            "created_utc": "2026-07-25T00:00:00+00:00",
            "scheduler_name": "simple_kes",
            "technical_complete": True,
            "runs": [
                {
                    "status": "completed",
                    "case": {"case_id": "device_case"},
                    "variant": {"key": "simple_euler_native"},
                    "schedule": {},
                    "schedule_metadata": {
                        "scheduler_settings": {
                            "device": torch.device("cpu"),
                            "dtype": torch.float16,
                        }
                    },
                }
            ],
            "dpm_comparisons": {},
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            json_path, markdown_path = write_report(report, Path(temp_dir))
            payload = json.loads(json_path.read_text(encoding="utf-8"))

            self.assertEqual(
                payload["runs"][0]["schedule_metadata"]["scheduler_settings"]["device"],
                "cpu",
            )
            self.assertEqual(
                payload["runs"][0]["schedule_metadata"]["scheduler_settings"]["dtype"],
                "torch.float16",
            )
            self.assertTrue(markdown_path.is_file())


if __name__ == "__main__":
    unittest.main()
