from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path

from image_gen.contracts import SamplerCapabilities
from image_gen.systems.registry import (
    DuplicatePluginIdentityError,
    PluginCompatibilityError,
    PluginDescriptor,
    PluginDescriptorError,
    PluginRegistry,
    RuntimeRegistrySystem,
)
from modules.project_context import ProjectContext
from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.kes_sampler_adapter import (
    KESSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.simple_euler import (
    SimpleEulerSamplerAdapter,
)
from modules.ss_registry.schedulers.simple_kes_sched.kes_scheduler_adapter import (
    SimpleKESSchedulerAdapter,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def sampler_descriptor(
    *,
    plugin_id: str,
    name: str,
    label: str,
    module: str,
    adapter_class: str = "SamplerAdapter",
    aliases: list[str] | None = None,
    capabilities: dict | None = None,
) -> PluginDescriptor:
    return PluginDescriptor.from_mapping(
        {
            "plugin_id": plugin_id,
            "kind": "sampler",
            "name": name,
            "label": label,
            "module": module,
            "adapter_class": adapter_class,
            "aliases": aliases or [],
            "capabilities": capabilities
            or SamplerCapabilities(
                sampler_name=name,
                guidance_owner="pipeline",
                uses_raw_model_fn=False,
                uses_guided_model_fn=True,
                requires_requested_step_schedule=True,
                forced_pipeline_mode="fixed_steps",
            ).to_serializable_dict(),
            "config_schema": {
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
        }
    )


def scheduler_descriptor(
    *,
    plugin_id: str,
    name: str,
    label: str,
    module: str,
    adapter_class: str = "SchedulerAdapter",
    aliases: list[str] | None = None,
    supports_fixed_steps: bool = True,
    supports_step_expansion: bool = False,
    supports_tail_metadata: bool = False,
) -> PluginDescriptor:
    return PluginDescriptor.from_mapping(
        {
            "plugin_id": plugin_id,
            "kind": "scheduler",
            "name": name,
            "label": label,
            "module": module,
            "adapter_class": adapter_class,
            "aliases": aliases or [],
            "capabilities": {
                "pipeline_modes": ["fixed_steps"],
                "supports_fixed_steps": supports_fixed_steps,
                "supports_step_expansion": supports_step_expansion,
                "supports_tail_metadata": supports_tail_metadata,
            },
            "config_schema": {
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
        }
    )


class Phase05BuiltInDiscoveryTests(unittest.TestCase):
    def test_discovers_every_builtin_through_one_descriptor_mechanism(self) -> None:
        context = ProjectContext.load(project_root=PROJECT_ROOT)
        system = RuntimeRegistrySystem(project_context=context)

        sampler_ids = {item.plugin_id for item in system.descriptors("sampler")}
        scheduler_ids = {item.plugin_id for item in system.descriptors("scheduler")}

        self.assertEqual(
            sampler_ids,
            {"sampler.kes", "sampler.simple_euler", "sampler.dpmpp_2m"},
        )
        self.assertEqual(scheduler_ids, {"scheduler.simple_kes"})
        self.assertEqual(system.construction_count, 1)

        # Reusing the same session must not rescan the filesystem.
        system.legacy_map("sampler")
        system.legacy_map("scheduler")
        system.descriptors()
        self.assertEqual(system.construction_count, 1)

    def test_builtin_aliases_resolve_to_stable_descriptors(self) -> None:
        context = ProjectContext.load(project_root=PROJECT_ROOT)
        system = RuntimeRegistrySystem(project_context=context)

        self.assertEqual(
            system.resolve_descriptor("DPM++ 2M", kind="sampler").plugin_id,
            "sampler.dpmpp_2m",
        )
        self.assertEqual(
            system.resolve_descriptor("euler", kind="sampler").plugin_id,
            "sampler.simple_euler",
        )
        self.assertEqual(
            system.resolve_descriptor("karras exponential", kind="scheduler").plugin_id,
            "scheduler.simple_kes",
        )

    def test_builtin_adapters_instantiate_through_descriptors(self) -> None:
        context = ProjectContext.load(project_root=PROJECT_ROOT)
        system = RuntimeRegistrySystem(state="phase05-state", project_context=context)

        self.assertIsInstance(
            system.instantiate_adapter(
                system.resolve_descriptor("simple_euler", kind="sampler")
            ),
            SimpleEulerSamplerAdapter,
        )
        kes = system.instantiate_adapter(system.resolve_descriptor("kes", kind="sampler"))
        scheduler = system.instantiate_adapter(
            system.resolve_descriptor("simple_kes", kind="scheduler")
        )
        self.assertIsInstance(kes, KESSamplerAdapter)
        self.assertEqual(kes.state, "phase05-state")
        self.assertIsInstance(scheduler, SimpleKESSchedulerAdapter)
        self.assertEqual(scheduler.state, "phase05-state")

    def test_all_builtin_sampler_scheduler_pairs_are_declared_compatible(self) -> None:
        context = ProjectContext.load(project_root=PROJECT_ROOT)
        system = RuntimeRegistrySystem(project_context=context)
        scheduler = system.resolve_descriptor("simple_kes", kind="scheduler")
        for sampler in system.descriptors("sampler"):
            with self.subTest(sampler=sampler.plugin_id):
                result = system.validate_pair(sampler, scheduler)
                self.assertTrue(result.is_compatible, result.reasons)

    def test_runtime_does_not_import_generated_python_map_modules(self) -> None:
        context = ProjectContext.load(project_root=PROJECT_ROOT)
        system = RuntimeRegistrySystem(project_context=context)
        system.descriptors()
        self.assertNotIn("modules.ss_registry.sampler_map", sys.modules)
        self.assertNotIn("modules.ss_registry.scheduler_map", sys.modules)


class Phase05DescriptorValidationTests(unittest.TestCase):
    def test_malformed_descriptor_identifies_missing_field(self) -> None:
        with self.assertRaisesRegex(PluginDescriptorError, "config_schema"):
            PluginDescriptor.from_mapping(
                {
                    "plugin_id": "sampler.broken",
                    "kind": "sampler",
                    "name": "broken",
                    "label": "Broken",
                    "module": "tests.phase05.broken",
                    "adapter_class": "BrokenAdapter",
                    "capabilities": {"guidance_owner": "pipeline"},
                }
            )

    def test_malformed_config_schema_identifies_required_field(self) -> None:
        with self.assertRaisesRegex(PluginDescriptorError, "undefined fields: missing"):
            PluginDescriptor.from_mapping(
                {
                    "plugin_id": "scheduler.broken",
                    "kind": "scheduler",
                    "name": "broken",
                    "label": "Broken",
                    "module": "tests.phase05.broken",
                    "adapter_class": "BrokenAdapter",
                    "capabilities": {"supports_fixed_steps": True},
                    "config_schema": {
                        "type": "object",
                        "properties": {},
                        "required": ["missing"],
                    },
                }
            )

    def test_duplicate_name_or_alias_is_rejected(self) -> None:
        module_a_name = "tests.phase05._plugin_a"
        module_b_name = "tests.phase05._plugin_b"
        module_a = types.ModuleType(module_a_name)
        module_b = types.ModuleType(module_b_name)

        class SamplerAdapter:
            def sample(
                self,
                raw_model_fn,
                guided_model_fn,
                latents,
                schedule,
                conditioning,
                request,
                state=None,
            ):
                return None

        module_a.SamplerAdapter = SamplerAdapter
        module_b.SamplerAdapter = SamplerAdapter
        sys.modules[module_a_name] = module_a
        sys.modules[module_b_name] = module_b
        try:
            registry = PluginRegistry()
            registry.register(
                sampler_descriptor(
                    plugin_id="sampler.alpha",
                    name="alpha",
                    label="Alpha",
                    module=module_a_name,
                    aliases=["shared alias"],
                ),
                module=module_a,
            )
            with self.assertRaisesRegex(DuplicatePluginIdentityError, "shared alias"):
                registry.register(
                    sampler_descriptor(
                        plugin_id="sampler.beta",
                        name="beta",
                        label="Beta",
                        module=module_b_name,
                        aliases=["shared alias"],
                    ),
                    module=module_b,
                )
        finally:
            sys.modules.pop(module_a_name, None)
            sys.modules.pop(module_b_name, None)


    def test_duplicate_canonical_name_is_rejected(self) -> None:
        module_a_name = "tests.phase05._name_plugin_a"
        module_b_name = "tests.phase05._name_plugin_b"
        module_a = types.ModuleType(module_a_name)
        module_b = types.ModuleType(module_b_name)

        class SamplerAdapter:
            def sample(
                self,
                raw_model_fn,
                guided_model_fn,
                latents,
                schedule,
                conditioning,
                request,
                state=None,
            ):
                return None

        module_a.SamplerAdapter = SamplerAdapter
        module_b.SamplerAdapter = SamplerAdapter
        sys.modules[module_a_name] = module_a
        sys.modules[module_b_name] = module_b
        try:
            registry = PluginRegistry()
            registry.register(
                sampler_descriptor(
                    plugin_id="sampler.name_alpha",
                    name="same_name",
                    label="First Label",
                    module=module_a_name,
                ),
                module=module_a,
            )
            with self.assertRaisesRegex(DuplicatePluginIdentityError, "name 'same_name'"):
                registry.register(
                    sampler_descriptor(
                        plugin_id="sampler.name_beta",
                        name="same_name",
                        label="Second Label",
                        module=module_b_name,
                    ),
                    module=module_b,
                )
        finally:
            sys.modules.pop(module_a_name, None)
            sys.modules.pop(module_b_name, None)

    def test_incompatible_sampler_scheduler_capabilities_are_rejected(self) -> None:
        sampler_module_name = "tests.phase05._expanding_sampler"
        scheduler_module_name = "tests.phase05._fixed_scheduler"
        sampler_module = types.ModuleType(sampler_module_name)
        scheduler_module = types.ModuleType(scheduler_module_name)

        class SamplerAdapter:
            def sample(
                self,
                raw_model_fn,
                guided_model_fn,
                latents,
                schedule,
                conditioning,
                request,
                state=None,
            ):
                return None

        class SchedulerAdapter:
            def build_schedule(self, request, state=None):
                return None

        sampler_module.SamplerAdapter = SamplerAdapter
        scheduler_module.SchedulerAdapter = SchedulerAdapter
        sys.modules[sampler_module_name] = sampler_module
        sys.modules[scheduler_module_name] = scheduler_module
        try:
            registry = PluginRegistry()
            expanding = SamplerCapabilities(
                sampler_name="expanding",
                guidance_owner="sampler",
                uses_raw_model_fn=True,
                uses_guided_model_fn=False,
                supports_step_expansion=True,
                supports_tail_metadata=True,
                requires_requested_step_schedule=False,
                forced_pipeline_mode="extended_steps",
            ).to_serializable_dict()
            registry.register(
                sampler_descriptor(
                    plugin_id="sampler.expanding",
                    name="expanding",
                    label="Expanding",
                    module=sampler_module_name,
                    capabilities=expanding,
                ),
                module=sampler_module,
            )
            registry.register(
                scheduler_descriptor(
                    plugin_id="scheduler.fixed_only",
                    name="fixed_only",
                    label="Fixed Only",
                    module=scheduler_module_name,
                ),
                module=scheduler_module,
            )
            result = registry.validate_pair("expanding", "fixed_only")
            self.assertFalse(result.is_compatible)
            with self.assertRaises(PluginCompatibilityError):
                result.raise_if_incompatible()
        finally:
            sys.modules.pop(sampler_module_name, None)
            sys.modules.pop(scheduler_module_name, None)


if __name__ == "__main__":
    unittest.main()
