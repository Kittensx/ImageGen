@echo off
cd /d %~dp0

call venv\Scripts\activate
set PYTHONPATH=%cd%

echo Running master_sampler.py...
echo Project root: %cd%
echo.

python -u scripts\diagnostics\sampler_map.py

echo.
echo Exit code: %ERRORLEVEL%
echo.
cmd /k
