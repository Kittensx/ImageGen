@echo off
setlocal
cd /d "%~dp0"

set "PYTHON=venv\Scripts\python.exe"
if not exist "%PYTHON%" set "PYTHON=python"

"%PYTHON%" scripts\tests\run_test_tier.py %*
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Phase 06 test tier passed.
) else (
    echo Phase 06 test tier failed or was not run. Exit code: %EXIT_CODE%
)
pause
exit /b %EXIT_CODE%
