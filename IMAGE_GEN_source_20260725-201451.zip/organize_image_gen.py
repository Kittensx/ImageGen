#!/usr/bin/env python3
"""Organize the loose files in the image_gen project root.

This restores the organizer used for the packaged IMAGE_GEN layout, with the
four legacy planning documents placed directly in ``docs/planning/historical``
to match IMAGE_GEN_source_20260725-041220 exactly.

The script is intentionally conservative:
- all .bat launchers remain in the project root;
- existing destination files are never overwritten;
- the operation is idempotent after a successful run;
- a JSON log is written under artifacts/organization/;
- use --dry-run to preview or --yes to apply without prompting.

Place this file in the image_gen project root, then run:
    py -3.10 organize_image_gen.py --dry-run
    py -3.10 organize_image_gen.py --yes
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


MoveTransform = Callable[[str], str]


def add_project_root_bootstrap(text: str, parents_index: int) -> str:
    marker = "# IMAGE_GEN_PROJECT_ROOT_BOOTSTRAP"
    if marker in text:
        return text
    block = (
        "from pathlib import Path\n"
        "import sys\n\n"
        f"{marker}\n"
        f"PROJECT_ROOT = Path(__file__).resolve().parents[{parents_index}]\n"
        "if str(PROJECT_ROOT) not in sys.path:\n"
        "    sys.path.insert(0, str(PROJECT_ROOT))\n\n"
    )
    future = "from __future__ import annotations\n"
    if text.startswith(future):
        return future + "\n" + block + text[len(future):].lstrip("\n")
    return block + text


def transform_app_run(text: str) -> str:
    return add_project_root_bootstrap(text, parents_index=1)


def transform_diagnostic_map(text: str) -> str:
    text = text.replace(
        "project_root = os.path.abspath(os.path.dirname(__file__))",
        'project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))',
    )
    text = text.replace(
        'output_json = os.path.join(project_root, "sampler_map_test_output.json")',
        'output_dir = os.path.join(project_root, "artifacts", "diagnostics")\n'
        '    os.makedirs(output_dir, exist_ok=True)\n'
        '    output_json = os.path.join(output_dir, "sampler_map_test_output.json")',
    )
    text = text.replace(
        'output_json = os.path.join(project_root, "scheduler_map_test_output.json")',
        'output_dir = os.path.join(project_root, "artifacts", "diagnostics")\n'
        '    os.makedirs(output_dir, exist_ok=True)\n'
        '    output_json = os.path.join(output_dir, "scheduler_map_test_output.json")',
    )
    return text


def transform_test_script(text: str) -> str:
    return add_project_root_bootstrap(text, parents_index=2)


def transform_install_venv(text: str) -> str:
    marker = "# IMAGE_GEN_ORGANIZED_PATHS"
    if marker not in text:
        text = text.replace(
            "import venv\n",
            "import venv\nfrom pathlib import Path\n\n"
            f"{marker}\n"
            "PROJECT_ROOT = Path(__file__).resolve().parents[2]\n"
            'REQUIREMENTS_FILE = PROJECT_ROOT / "requirements" / "requirements.txt"\n',
        )
    text = text.replace('VENV_DIR = "venv"', 'VENV_DIR = str(PROJECT_ROOT / "venv")')
    text = text.replace('if not os.path.exists("requirements.txt"):', "if not REQUIREMENTS_FILE.exists():")
    text = text.replace('print("❌ requirements.txt not found.")', 'print(f"❌ Requirements file not found: {REQUIREMENTS_FILE}")')
    text = text.replace('"-r", "requirements.txt"', '"-r", str(REQUIREMENTS_FILE)')
    return text


def transform_update_venv(text: str) -> str:
    marker = "# IMAGE_GEN_ORGANIZED_PATHS"
    if marker not in text:
        text = text.replace(
            "import sys\n",
            "import sys\nfrom pathlib import Path\n\n"
            f"{marker}\n"
            "PROJECT_ROOT = Path(__file__).resolve().parents[2]\n"
            'REQUIREMENTS_FILE = PROJECT_ROOT / "requirements" / "requirements.txt"\n',
        )
    text = text.replace(
        'PATCHED_NUMPY_PATH = os.path.join("imagecore", "repositories", "numpy")',
        'PATCHED_NUMPY_PATH = os.path.join(PROJECT_ROOT, "imagecore", "repositories", "numpy")',
    )
    text = text.replace(
        'return os.path.join("venv", "Scripts", "python.exe")',
        'return str(PROJECT_ROOT / "venv" / "Scripts" / "python.exe")',
    )
    text = text.replace(
        'return os.path.join("venv", "bin", "python")',
        'return str(PROJECT_ROOT / "venv" / "bin" / "python")',
    )
    text = text.replace('if not os.path.exists("requirements.txt"):', "if not REQUIREMENTS_FILE.exists():")
    text = text.replace('print("❌ requirements.txt not found.")', 'print(f"❌ Requirements file not found: {REQUIREMENTS_FILE}")')
    text = text.replace(
        'with open("requirements.txt", "r") as f:',
        'with REQUIREMENTS_FILE.open("r", encoding="utf-8") as f:',
    )
    text = text.replace(
        'temp_file = "temp_requirements.txt"',
        'temp_file = str(PROJECT_ROOT / "requirements" / "temp_requirements.txt")',
    )
    return text


STATIC_MOVES: list[tuple[str, str, MoveTransform | None]] = [
    ("run.py", "app/run.py", transform_app_run),
    ("install_venv.py", "scripts/setup/install_venv.py", transform_install_venv),
    ("update_venv.py", "scripts/setup/update_venv.py", transform_update_venv),
    ("requirements_cuda_install.py", "docs/setup/requirements_cuda_install_command.txt", None),
    ("sampler_map.py", "scripts/diagnostics/sampler_map.py", transform_diagnostic_map),
    ("sched.py", "scripts/diagnostics/scheduler_map.py", transform_diagnostic_map),
    ("test1.py", "scripts/diagnostics/model_load_test.py", transform_test_script),
    ("requirements.txt", "requirements/requirements.txt", None),
    ("requirements_cuda.txt", "docs/setup/cuda_install_notes.txt", None),
    ("output.png", "artifacts/samples/output.png", None),
    ("sampler_map_test_output.json", "artifacts/diagnostics/sampler_map_test_output.json", None),
    ("scheduler_map_test_output.json", "artifacts/diagnostics/scheduler_map_test_output.json", None),
    ("check 1..docx", "docs/planning/historical/check 1..docx", None),
    ("completed plan phases.docx", "docs/planning/historical/completed plan phases.docx", None),
    ("in progress_implementation_plan.docx", "docs/planning/historical/in progress_implementation_plan.docx", None),
    ("txt2img_implementation_plan.docx", "docs/planning/historical/txt2img_implementation_plan.docx", None),
    ("pipeline_requirements.docx", "docs/architecture/pipeline_requirements.docx", None),
    ("using frozenclip_tokenizeres.docx", "docs/research/using frozenclip_tokenizeres.docx", None),
    ("ideas.docx", "docs/ideas/ideas.docx", None),
]

BAT_REPLACEMENTS: dict[str, list[tuple[str, str]]] = {
    "run.bat": [
        ("call python.exe run.py", r"call python.exe app\run.py"),
        ("python.exe run.py", r"python.exe app\run.py"),
    ],
    "pb.bat": [
        ("python -u sampler_map.py", r"python -u scripts\diagnostics\sampler_map.py"),
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Organize the image_gen project root safely.")
    parser.add_argument("--root", type=Path, help="Project root; defaults to this script's folder")
    parser.add_argument("--dry-run", action="store_true", help="Show changes without moving or editing files")
    parser.add_argument("--yes", action="store_true", help="Apply without an interactive confirmation")
    return parser.parse_args()


def collect_moves(root: Path) -> list[tuple[Path, Path, MoveTransform | None]]:
    moves: list[tuple[Path, Path, MoveTransform | None]] = []
    for src_rel, dst_rel, transform in STATIC_MOVES:
        src = root / src_rel
        if src.exists():
            moves.append((src, root / dst_rel, transform))

    ideas_root = root / "_docs" / "Ideas"
    if ideas_root.is_dir():
        for src in sorted(ideas_root.iterdir(), key=lambda item: item.name.casefold()):
            if src.is_file():
                moves.append((src, root / "docs" / "ideas" / src.name, None))
    return moves


def planned_bat_patches(root: Path) -> list[Path]:
    patches: list[Path] = []
    for filename, replacements in BAT_REPLACEMENTS.items():
        path = root / filename
        if not path.is_file():
            continue
        text = path.read_text(encoding="utf-8-sig")
        if any(old in text and new not in text for old, new in replacements):
            patches.append(path)
    return patches


def apply_move(src: Path, dst: Path, transform: MoveTransform | None) -> tuple[str, str]:
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        return "conflict", f"Destination already exists: {dst}"

    if transform is None:
        shutil.move(str(src), str(dst))
    else:
        text = src.read_text(encoding="utf-8-sig")
        dst.write_text(transform(text), encoding="utf-8", newline="\n")
        src.unlink()
    return "moved", f"{src} -> {dst}"


def patch_bat(path: Path) -> bool:
    original = path.read_text(encoding="utf-8-sig")
    updated = original
    for old, new in BAT_REPLACEMENTS[path.name]:
        updated = updated.replace(old, new)
    if updated == original:
        return False
    path.write_text(updated, encoding="utf-8", newline="\r\n")
    return True


def remove_empty_legacy_dirs(root: Path) -> list[str]:
    removed: list[str] = []
    for path in (root / "_docs" / "Ideas", root / "_docs"):
        if path.is_dir() and not any(path.iterdir()):
            path.rmdir()
            removed.append(str(path))
    return removed


def main() -> int:
    args = parse_args()
    root = (args.root or Path(__file__).resolve().parent).resolve()
    if not (root / "modules").is_dir():
        print(f"ERROR: This does not look like the image_gen project root: {root}", file=sys.stderr)
        print("Expected to find the 'modules' directory.", file=sys.stderr)
        return 2

    moves = collect_moves(root)
    bat_patches = planned_bat_patches(root)

    print("IMAGE_GEN ROOT ORGANIZER")
    print(f"Project root: {root}")
    print(f"Files to move: {len(moves)}")
    print(f"Launchers to update: {len(bat_patches)}")
    print("\nThe .bat launchers will remain in the project root.")
    for src, dst, _ in moves:
        print(f"  MOVE  {src.relative_to(root)} -> {dst.relative_to(root)}")
    for path in bat_patches:
        print(f"  PATCH {path.relative_to(root)}")

    if args.dry_run:
        print("\nDRY RUN: no files were changed.")
        return 0

    if not args.yes:
        answer = input("\nApply these changes? [y/N]: ").strip().lower()
        if answer not in {"y", "yes"}:
            print("No changes made.")
            return 0

    records: list[dict[str, str]] = []
    conflicts = 0
    for src, dst, transform in moves:
        status, detail = apply_move(src, dst, transform)
        records.append({"status": status, "detail": detail})
        print(f"{status.upper():8} {detail}")
        if status == "conflict":
            conflicts += 1

    for path in bat_patches:
        changed = patch_bat(path)
        status = "patched" if changed else "unchanged"
        detail = str(path)
        records.append({"status": status, "detail": detail})
        print(f"{status.upper():8} {detail}")

    removed = remove_empty_legacy_dirs(root)
    for path in removed:
        records.append({"status": "removed_empty_directory", "detail": path})

    log_dir = root / "artifacts" / "organization"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    log_path = log_dir / f"organization_{stamp}.json"
    log = {
        "format": "image-gen-organization-log-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "project_root": str(root),
        "records": records,
        "conflict_count": conflicts,
    }
    log_path.write_text(json.dumps(log, indent=2), encoding="utf-8")

    print(f"\nOrganization log: {log_path}")
    if conflicts:
        print(f"Completed with {conflicts} conflict(s); existing destination files were not overwritten.")
        return 1
    print("Organization completed successfully.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
