# Attention Backend Recovery Control

The last coherent KES baseline used substantially slower UNet calls than the
current broken runs after the Python 3.10 environment rebuild. This hotfix
forces Diffusers `AttnProcessor` (eager attention) by default as a controlled
recovery test while leaving MSLK and xFormers installed.

Set one of the following before launching IMAGE_GEN to override the recovery
default:

```bat
set IMAGE_GEN_ATTENTION_BACKEND=eager
set IMAGE_GEN_ATTENTION_BACKEND=sdpa
set IMAGE_GEN_ATTENTION_BACKEND=xformers
set IMAGE_GEN_ATTENTION_BACKEND=default
```

Use `eager` first. The output manifest records the requested backend and the
actual UNet attention processor class names. If coherent generation returns,
the regression is isolated to the accelerated attention implementation chosen
by the rebuilt environment rather than the scheduler or sampler equations.

The CLI also prints the requested seed and rejects a run if a nonnegative seed
changes before or during generation. Output sequence numbering remains
independent from image seeds.
