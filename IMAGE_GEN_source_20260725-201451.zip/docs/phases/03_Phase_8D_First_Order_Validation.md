# Phase 8D — Validate First-Order DPM++ Without History

## Goal

Determine whether the canonical denoised prediction works when multistep history is completely disabled.

This isolates the denoising contract from the second-order history mechanism.

## New History Mode

Add:

```text
history_policy: first_order_only
```

This mode must use the first-order DPM++ update at every step.

Conceptually:

```python
x_next = first_order_dpmpp_update(
    sample=x,
    denoised=x0,
    sigma=sigma,
    sigma_next=sigma_next,
)
```

## Comparison Matrix

Use identical prompts, seeds, scheduler settings, step count, and sigma range:

| Variant | Model output | Update |
|---|---|---|
| Euler reference | Guided epsilon | Euler |
| DPM first-order legacy | Sampler-local x0 | First-order DPM++ |
| DPM first-order canonical | Denoiser-provided x0 | First-order DPM++ |

## Diagnostics

Record:

```text
predicted-x0 statistics
latent norm before update
latent norm after update
sigma
sigma_next
model timestep
finite-value status
difference from Euler reference
```

Decode predicted-x0 previews using the same selected steps from Phase 8B.

## Interpretation

### If canonical first-order succeeds

The denoising contract is probably correct.

Proceed to Phase 8E.

### If canonical first-order fails

Do not work on multistep history yet.

Investigate:

- Prediction type
- Model-input scaling
- Latent scaling
- CFG space
- Sigma used during conversion
- Initial-noise scaling
- Solver-state versus model-input confusion

## Required Tests

Add tests for:

- First-order-only mode never reads old denoised history.
- First-order-only mode never emits a second-order update.
- Canonical and legacy conversions can be compared independently.
- Terminal-zero behavior remains valid.
- The initial and final latent dtypes are handled correctly.
- Float32 solver state returns to the expected model/output dtype only at boundaries.

## Acceptance Gate

Phase 8D passes when canonical first-order DPM++ produces:

- Finite latents at every step
- Coherent predicted-x0 previews
- Prompt-related final images
- No major regression compared with Euler on reliable control prompts
- Repeatable output for fixed seeds

## Implementation Status — 2026-07-25

Phase 8D is implemented in source with an opt-in first-order policy:

```text
sampler_kwargs.history_policy: first_order_only
```

Normal DPM++ 2M requests continue to default to `multistep`. In first-order-only mode the sampler does not retain or read solver history, does not emit second-order updates, and still preserves terminal-zero behavior.

The real-checkpoint comparison runner is:

```bat
phase08d_validate.bat --model "C:\path\to\checkpoint.safetensors"
```

It runs the following matched matrix for every fixed prompt and seed:

```text
Euler reference
DPM first-order legacy sampler-local x0
DPM first-order canonical x0
DPM first-order canonical repeat
```

The legacy conversion is diagnostic-only. It requires both:

```text
phase08d_validation_mode: true
history_policy: first_order_only
```

The report is written under:

```text
artifacts/phase08d_first_order/<datetime>/
```

Technical completion verifies finite tensors, no history reads, no second-order updates, Euler-reference difference metrics, float32 solver state, predicted-x0 preview export, and fixed-seed repeatability. Coherence and prompt relevance remain the manual acceptance gate before Phase 8E.
