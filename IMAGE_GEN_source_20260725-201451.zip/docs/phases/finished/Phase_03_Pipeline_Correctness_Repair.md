# Phase 03 - Pipeline Correctness Repair

## Status

**Implementation complete:** 2026-07-25

The code-level pipeline correctness work is complete and validated with fake components. A real Stable Diffusion 1.x checkpoint was not included in the supplied source package, so the real-checkpoint smoke gate remains user-run/pending rather than being reported as passed.

## Objective

Repair the existing generation path before moving responsibilities into new system folders.

## Implemented Work

1. Fixed the Simple Euler and DPM++ 2M sampler paths so every denoising transition receives both sigma and timestep.
2. Standardized the raw denoiser callback as:

   ```text
   raw_model_fn(latents, sigma, timestep, conditioning, extra=None) -> epsilon
   ```

3. Standardized the guided denoiser callback as:

   ```text
   guided_model_fn(latents, sigma, timestep, cond, uncond, cfg_scale, extra=None) -> epsilon
   ```

4. Added schedule validation for one-dimensional, finite, non-negative, non-increasing sigma sequences; explicit transition counts; and valid timestep lengths.
5. Replaced the reversed logarithmic sigma-to-timestep approximation with Stable Diffusion 1.x scaled-linear beta reconstruction and log-sigma interpolation.
6. Made schedules terminate at explicit sigma zero instead of padding a short schedule by repeating the final positive sigma.
7. Scaled initial random latents by the first scheduler sigma.
8. Scaled UNet model input by `1 / sqrt(sigma^2 + 1)` before inference.
9. Declared epsilon/noise prediction as the canonical model-output parameterization.
10. Corrected DPM++ 2M to convert epsilon to denoised prediction before its integration update.
11. Routed Simple Euler, DPM++ 2M, and KES through the shared step-conditioning resolver.
12. Normalized UNet and VAE return forms that are tensors, tuples/lists, or objects exposing `.sample`.
13. Removed image writing from `CustomSDPipeline`; `modules.txt2img.output_saver` is now the sole output owner.
14. Removed the core-pipeline/runner double-save path.
15. Normalized seeds so `None` and negative values request a random seed while non-negative seeds remain reproducible.
16. Made KES-added sampler noise deterministic from the resolved request seed.
17. Removed unconditional tensor/configuration diagnostic printing from the normal generation path.
18. Updated the Phase 00 audit so repaired Phase 03 findings are recorded as resolved rather than outstanding.

## Runtime Ownership After Phase 03

| Concern | Authoritative owner |
|---|---|
| prompt and step conditioning | prompt adapter plus shared step-conditioning resolver |
| sigmas and timesteps | scheduler adapter and `SchedulerOutput` |
| raw/guided UNet calls | `CustomSDPipeline` denoiser callbacks |
| sampler integration | selected sampler adapter |
| latent initialization and seed | `CustomSDPipeline` plus `modules.txt2img.seed_utils` |
| VAE tensor normalization | `CustomSDPipeline.decode_latents` |
| image and manifest writing | `modules.txt2img.output_saver` through `Txt2ImgRunner` |

## Focused Tests

The Phase 03 suite verifies:

- raw callback argument order and model-input scaling
- guided callback argument order
- timestep delivery to baseline samplers
- schedule length, direction, and transition rules
- Stable Diffusion 1.x sigma-to-timestep direction
- initial latent scaling by the first sigma
- fixed-seed reproducibility
- successful fake-component runs through Simple Euler, DPM++ 2M, and KES
- DPM++ epsilon-to-denoised conversion behavior
- scheduled conditioning changes at the intended steps
- VAE tensor, tuple, and object-with-sample outputs
- zero file writes from the core pipeline
- one output layer invocation creating one output set
- quiet normal execution without unconditional debug output

Run the focused suite:

```bat
venv\Scripts\python.exe -m unittest tests.phase03.test_phase03_pipeline_correctness -v
```

Run Phases 00-03 regression coverage:

```bat
venv\Scripts\python.exe -m unittest tests.phase00.test_phase00_baseline tests.phase01.test_phase01_project_context tests.phase02.test_phase02_runtime_contracts tests.phase03.test_phase03_pipeline_correctness -v
```

Run the baseline audit:

```bat
venv\Scripts\python.exe scripts\audit\phase00_audit.py --print-known-issues
```

## Validation Result

```text
Phase 03 focused tests:      10 passed
Phase 00-03 focused total:   30 passed
Active-source compilation:   PASS
Internal import validation:  PASS
Fake pipeline baseline:      PASS
Failure-stage ownership:     PASS
```

## Exit Criteria

- [x] All three current sampler paths complete fake-component runs.
- [x] Baseline samplers receive explicit timesteps.
- [x] Schedule, scaling, parameterization, seed, VAE, and output ownership contracts are covered by focused tests.
- [ ] A real SD1 checkpoint completes image output or fails at a precisely identified system boundary.

The remaining item requires a locally available compatible checkpoint and is intentionally deferred to the controlled real-checkpoint validation work in Phase 07. Phase 03 does not claim real model-quality or checkpoint-compatibility validation.

## Known Follow-up

The current Simple KES defaults allow sigma values outside the reconstructed SD1 training sigma range. The scheduler records low/high clipping counts in `timestep_mapping` metadata so this is visible during later real-checkpoint validation. Do not treat the presence of SD1 configuration files as proof that every model family is supported.
