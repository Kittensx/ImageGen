# Phase 05 - Registry and Plugin Architecture

## Status

**Implementation complete:** 2026-07-25

Phase 05 replaces the runtime sampler/scheduler map scanners with a validated, session-scoped plugin registry. Generated maps remain optional diagnostics and are not imported by generation code.

## Objective

Make samplers and schedulers independently discoverable, validated, and upgradeable without editing the runtime pipeline.

## Canonical Registry Package

```text
src/image_gen/systems/registry/
|-- descriptors.py
|-- discovery.py
|-- errors.py
|-- registry.py
|-- system.py
`-- __init__.py
```

### Responsibilities

- `PluginDescriptor` defines stable plugin metadata.
- `PluginDiscovery` finds descriptor-bearing modules under the project registry root.
- `PluginRegistry` validates identities, adapters, schemas, and capabilities.
- `RuntimeRegistrySystem` owns one lazy registry instance for a runtime session.
- `PluginCompatibilityResult` explains sampler/scheduler capability conflicts.

## Descriptor Contract

Every sampler and scheduler plugin must export `PLUGIN_DESCRIPTOR` with:

```text
plugin_id
kind
name
label
module
adapter_class
aliases
capabilities
config_schema
description
version
```

Validation rules include:

- IDs are stable lowercase identifiers prefixed by `sampler.` or `scheduler.`.
- canonical names are lowercase and filesystem-safe.
- the adapter class must exist in the declared module.
- the adapter must conform to the canonical sampler or scheduler protocol.
- capabilities must be declared.
- configuration uses an object-style schema with declared properties.
- duplicate IDs, names, labels, and aliases within a plugin kind are rejected.

## Discovery Roots

Discovery uses `ProjectContext.registry_root`:

```text
modules/ss_registry/
|-- samplers/
|   |-- <package plugin>/__init__.py
|   `-- simple_samplers/<plugin>.py
`-- schedulers/
    `-- <package plugin>/__init__.py
```

The current working directory is not used. The package-location fallback is used only when a minimal injected test context does not expose `registry_root`.

## Built-in Plugins

All built-ins now use the same descriptor and validation path:

| Stable plugin ID | Kind | Canonical name | Adapter |
|---|---|---|---|
| `sampler.kes` | sampler | `kes` | `KESSamplerAdapter` |
| `sampler.simple_euler` | sampler | `simple_euler` | `SimpleEulerSamplerAdapter` |
| `sampler.dpmpp_2m` | sampler | `dpmpp_2m` | `DPMPlusPlus2MSamplerAdapter` |
| `scheduler.simple_kes` | scheduler | `simple_kes` | `SimpleKESSchedulerAdapter` |

Aliases such as `euler`, `DPM++ 2M`, and `karras exponential` resolve to the stable descriptor.

## Runtime Construction

The CLI now creates one `RuntimeRegistrySystem`, uses it for interactive choices, and passes the same instance into `Txt2ImgRunner`.

```text
CLI session
  -> RuntimeRegistrySystem
       -> lazy PluginRegistry discovery (once)
       -> sampler selection
       -> scheduler selection
       -> adapter construction
       -> compatibility validation
```

Repeated calls to `descriptors()` or `legacy_map()` reuse the same in-memory registry. The current transitional map shape is generated from descriptors, not from generated Python files.

## Compatibility Validation

Before model loading, descriptor capabilities are checked together:

- fixed-step samplers require scheduler fixed-step support.
- expanded-step samplers require scheduler expansion support.
- samplers using tail metadata require scheduler tail-metadata support.
- forced pipeline modes must be supported by the scheduler.

The existing schedule-level compatibility checks remain in place after schedule construction.

## Diagnostic Maps

`sampler_map.py` and `scheduler_map.py` are no longer runtime inputs.

The compatibility wrappers now:

- default to no file output;
- expose descriptor-derived maps to older imports;
- write JSON only when diagnostic output is explicitly requested.

Diagnostic scripts write to:

```text
artifacts/diagnostics/registry/sampler_registry.json
artifacts/diagnostics/registry/scheduler_registry.json
```

Each report states that it is not a runtime dependency.

## Source Package Correction

The supplied Phase 05 source archive referenced `image_gen.systems.output.OutputSystem` in the canonical runner and Phase 04 tests, but the corresponding `src/image_gen/systems/output/` files were absent from the archive. Phase 05 restores that previously documented system boundary so Phase 04 regression coverage remains runnable. This restoration does not change the Phase 03 rule that only the output system writes images and sidecars.

## Focused Tests

Run Phase 05:

```bat
venv\Scripts\python.exe -m unittest tests.phase05.test_phase05_registry_plugins -v
```

Run focused regression coverage through Phase 05:

```bat
venv\Scripts\python.exe -m unittest tests.phase00.test_phase00_baseline tests.phase01.test_phase01_project_context tests.phase02.test_phase02_runtime_contracts tests.phase03.test_phase03_pipeline_correctness tests.phase04.test_phase04_system_modules tests.phase05.test_phase05_registry_plugins -v
```

Run the baseline audit:

```bat
venv\Scripts\python.exe scripts\audit\phase00_audit.py --print-known-issues
```

Generate optional diagnostic registry reports:

```bat
venv\Scripts\python.exe scripts\diagnostics\sampler_map.py
venv\Scripts\python.exe scripts\diagnostics\scheduler_map.py
```

## Validation Result

```text
Phase 05 focused tests:       10 passed
Phase 00-05 focused total:    50 passed
Active-source compilation:    PASS
Internal import validation:   PASS
Fake generation baseline:     PASS
Failure-stage ownership:      PASS
Sampler diagnostic report:    PASS
Scheduler diagnostic report:  PASS
```

## Exit Criteria

- [x] A canonical plugin descriptor schema exists.
- [x] Discovery roots come from project/package context rather than the process CWD.
- [x] Stable IDs, names, labels, aliases, adapter classes, capabilities, and schemas are required.
- [x] Duplicate identities are rejected with actionable messages.
- [x] Adapter protocol compatibility is validated during registration.
- [x] KES, Simple Euler, and DPM++ 2M use the same sampler mechanism.
- [x] Simple KES uses the same scheduler mechanism.
- [x] Generated Python registry maps are not runtime dependencies.
- [x] Registry construction occurs once per runtime-session registry system.
- [x] Sampler/scheduler capabilities are checked before generation.
- [x] Adding a descriptor-bearing sampler or scheduler does not require changing the generation pipeline.

## Deferred Work

Phase 06 owns structured run diagnostics, per-stage timing, failure bundles, and formal test tiers. Phase 05 reports registry failures precisely, but it does not yet introduce a general structured logging system.

No real checkpoint was included, so this phase does not claim real-model generation or image-quality validation.
