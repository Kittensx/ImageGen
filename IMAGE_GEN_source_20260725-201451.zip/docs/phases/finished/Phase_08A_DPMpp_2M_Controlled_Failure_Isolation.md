# Phase 08A - DPM++ 2M Controlled Failure Isolation

## Status

**Implementation complete:** 2026-07-25  
**Real-checkpoint matrix:** ready for Joel's local run

Phase 08A does not attempt to tune DPM++ 2M by visual guesswork. It creates a controlled matrix that holds the checkpoint, prompt, seed, dimensions, step count, CFG scale, and scheduler family constant while changing only the schedule domain and DPM solver precision.

No normal generation default is changed by this phase.

## Objective

Determine whether the DPM++ 2M failure is primarily caused by:

1. the native Simple KES sigma/timestep schedule;
2. float16 multistep solver mathematics;
3. the interaction of both factors; or
4. an additional defect that remains after both factors are controlled.

The matrix also runs every registered sampler sequentially through the same Simple KES scheduler so current and future sampler behavior can be compared under one reproducible harness.

## Sequential Run Matrix

For every configured prompt case, the launcher runs these registered sampler baselines first:

1. `simple_euler` with the native Simple KES schedule;
2. `kes` with the native Simple KES schedule;
3. `dpmpp_2m` with the native Simple KES schedule and latent/model precision;
4. any additional registered sampler discovered later, using its native configuration.

DPM++ 2M then receives the controlled isolation variants:

| Variant | Schedule | Solver state | Purpose |
|---|---|---|---|
| A | native Simple KES | latent dtype | reproduce the current failure condition |
| B | model-bounded plain Karras | latent dtype | isolate schedule-domain effects |
| C | native Simple KES | float32 | isolate solver-precision effects |
| D | model-bounded plain Karras | float32 | test the combined corrective baseline |

Variant A is the normal registered DPM++ 2M baseline and is not run twice.

## Prompt Cases

The default case file is:

```text
scripts/validation/profiles/phase08a_cases.json
```

It contains the three requests reconstructed from the supplied sampler test manifests:

- dog playing poker;
- cat sitting on a table in afternoon sunlight;
- sunset, lake, mountains, clouds, and reflection.

Every sampler and DPM variant receives every case with the same prompt, negative prompt, seed, dimensions, steps, and CFG scale.

## Validation-Only Scheduler Bridge

The Phase 8A scheduler wrapper is:

```text
scripts/validation/phase08a_support.py
```

It always calls the real `SimpleKESSchedulerAdapter` first.

### Native mode

Native mode passes the real Simple KES schedule through unchanged and adds a diagnostic snapshot containing:

- complete sigma values;
- complete timestep values;
- monotonicity status;
- positive-sigma clipping counts;
- duplicated positive timestep count;
- training sigma bounds reported by the scheduler.

### Model-bounded Karras mode

The bounded mode preserves the native result as the candidate schedule, then creates the execution schedule with:

- one strictly decreasing positive Karras sigma per requested step;
- sigma minimum and maximum clamped to the scheduler-reconstructed SD1 training range;
- exactly one terminal zero;
- timesteps recomputed through the current Simple KES SD1 sigma-to-timestep mapper;
- no KES step-size/noise-scale multiplication;
- no tail expansion, decay tail, blended tail, or stabilization steps.

Both the candidate and execution schedules are written into the report. This prevents the diagnostic bridge from hiding what the production scheduler originally produced.

## DPM++ 2M Precision Isolation

The DPM++ 2M sampler now accepts:

```json
{
  "solver_dtype": "latent"
}
```

Supported values are:

- `latent` - existing behavior and the unchanged default;
- `float16` - explicit float16 solver state;
- `float32` - float32 solver state for Phase 8A isolation.

In float32 mode:

1. the persistent DPM latent state is float32;
2. epsilon-to-denoised conversion is float32;
3. logarithms, `expm1`, step ratios, and multistep history are float32;
4. each UNet call still receives latents and conditioning in the original model input dtype;
5. final sampler latents are converted back to the original model input dtype before decode.

This isolates solver arithmetic without requiring the float16 checkpoint modules to accept float32 inputs.

## Per-Step DPM Evidence

When sampler tracing is enabled, every DPM step records:

- sigma and next sigma;
- model timestep;
- latent norm before and after the update;
- epsilon norm and min/max/mean/std;
- denoised/x0 norm and min/max/mean/std;
- `t`, `t_next`, `h`, `h_last`, and `r` where applicable;
- whether prior denoised history was used;
- model input dtype and solver dtype.

The launcher exports JSON, CSV, and text trace artifacts for each run.

## Launcher

Windows launcher:

```bat
phase08a_sampler_matrix.bat --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors"
```

One-case smoke matrix:

```bat
phase08a_sampler_matrix.bat ^
  --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors" ^
  --case-limit 1
```

List the samplers that will be discovered:

```bat
phase08a_sampler_matrix.bat --list-samplers
```

Run only selected samplers:

```bat
phase08a_sampler_matrix.bat ^
  --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors" ^
  --samplers simple_euler kes dpmpp_2m
```

Direct Python command:

```bat
venv\Scripts\python.exe scripts\validation\phase08a_sampler_matrix.py ^
  --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors"
```

## Output Layout

The default output root is:

```text
artifacts/phase08a_sampler_matrix/<timestamp>/
```

It contains:

```text
phase08a_sampler_matrix_report.json
phase08a_sampler_matrix_report.md
runs/
  <order>_<variant>/
    <case>/
      images/
      trace/
```

The report is rewritten after every attempted run, so completed evidence survives a later failure or interruption.

## Report Interpretation

For each prompt case:

1. compare A against B to identify the effect of replacing the native schedule;
2. compare A against C to identify the effect of float32 solver arithmetic;
3. compare A against D to identify the combined effect;
4. compare all four DPM images against Simple Euler and KES for semantic coherence.

Expected diagnostic patterns:

- **B improves substantially:** schedule/timestep mismatch is the dominant cause;
- **C improves substantially:** float16 multistep arithmetic is the dominant cause;
- **D improves while B and C only partly improve:** both causes interact;
- **D remains semantically wrong:** Phase 8B must investigate denoised prediction conversion, model scaling, history handling, or conditioning discontinuities before changing the DPM equation.

Technical completion only means that every requested run completed and produced evidence. Image quality remains a manual acceptance gate.

## Focused Tests

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py phase08a
```

The model-free tests verify:

- sequential variant construction includes all registered samplers;
- DPM A/B/C/D are generated in the intended order;
- bounded Karras stays inside the model sigma range;
- candidate and execution schedules remain separately visible;
- positive clipping and duplicated timestep analysis works;
- float32 DPM state does not change the UNet/model input dtype;
- DPM returns latents in the original decode-compatible dtype;
- extended per-step evidence is captured when tracing is enabled.

## Exit Criteria

Phase 08A implementation is complete when:

- the launcher and case profile exist;
- every registered sampler can be sequenced through the current scheduler;
- DPM A/B/C/D can run without changing production defaults;
- reports and step traces preserve enough evidence to choose the Phase 8B repair;
- model-free focused tests pass.

The real-checkpoint acceptance gate completes after the local matrix is run and the images and report are reviewed.
