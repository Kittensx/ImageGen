# Phase 04 - System Module Extraction

## Status

**Implementation complete:** 2026-07-25

Phase 04 extracts the repaired Phase 03 generation path into independent Python systems. The project remains Python-based; no Avalonia or replacement desktop framework was introduced.

## Objective

Extract pipeline responsibilities into replaceable systems while preserving the current generation contracts and old import paths.

## Implemented Package Structure

```text
image_gen/                         source-tree import bridge
src/image_gen/
|-- contracts/
|-- runtime/
`-- systems/
    |-- configuration/
    |-- model_loading/
    |-- conditioning/
    |-- scheduling/
    |-- denoising/
    |-- sampling/
    |-- decoding/
    |-- output/
    |-- registry/
    `-- diagnostics/
```

The small root `image_gen/__init__.py` bridge makes the `src/image_gen` package importable when the uninstalled project is run directly from its root. The canonical implementations remain under `src/image_gen`.

## Implemented Work

1. Moved the canonical request, result, scheduler, sampler, compatibility, and adapter protocol definitions to `src/image_gen/contracts/`.
2. Converted `modules/contracts/` into identity-preserving compatibility facades.
3. Extracted prompt adapter execution into `ConditioningSystem`.
4. Extracted scheduler adapter execution and schedule validation into `SchedulingSystem`.
5. Extracted deterministic latent creation into `LatentPreparationSystem`.
6. Extracted canonical raw and guided UNet callbacks into `DenoisingSystem`.
7. Extracted sampler invocation and latent-output validation into `SamplingSystem`.
8. Extracted VAE tensor normalization into `DecodingSystem`.
9. Added `DiagnosticsSystem` for the optional trace lifecycle.
10. Added `ModelLoadingSystem`, preserving the existing `LoadModel.prepare_load_plan()` then `build_components_from_plan()` order.
11. Added `RuntimeRegistrySystem` to resolve already-discovered entries and construct adapters without placing registry logic in the generation runtime.
12. Added `OutputSystem` as the explicit persistence boundary for images and sidecars.
13. Added `GenerationSystems`, `PipelineCompositionRoot`, and `GenerationPipeline`.
14. Reduced generation orchestration to ordered system calls.
15. Reduced `Txt2ImgRunner` to a use-case coordinator for validation, registry resolution, model loading, generation, manifest construction, and optional output.
16. Replaced `modules/pipeline_builder.py` and `modules/txt2img/txt2img_runner.py` with compatibility facades.
17. Updated the Phase 00 audit so the `image_gen` source-layout package participates in active-source and internal-import validation.
18. Updated Pipegen's `.image-gen-include` so `src/` and the root `image_gen/` bridge are retained in source packages.

## System Ownership

| System | Owns | Does not own |
|---|---|---|
| configuration | project context and generation defaults | inference or file writing |
| model loading | load plan and component construction | prompts, samplers, output |
| conditioning | prompt adapter boundary | denoising or integration |
| scheduling | scheduler adapter and schedule validation | model calls |
| latent preparation | seed-controlled initial noise | denoising |
| denoising | UNet input scaling, raw prediction, CFG prediction | sampler integration |
| sampling | sampler adapter invocation and output validation | checkpoint loading or saving |
| decoding | VAE latent-to-image tensor conversion | filenames or manifests |
| diagnostics | optional trace session lifecycle | normal inference behavior |
| registry | entry lookup and adapter construction | generation order |
| output | image and sidecar persistence | inference math |
| runtime | ordered composition of systems | subsystem implementation details |

## Canonical Generation Order

```text
ConditioningSystem.encode
  -> SchedulingSystem.build
  -> DiagnosticsSystem.start
  -> LatentPreparationSystem.prepare
  -> SamplingSystem.sample
       -> DenoisingSystem.predict_raw_noise / predict_guided_noise
  -> DiagnosticsSystem.finish
  -> DecodingSystem.decode
  -> GenerationResult
```

`GenerationPipeline` does not scan registries and does not write files. Registry and output systems are only used by the higher-level txt2img use case.

## Compatibility Surface

These historical imports remain functional:

```python
from modules.contracts import GenerationRequest
from modules.pipeline_builder import CustomSDPipeline, PipelineBuilder
from modules.pipeline.pipeline_builder import CustomSDPipeline
from modules.txt2img.txt2img_runner import Txt2ImgRunner
```

They resolve to the canonical Phase 04 implementations rather than duplicate classes.

## Focused Tests

Run Phase 04:

```bat
venv\Scripts\python.exe -m unittest tests.phase04.test_phase04_system_modules -v
```

Run Phases 00-04 focused regression coverage:

```bat
venv\Scripts\python.exe -m unittest tests.phase00.test_phase00_baseline tests.phase01.test_phase01_project_context tests.phase02.test_phase02_runtime_contracts tests.phase03.test_phase03_pipeline_correctness tests.phase04.test_phase04_system_modules -v
```

Run the audit:

```bat
venv\Scripts\python.exe scripts\audit\phase00_audit.py --print-known-issues
```

## Validation Result

```text
Phase 04 focused tests:      10 passed
Phase 00-04 focused total:   40 passed
Active-source compilation:   PASS
Internal import validation:  PASS
Fake pipeline baseline:      PASS
Failure-stage ownership:     PASS
```

## Exit Criteria

- [x] Canonical contracts live under `src/image_gen/contracts`.
- [x] Each target responsibility has a named system boundary.
- [x] The runtime pipeline contains ordered system calls rather than denoising, decoding, registry, and output implementations.
- [x] The composition root can replace every generation system with a fake or proxy.
- [x] Old import paths remain identity-compatible.
- [x] Core generation runs without registry scanning or file output.
- [x] `Txt2ImgRunner` coordinates systems rather than implementing their internals.

## Deferred Work

Phase 04 intentionally does not redesign plugin discovery metadata or versioning. The existing sampler and scheduler scanners still produce runtime maps; Phase 05 owns the formal registry/plugin architecture.

A compatible real Stable Diffusion checkpoint was not included. No real-model image-quality or checkpoint-compatibility claim is made by this phase.
