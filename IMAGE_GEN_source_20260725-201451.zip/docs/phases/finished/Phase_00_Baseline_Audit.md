# Phase 00 - Baseline Audit and Reproducible Failure Capture

## Objective

Create a trustworthy snapshot of the current IMAGE_GEN pipeline and make every failure reproducible before runtime behavior is changed.

## Scope

- identify the canonical current execution path
- classify active, legacy, experimental, generated, and broken files
- compile active Python files
- inspect internal imports
- map runtime dependencies between modules
- create a fake-component pipeline harness
- capture current errors by stage

## Required Work

1. Record the current intended pipeline from CLI through output.
2. Mark `app/run.py` and `modules/generation_test.py` as legacy/placeholder until repaired.
3. Exclude documentation experiments from active-source compilation.
4. Decide whether `sampler_advanced.py` is an active feature or an archived experiment.
5. Add a test-only fake tokenizer, text encoder, UNet, scheduler, sampler, and VAE.
6. Add a command that runs static checks and fake-pipeline checks without a model.
7. Produce a machine-readable audit report.

## Focused Tests

- active source compiles
- all active internal imports resolve
- fake request reaches a fake decoded image
- each stage can be intentionally failed and correctly identified

## Exit Criteria

- one command reproduces the current pipeline baseline
- known failures are documented with file and system ownership
- no production code has been moved yet


## Implementation Status

**Complete - 2026-07-25**

Implemented deliverables:

- canonical current pipeline map in `docs/architecture/CURRENT_PIPELINE_BASELINE.md`
- source classification and known-failure report in `docs/audits/Phase_00_Baseline_Audit_Report.md`
- machine-readable report generator at `scripts/audit/phase00_audit.py`
- report schema at `docs/audits/phase00_audit_report_schema.json`
- root Windows launcher `phase00_audit.bat`
- fake tokenizer, text encoder, UNet, scheduler, sampler, and VAE under `tests/phase00/`
- deterministic fake-pipeline and stage-failure tests

Validation performed:

```text
python scripts/audit/phase00_audit.py --print-known-issues
python -m unittest tests.phase00.test_phase00_baseline -v
```

Results:

- active Python source compilation: passed
- no unapproved active internal-import gaps: passed
- fake request reached a decoded image tensor: passed
- all injected failures identified the requested stage and owner: passed
- focused unit tests: 2 passed

Two guarded imports to `modules.pipeline.pipeline_builder` remain explicitly approved baseline gaps and are assigned to Phase 02. No production source was moved, and no real checkpoint was loaded.

## Post-Phase Baseline Stabilization - 2026-07-25

Before beginning Phase 07, the remaining baseline inventory defects were repaired without changing the active image-generation algorithms:

- `modules/generation_test.py` is now a compatibility launcher for the canonical checkpoint smoke test;
- the archived `sampler_advanced.py` helper is valid, consistently indented Python but remains unregistered;
- `docs/ideas/more_mem_optim.py` is UTF-8 and syntax-valid experimental documentation;
- the missing `src/image_gen/systems/output/` package was restored;
- the audit now prints the exact active syntax or import blockers instead of only a generic failed gate.

See `docs/audits/Phase_00_Baseline_Stabilization_Report.md`.
