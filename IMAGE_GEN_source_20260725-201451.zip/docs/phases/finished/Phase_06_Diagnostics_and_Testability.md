# Phase 06 - Diagnostics and Testability

## Status

**Implementation complete:** 2026-07-25

Phase 06 makes troubleshooting a first-class system without changing the sampler, scheduler, prompt, or model contracts established in Phases 02-05.

## Objective

Make failures easy to isolate, preserve enough context to reproduce them, and keep successful normal runs readable.

## Canonical Diagnostics Package

```text
src/image_gen/systems/diagnostics/
|-- failure_bundle.py
|-- models.py
|-- serialization.py
|-- system.py
`-- __init__.py
```

### Responsibilities

- `DiagnosticConfig` owns verbosity, artifact, tensor, progress, trace, and failure-bundle policy.
- `DiagnosticSession` owns one run ID and all events, timings, summaries, and reports for that run.
- `DiagnosticEvent` records run ID, severity, system, operation, timestamp, elapsed time, message, and structured details.
- `DiagnosticsSystem` wraps each system operation, records results, and assigns failures.
- `PipelineStageError` exposes the failing system, operation, run ID, original error, and failure-bundle path.
- `write_failure_bundle()` creates a sanitized reproduction package outside source folders.

## Structured Event Contract

Every diagnostic event contains:

```text
sequence
timestamp_utc
elapsed_ms
run_id
severity
system
operation
message
details
```

Console output uses stable key-value fields:

```text
[INFO] run_id=<id> system=conditioning operation=encode message="stage completed" duration_ms=...
```

Successful default runs emit warnings and errors only. `verbose` emits completed stages. `trace` also exports successful-run event files automatically.

## System Ownership

The canonical pipeline now records these named operations:

| System | Operation |
|---|---|
| `conditioning` | `encode` |
| `scheduling` | `build` |
| `latent_preparation` | `prepare` |
| `denoising` | `predict_raw_noise` / `predict_guided_noise` |
| `sampling` | `sample` |
| `decoding` | `decode` |
| `runtime` | `result_validation` |
| `configuration` | `validate_generation_paths` |
| `registry` | `resolve_plugins` |
| `model_loading` | `load_tokenizer` / `load_checkpoint` |
| `runtime` | `compose_pipeline` |
| `output` | `build_manifest` / `save` |

A nested denoising failure remains assigned to `denoising`; the outer sampling stage does not replace it with a generic sampler error.

## Per-Stage Timings

Each operation records:

```text
system
operation
occurrence
status
duration_ms
```

Repeated UNet calls use occurrence numbers rather than overwriting one another. Timings are attached to the generation result under:

```text
result.metadata["diagnostics"]["timings"]
```

## Tensor Summaries

Tensor diagnostics are opt-in and never include full tensor contents.

Base summary:

```text
shape
dtype
device
requires_grad
numel
```

Optional statistics:

```text
finite
finite_count
min
max
mean
std
norm
```

Summaries are collected for conditioning tensors, sigma/timestep schedules, initial latents, sampler output latents, and decoded images.

## Sampler Step Traces

The existing `StepTraceRecorder` remains the sampler-facing implementation. Phase 06 moves its default output to:

```text
artifacts/diagnostics/traces/<run_id>/
```

Trace recording is disabled by default. All built-in samplers continue to read the injected `trace_recorder` through their existing trace mixin.

If a configured trace path points into `src/`, `modules/`, `tests/`, `docs/`, `app/`, or the source-tree `image_gen/` bridge, diagnostics relocate the trace to the artifact root and issue a warning.

## Failure Bundle

Failure bundles are enabled by default and written to:

```text
artifacts/diagnostics/failures/<run_id>_<system>_<operation>/
```

Each bundle contains:

```text
failure.json
request.json
request_extras.json
effective_config.json
components.json
schedule.json
sampler.json
timings.json
tensor_summaries.json
events.jsonl
traceback.txt
reproduction_request.json
reproduce_command.txt
```

Passwords, secrets, tokens, and API-key-like fields are redacted. Tensors and live runtime objects are summarized rather than serialized.

`reproduction_request.json` combines the effective generation request with portable request extras such as the model path. `reproduce_command.txt` supplies a Windows command that runs the bundle through the canonical CLI with verbose diagnostics.

## Configuration

Canonical defaults are under `user_config/user-config.yml`:

```yaml
diagnostics:
  verbosity: "normal"
  failure_bundles: true
  export_events: false
  tensor_summaries: false
  tensor_statistics: false
  progress: true
  sampler_trace:
    enabled: false
    export_json: true
    export_csv: false
    export_txt_summary: true
    capture_latents: false
    capture_latent_every_n: 0
```

The artifact root is a canonical project path:

```yaml
paths:
  diagnostics_dir: "artifacts/diagnostics"
```

Per-request diagnostics are supported in YAML/JSON request files through the `diagnostics` object.

## CLI Controls

```bat
venv\Scripts\python.exe -m modules.txt2img.cli run ^
  --diagnostics verbose ^
  --export-diagnostic-events ^
  --tensor-summaries ^
  --sampler-trace
```

Additional controls:

```text
--diagnostics quiet|normal|verbose|trace
--diagnostics-dir PATH
--tensor-statistics
--no-failure-bundle
--no-progress
```

## Test Tiers

A single tier runner is available:

```bat
phase06_tests.bat static
phase06_tests.bat unit
phase06_tests.bat contract
phase06_tests.bat integration
phase06_tests.bat focused
```

Equivalent direct commands:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py static
venv\Scripts\python.exe scripts\tests\run_test_tier.py unit
venv\Scripts\python.exe scripts\tests\run_test_tier.py contract
venv\Scripts\python.exe scripts\tests\run_test_tier.py integration
venv\Scripts\python.exe scripts\tests\run_test_tier.py focused
```

A real-checkpoint smoke command exists but is never run implicitly:

```bat
phase06_tests.bat checkpoint --model "models\StableDiffusion\CheckPoints\model.safetensors"
```

The checkpoint tier uses a fixed seed, two steps, 64 x 64 dimensions, `simple_euler`, and `simple_kes`. Formal image-quality and reproducibility work remains Phase 07.

## Deterministic Fake Systems

`tests/fakes/deterministic_systems.py` supplies:

- deterministic fake components and requests;
- replaceable intentional-failure proxies;
- a wrong-shape decoding system for runtime-validation failures;
- a trace-aware fake sampler;
- a standard fake pipeline builder using the production composition root.

These fakes exercise the real runtime orchestration without requiring a checkpoint or downloading assets.

## Focused Tests

```bat
venv\Scripts\python.exe -m unittest tests.phase06.test_phase06_diagnostics -v
```

Coverage includes:

- intentional failure assignment for every generation stage;
- failure-bundle creation and contents;
- quiet successful normal run;
- verbose structured events;
- per-stage timing records;
- configurable tensor summaries;
- trace disabled by default;
- opt-in sampler trace export;
- explicit failure-bundle disablement.

## Validation Result

```text
Phase 06 focused tests:       6 passed
Phase 00-06 focused total:   56 passed
Active-source compilation:    PASS
Internal import validation:   PASS
Fake generation baseline:     PASS
Intentional stage failures:   PASS
Failure-bundle reproduction:  PASS
Quiet normal run:             PASS
Verbose diagnostic run:       PASS
Sampler trace default off:    PASS
```

The supplied Phase 06 source archive again omitted `src/image_gen/systems/output/`, although the canonical runner and Phase 04 tests require it. The documented Phase 04 output system was restored unchanged before running regression coverage.

## Exit Criteria

- [x] Structured events include run ID, system, operation, and severity.
- [x] Every generation and use-case operation can be timed independently.
- [x] Tensor diagnostics are configurable and never dump full tensors.
- [x] Sampler traces remain optional and are disabled by default.
- [x] Failure bundles include effective configuration, request, components, schedule, sampler, timings, events, and traceback.
- [x] Failure bundles include a reproduction request and command.
- [x] Failures are assigned to a named system and operation.
- [x] Successful normal runs remain quiet.
- [x] Successful verbose runs expose stage progress and timings.
- [x] Static, unit, contract, integration, focused, and checkpoint-smoke commands exist.
- [x] Deterministic fake systems support local and CI execution.
- [x] Diagnostic artifacts are outside source folders and excluded from source packages.

## Deferred Work

Phase 07 owns validation with a known real Stable Diffusion 1.x checkpoint, fixed golden metadata, load coverage, schedule review, latent statistics, decode validation, sampler comparison, and output reproducibility.

No compatible checkpoint was included with this phase, so no real-model generation or image-quality claim is made.
