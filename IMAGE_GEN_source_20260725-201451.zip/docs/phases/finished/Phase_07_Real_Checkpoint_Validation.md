# Phase 07 - Real Checkpoint Validation

## Status

**Implementation complete:** 2026-07-25  
**Real-checkpoint acceptance gate:** completed locally by Joel on 2026-07-25

Phase 07 provides a controlled, repeatable validation system for one Stable Diffusion 1.x checkpoint. Joel completed the local real-checkpoint validation and confirmed that the complete pipeline produced valid images. Follow-up multi-prompt sampler testing then showed that Simple Euler and KES were usable while DPM++ 2M required a dedicated correctness investigation, now tracked as Phase 08A.

## Objective

Prove the stabilized pipeline with controlled real checkpoints, one architecture at a time.

The first and only enabled validation target is SD1.x. SD2 and SDXL are explicitly blocked rather than being inferred from the presence of local configuration files.

## Canonical Validation Package

```text
src/image_gen/systems/validation/
|-- capabilities.py
|-- metrics.py
|-- models.py
|-- system.py
`-- __init__.py
```

Responsibilities:

- `capabilities.py` declares explicit architecture support status.
- `metrics.py` produces tensor digests, statistics, reproducibility comparisons, and sampler-comparison metrics.
- `models.py` defines the validation profile, checks, run records, architecture capability, and final report.
- `system.py` owns checkpoint preflight, tokenizer evidence, component coverage, run evidence, comparisons, acceptance checks, and report writing.

## Fixed SD1 Validation Profile

The default profile is:

```text
Prompt:             a small red ceramic teapot on a plain wooden table, studio light
Negative prompt:    blurry, distorted, low resolution
Seed:               707
Steps:              12
Dimensions:         256 x 256
CFG:                7.0
Scheduler:          simple_kes
Baseline sampler:   simple_euler
Comparison sampler: kes
Batch size:         1
Sigma range:        0.03 to 14.0
Reproducibility:    atol=1e-5, rtol=1e-5
```

The sigma range is intentionally kept inside the reconstructed SD1 training range so the validation profile does not begin with known high-sigma clipping.

## Checkpoint Inspection

`CheckpointInspector.inspect()` no longer materializes every checkpoint tensor merely to inspect the file. It reads the safetensors header and records:

- file size;
- SHA-256 fingerprint;
- tensor key count;
- key prefixes and examples;
- dtype counts;
- selected tensor shapes;
- embedded safetensors metadata;
- architecture evidence;
- full/partial/LoRA checkpoint classification.

Architecture detection now uses text-embedding and UNet cross-attention dimensions:

- `768` identifies SD1-style conditioning;
- `1024` identifies SD2-style conditioning;
- dual conditioner/text-encoder keys or `2048` identify SDXL;
- unresolved SD1/SD2 files are blocked instead of being silently treated as SD1.

The full state dictionary is loaded only after the checkpoint has passed the architecture capability gate.

## Architecture Capability Status

| Architecture | Status | Generation | Phase 07 validation |
|---|---|---:|---:|
| SD1.x | validation target | enabled | enabled |
| SD2.x | blocked | disabled | disabled |
| SDXL | blocked | disabled | disabled |
| unresolved/unknown | unsupported | disabled | disabled |

SD2 remains blocked until the runtime has an explicit OpenCLIP tokenizer/text-encoder path and verified 1024-wide conditioning.

SDXL remains blocked until dual text encoders, pooled conditioning, added time IDs, and the SDXL UNet call contract are implemented.

## Component Loading Coverage

UNet, text encoder, and VAE load results now record:

```text
provided_keys
expected_keys
matched_keys
coverage_ratio
missing_key_count
unexpected_key_count
missing_key_samples
unexpected_key_samples
```

The Phase 07 acceptance threshold is at least 95 percent matched key coverage for all three components, with each component reporting a successful load.

This threshold does not hide missing or unexpected keys. The full counts and representative samples are written into the JSON report.

## Tokenizer Validation

The local tokenizer is loaded with `local_files_only=True` and tested with the profile prompt, negative prompt, a short prompt, and an empty prompt.

The report records:

- tokenizer class;
- vocabulary size;
- model maximum length;
- special token IDs;
- token batch shape;
- non-padding token count;
- deterministic token-ID digest;
- first token IDs.

The tokenizer check passes only when repeated tokenization is deterministic and every result has the expected 77-token width.

## Controlled Real Runs

The launcher performs three runs while reusing the loaded checkpoint components:

1. `simple_euler` baseline;
2. the identical `simple_euler` request again;
3. `kes` under the same fixed request and scheduler profile.

Mutable `SharedState` is reset between requests so repeatability is not accidentally dependent on state left by the prior run. The loaded checkpoint cache is retained for the three-run validation session and invalidates when the checkpoint path, size, modification time, device, or dtype changes.

The output system now honors `request.output_prefix`, allowing the validation images to be identified independently.

## Evidence Recorded Per Run

Each run records:

- run ID and generation time;
- sampler and scheduler;
- conditioning shape, dtype, device, and statistics;
- complete sigma and timestep sequences;
- initial latent statistics from diagnostics;
- final latent statistics and digest;
- decoded image shape, range, statistics, and digest;
- sampler metadata;
- diagnostic timings and warnings;
- saved image paths.

## Reproducibility

The repeated baseline run compares both final latents and decoded images.

The report includes:

```text
shape equality
exact digest equality
materially equivalent result
maximum absolute difference
mean absolute difference
RMSE
cosine similarity
absolute and relative tolerance
metadata equality
```

A real validation PASS requires materially equivalent baseline latents and images under the fixed seed.

## Sampler Comparison

The KES run is compared against the baseline using the same tensor metrics. Equality is not expected and is not an acceptance requirement. The comparison exists to prove both sampler paths complete and to preserve objective evidence for later tuning.

## Validation Reports

The default output directory is:

```text
artifacts/phase07_validation/<timestamp>/
```

It contains:

```text
phase07_preflight.json
phase07_validation_report.json
phase07_validation_report.md
images/baseline/
images/kes/
```

A preflight or runtime exception writes:

```text
phase07_preflight_failure.json
```

Phase 06 diagnostic failure bundles remain active for named pipeline-stage failures.

## Windows Commands

Display architecture capability status:

```bat
phase07_validate.bat --capabilities
```

Run checkpoint and tokenizer preflight only:

```bat
phase07_validate.bat ^
  --model "models\StableDiffusion\CheckPoints\goldenLegends_v10.safetensors" ^
  --preflight-only
```

Run the complete controlled validation:

```bat
phase07_validate.bat ^
  --model "models\StableDiffusion\CheckPoints\goldenLegends_v10.safetensors"
```

Use a different output directory:

```bat
phase07_validate.bat ^
  --model "models\StableDiffusion\CheckPoints\goldenLegends_v10.safetensors" ^
  --output-dir "artifacts\phase07_validation\golden_legends"
```

Direct Python command:

```bat
venv\Scripts\python.exe scripts\validation\phase07_validate.py ^
  --model "models\StableDiffusion\CheckPoints\goldenLegends_v10.safetensors"
```

Focused Phase 07 tests:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py phase07
```

Focused regression tests through Phase 07:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py focused
```

## Implemented Acceptance Checks

- `checkpoint.full_sd1`
- `tokenizer.local_deterministic`
- `components.coverage`
- `conditioning.sd1_contract`
- `schedule.valid`
- `decode.valid`
- `reproducibility.fixed_seed`
- `samplers.executed`

## Validation Completed Without a Checkpoint

```text
Phase 07 focused tests:       5 passed
Phase 00-07 focused total:   65 passed
Active-source compilation:    PASS
Internal import validation:   PASS
Fake generation baseline:     PASS
Intentional stage failures:   PASS
Checkpoint header detection:  PASS
Capability gates:             PASS
Report/reproducibility logic: PASS
```

The supplied source archive again omitted `src/image_gen/systems/output/`, although existing tests and the canonical runner require it. The documented Phase 04 output system was restored unchanged except that it now honors the request output prefix.

## Exit Criteria

Implementation gates:

- [x] Record checkpoint fingerprint and architecture evidence.
- [x] Record component key loading coverage.
- [x] Validate local tokenizer behavior.
- [x] Validate conditioning shape and dtype.
- [x] Record sigma and timestep sequences.
- [x] Record controlled latent statistics.
- [x] Validate VAE output range and shape.
- [x] Compare KES and baseline samplers under fixed conditions.
- [x] Verify fixed-seed reproducibility through explicit metrics.
- [x] Define explicit architecture capability status.
- [x] Add focused model-free tests for the validation system.

Real-checkpoint acceptance gates:

- [ ] A fixed SD1 request produces a valid image without contract warnings.
- [ ] Repeating the same SD1 request produces materially equivalent output.
- [ ] UNet, text encoder, and VAE each meet the 95 percent coverage threshold.
- [ ] Both Simple Euler and KES complete under the fixed profile.

These four gates remain pending because no checkpoint was included in the source ZIP. Phase 08 should not remove compatibility or diagnostic code until the local Phase 07 report has been reviewed.
