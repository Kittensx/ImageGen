# Legacy Phase 08 Reference - Cleanup Moved to Phase 09

The original Phase 08 cleanup work was deferred after real sampler testing exposed a DPM++ 2M correctness issue.

The active sequence is now:

1. Phase 08A - controlled DPM++ 2M failure isolation;
2. Phase 08B - sampler schedule bridge and corrective implementation selected from Phase 08A evidence;
3. Phase 08C - canonical denoised prediction and float32 multistep solver core;
4. Phase 08D - reference parity and real-checkpoint acceptance;
5. Phase 09 - cleanup and upgrade readiness.

Use:

```text
docs/phases/Phase_08A_DPMpp_2M_Controlled_Failure_Isolation.md
docs/phases/Phase_09_Cleanup_and_Upgrade_Readiness.md
```
