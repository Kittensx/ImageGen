# Phase 09 - Cleanup and Upgrade Readiness

## Objective

Remove migration debris and make future upgrades predictable after sampler correctness is established.

## Required Work

1. Retire obsolete launchers and placeholder tests.
2. Move experimental scripts out of production packages.
3. Remove syntax-invalid files from active source.
4. Remove duplicate contracts and image savers.
5. Remove unused remote-backed conditioning imports.
6. Correct dependency declarations and environment setup.
7. Add package initialization where required.
8. Document sampler, scheduler, architecture, and interface extension procedures.
9. Document the KES raw-CFG and baseline guided-CFG architecture decision.
10. Add an upgrade checklist for Torch, Diffusers, Transformers, and Safetensors.

## Focused Tests

- clean source compilation;
- clean active import scan;
- packaging excludes runtime artifacts and models;
- example plugin guide validation.

## Exit Criteria

- no known broken file remains in an active runtime package;
- upgrade and extension guides match the actual code paths;
- the project is ready for a future CLI, web, or desktop interface without coupling the UI to inference internals.
