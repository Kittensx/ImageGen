# Phase 01 - Entrypoint, Configuration, and Project Context

## Objective

Establish one supported launcher and one authority for all project paths and configuration values.

## Required Work

1. Make `modules.txt2img.cli` the canonical runtime entry.
2. Update `run.bat` to invoke the canonical runtime or retire it in favor of one clearly named launcher.
3. Convert `app/run.py` into a compatibility redirect or archive it.
4. Define the canonical user configuration file and migrate existing settings.
5. Introduce `ProjectContext` containing project root, model roots, data root, output root, tokenizer root, cache root, and temporary root.
6. Remove path discovery based on `os.getcwd()`.
7. Remove unrelated directory creation from configuration constructors.
8. Add `config show` and `config validate` CLI operations.

## Focused Tests

- launch from the project root
- launch from another working directory
- load the same effective configuration in both cases
- detect missing model/tokenizer/output directories before generation

## Exit Criteria

- one launcher is documented and supported
- configuration is actually loaded from the visible user configuration file
- all systems receive paths through project context

## Implementation Status

**Complete - 2026-07-25**

Implemented deliverables:

- canonical interactive launcher at `run.bat`
- compatibility launcher at `run_cli.bat`, using the same CLI runtime
- compatibility redirect at `app/run.py`
- authoritative `ProjectContext` in `modules/project_context.py`
- canonical visible configuration at `user_config/user-config.yml`
- read-only `ConfigOptions` compatibility facade
- project-context injection into model loading, txt2img runtime, model selection, and sampler/scheduler registries
- working-directory-independent registry discovery
- `config show` and `config validate` CLI operations with text and JSON output
- focused Phase 01 tests under `tests/phase01/`
- architecture guidance in `docs/architecture/PROJECT_CONTEXT_AND_CONFIGURATION.md`
- implementation findings in `docs/audits/Phase_01_Implementation_Report.md`

Validation performed:

```text
python -m unittest tests.phase01.test_phase01_project_context -v
python -m unittest tests.phase00.test_phase00_baseline -v
python scripts/audit/phase00_audit.py --print-known-issues
```

Results:

- Phase 01 focused tests: 7 passed
- Phase 00 regression tests: 2 passed
- active source compilation: passed
- no unapproved active internal-import gaps
- effective paths and configuration remained identical after changing the process working directory
- missing model, tokenizer, checkpoint, and output paths were detected before generation

No real checkpoint was loaded. Pipeline contract and mathematical correctness repairs remain assigned to Phases 02 and 03.
