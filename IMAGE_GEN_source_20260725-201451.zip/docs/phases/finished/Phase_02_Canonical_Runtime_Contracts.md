# Phase 02 - Canonical Runtime Contracts

## Objective

Replace duplicated and drifting runtime objects with one authoritative contract package.

## Required Contracts

- `GenerationRequest`
- `PipelineComponents`
- `ConditioningOutput`
- `SchedulerOutput`
- `SamplerOutput`
- `GenerationResult`
- `PromptAdapterProtocol`
- `SchedulerAdapterProtocol`
- `SamplerAdapterProtocol`
- `SamplerCapabilities`
- `SchedulerCompatibilityResult`

## Required Decisions

### KES path

- receives raw model prediction callback
- receives sigma and timestep
- resolves or receives step conditioning
- owns cond/uncond mixing and CFG behavior

### Baseline path

- receives guided model callback
- receives sigma and timestep
- uses pipeline-owned CFG
- does not silently interpret KES tail semantics

## Required Work

1. Move contracts out of `pipeline_builder.py`.
2. Remove local `SamplerOutput` redefinitions.
3. Make protocol signatures identical in all imports.
4. Promote requested/effective step information to defined schedule fields or defined typed metadata, not a mixture of both.
5. Add adapter conformance checks during registry registration.
6. Add compatibility imports at old paths during migration.

## Focused Tests

- KES adapter conformance
- Simple Euler adapter conformance
- DPM++ 2M adapter conformance
- schedule serialization and validation
- result serialization without runtime objects

## Exit Criteria

- one source of truth exists for all runtime contracts
- adapter mismatches fail at registration or test time, not halfway through generation

## Implementation Status

**Complete - 2026-07-25**

Implemented deliverables:

- authoritative `modules/contracts/` package
- all required runtime contracts and protocols
- canonical raw and guided denoising callback protocols
- explicit `SamplerCapabilities` CFG ownership declarations
- explicit requested/effective schedule fields
- unified `SchedulerCompatibilityResult`
- registry-time sampler and scheduler adapter validation
- typed `GenerationResult` returned by `CustomSDPipeline`
- compatibility facades at historical import paths
- focused Phase 02 test suite
- architecture guide at `docs/architecture/RUNTIME_CONTRACTS.md`
- implementation report at `docs/audits/Phase_02_Implementation_Report.md`

Validation performed:

```text
python -m unittest tests.phase02.test_phase02_runtime_contracts -v
python -m unittest tests.phase00.test_phase00_baseline tests.phase01.test_phase01_project_context -v
python scripts/audit/phase00_audit.py --print-known-issues
```

Results:

- Phase 02 focused tests: 11 passed
- Phase 00 regression tests: 2 passed
- Phase 01 regression tests: 7 passed
- active source compilation: passed
- no unapproved active internal-import gaps
- live sampler and scheduler registry discovery passed

Phase 02 defines that both callback paths receive sigma and timestep. The existing Simple Euler and DPM++ 2M call sites still omit timestep and remain a documented Phase 03 correctness repair. No real checkpoint was loaded.
