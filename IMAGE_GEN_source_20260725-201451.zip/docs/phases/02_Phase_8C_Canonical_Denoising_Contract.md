# Phase 8C — Establish a Canonical Denoising Contract

## Goal

Move model-output interpretation out of the sampler.

DPM++ 2M must not independently assume every checkpoint predicts epsilon and perform an unverified local conversion.

The denoising layer must return a canonical predicted clean latent.

## Proposed Interface

```python
class Denoiser:
    def predict_model_output(...):
        ...

    def predict_epsilon(...):
        ...

    def predict_denoised(...):
        ...
```

The DPM++ sampler should request:

```python
denoised = denoiser.predict_denoised(
    sample=x,
    sigma=sigma,
    timestep=timestep,
    conditioning=conditioning,
)
```

## Responsibilities of `predict_denoised()`

The denoising layer owns:

- Model-input preconditioning
- Sigma-to-timestep mapping
- Checkpoint prediction type
- Conditional inference
- Unconditional inference
- Classifier-free guidance
- Optional CFG rescaling
- Conversion to predicted x0
- Float32 conversion for solver use

## Prediction Types

Explicitly support:

```text
epsilon
v_prediction
sample / x0
```

The prediction type must be recorded and validated rather than silently assumed.

For epsilon prediction, the canonical conversion may be:

```python
x0 = sample - sigma * epsilon
```

This formula must use:

- The solver-state sample
- The exact sigma used for model evaluation
- The guided epsilon prediction
- The correct preconditioning contract
- Float32 solver math

## Architectural Rule

The sampler must not need to know:

- Which prediction type the checkpoint uses
- How the model input was scaled
- How CFG was calculated
- Whether CFG rescaling occurred
- How sigma maps to a discrete timestep

The sampler should receive only the canonical float32 denoised prediction required by its integration equation.

## Required Tests

Add synthetic unit tests for:

```text
epsilon to x0
v-prediction to x0
x0 output to x0
CFG before conversion
dtype boundaries
sigma consistency
solver-state sample versus model-input sample
conditional and unconditional branch ordering
```

Use known synthetic tensors so the expected predicted-x0 values can be calculated exactly.

## Manifest Requirements

Record:

```text
prediction_type
prediction_conversion
model_input_preconditioning
cfg_scale
cfg_rescale
model_dtype
solver_dtype
sigma_used_for_prediction
model_timestep
```

## Acceptance Gate

Phase 8C passes when:

- The sampler receives a canonical float32 x0 prediction.
- The sampler no longer performs checkpoint-specific output interpretation.
- Synthetic conversion tests pass for every supported prediction type.
- The conversion uses the solver-state sample rather than a preconditioned model input.
- Prediction metadata is written truthfully to the manifest.
