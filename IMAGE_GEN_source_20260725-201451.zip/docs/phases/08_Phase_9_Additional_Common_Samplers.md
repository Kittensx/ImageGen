# Phase 9 — Add Additional Common Samplers

## Entry Requirement

Do not begin Phase 9 until DPM++ 2M passes Phase 8H.

## Goal

Add common sampler families one at a time using the validated infrastructure created during Phase 8.

## Recommended Order

```text
1. Heun
2. Euler ancestral
3. DPM++ 2S ancestral
4. DPM++ 2M SDE
5. DPM++ 3M SDE
```

## Shared Infrastructure

Every new sampler must reuse:

- Canonical denoiser output
- Explicit prediction-type handling
- Float32 solver boundaries where appropriate
- Scheduler metadata
- High-sigma validation
- History validation
- Per-step traces
- Reference-parity tests
- Deterministic acceptance matrices
- Truthful manifest reporting

## Per-Sampler Requirements

Each sampler phase must include:

```text
mathematical reference
production adapter
independent test-local reference
synthetic parity tests
real-checkpoint comparison
fixed prompts and seeds
diagnostic traces
manifest fields
documented defaults
```

## Acceptance Rule

A sampler must not be marked production-ready merely because it completes.

It must:

- Match its canonical reference implementation.
- Produce finite outputs.
- Produce coherent prompt-related images.
- Be deterministic for fixed seeds when the algorithm is deterministic.
- Save images and diagnostics reliably.
- Report its actual schedule and precision behavior.
