# Phase 08 Compatibility Hotfix: KES with Fixed-Step Schedulers

## Purpose

Allow the KES sampler to run against a non-KES scheduler that provides a valid fixed requested-step schedule.

## Negotiation

When the sampler is KES and the scheduler family is not KES:

- step expansion is clamped off;
- KES tail metadata is clamped off;
- the negotiated pipeline mode is `fixed_steps`;
- the scheduler must return exactly the requested number of sigma transitions.

The KES sampler retains its full expanded-step and tail behavior when paired with `simple_kes`. Other sampler/scheduler incompatibilities remain strict.

## Metadata

The registry, schedule, and sampler outputs record the negotiated mode and both clamp flags.
