# Phase 8G — Reference Parity and Regression Protection

## Goal

Prove that the production implementation matches a canonical DPM++ 2M integrator when both receive the same denoiser callback and sigma schedule.

## Test-Local Reference Implementation

Create an independent reference implementation covering:

- First-order bootstrap
- Second-order update
- Previous-denoised handling
- `h` calculations
- `r` calculations
- Terminal-zero behavior
- History reset behavior
- Float32 versus float64 comparison

Do not import production update functions into the reference implementation.

## Test Inputs

Feed both implementations:

```text
identical initial latent
identical sigma schedule
identical synthetic denoiser callback
identical history policy
identical conditioning-change events
identical timestep sequence
```

Compare every intermediate latent.

## Required Scenarios

Test:

```text
all timesteps distinct
high-end repeated-timestep plateau
low-end repeated-timestep plateau
conditioning change
non-finite previous history
terminal zero
two-step schedule
long schedule
float32 versus float64
```

## Tolerances

Define and document numerical tolerances for:

- Per-step latent maximum absolute error
- Per-step latent mean absolute error
- Final latent error
- Float32 versus float64 drift

The tolerance must be strict enough to catch coefficient, sign, history, and indexing errors.

## Regression Tests

Add permanent tests covering:

- Correct first-order bootstrap
- Correct second-order continuation
- Correct history rejection
- Correct history resumption
- Correct terminal behavior
- Determinism with fixed seeds
- No mutation of the input sigma schedule
- No accidental dtype downgrade inside solver math

## Acceptance Gate

Phase 8G passes when:

- Production output matches the reference integrator within the defined tolerance.
- Every supported history policy has reference coverage.
- Every intermediate latent can be compared.
- Remaining visual differences from Euler can be classified as sampler behavior rather than implementation error.
