# Phase 8F — Tune the High-Sigma Range

## Goal

After denoising and history are proven correct, determine the preferred maximum sigma.

Do not switch to a model-bounded `sigma_max` near `14`.

Empirical testing indicates that the useful range is approximately `35–50`.

## Test Values

```text
35
40
45
50
current native maximum, approximately 53–54
```

## Fixed Conditions

Use:

```text
canonical denoised output
float32 solver
strict timestep history
native KES schedule shape
same minimum sigma
same step count
same prompts
same seeds
```

Only the maximum sigma should change.

## Initial-Latent Control

The experiment must record whether initial noise is multiplied by `sigma_max`.

If changing `sigma_max` changes initial latent amplitude, record:

```text
raw noise norm
initial scaling factor
initial latent norm
sigma_max requested
sigma_max actual
```

That effect must be treated as part of the experiment.

## Validation Matrix

| Variant | Sigma max | History |
|---|---:|---|
| S35 | 35 | Strict |
| S40 | 40 | Strict |
| S45 | 45 | Strict |
| S50 | 50 | Strict |
| S54 | Native | Strict |

Use at least:

```text
3 reliable prompts
1 difficult stress prompt
3 fixed seeds per prompt
```

## Prompt Guidance

Include:

- A straightforward single-subject prompt that Euler consistently passes
- Cat at table
- Mountain lake
- Dog playing poker as a stress case

The stress prompt must not be the sole acceptance criterion.

## Evaluation Criteria

Compare:

- Subject adherence
- Composition
- Detail
- Contrast
- Numerical stability
- Seed consistency
- Predicted-x0 quality
- Latent norm behavior
- Runtime and memory use

## Reporting

Produce:

```text
contact sheet
per-prompt comparison
per-seed comparison
trace summary
schedule summary
manual review worksheet
recommended sigma_max
```

## Acceptance Gate

Select the range that provides the best combination of:

- Subject adherence
- Composition
- Detail
- Contrast
- Stability
- Seed consistency

The expected production range is approximately `40–50`, with `45` serving as a reasonable initial candidate unless testing favors another value.
