# Phase 8 — DPM++ 2M Repair and Validation Overview

## Purpose

Phase 8 will repair, validate, and productionize the DPM++ 2M sampler without weakening the high-sigma behavior that has performed best in testing.

The current evidence supports these conclusions:

- The core image-generation pipeline is functional.
- Simple Euler and KES Euler both produce acceptable results.
- DPM++ 2M completes sampling but does not yet produce consistently acceptable output.
- Reducing `sigma_max` to approximately `14.6` produces worse results.
- Empirical testing indicates that `sigma_max` values in the `35–50` range are preferable.
- The remaining issue may involve the denoising contract, model-output conversion, multistep history, or an interaction between those systems.

The investigation order is:

```text
1. Freeze the current high-sigma baseline and improve diagnostics.
2. Establish a canonical denoising contract.
3. Validate first-order DPM++ without history.
4. Repair second-order history.
5. Tune sigma_max within the proven 35–50 range.
6. Verify reference parity and add regression protection.
7. Promote the validated configuration into production.
```

## Phase Sequence

### Phase 8B — Baseline and diagnostics

Preserve the native high-sigma KES schedule and add detailed per-step tracing and predicted-x0 previews.

### Phase 8C — Canonical denoising contract

Move prediction-type handling, CFG, preconditioning, and model-output-to-x0 conversion out of the sampler and into the denoising layer.

### Phase 8D — First-order DPM++ validation

Disable multistep history and prove that canonical denoised predictions work with first-order DPM++ updates.

### Phase 8E — Second-order history repair

Reintroduce multistep behavior using timestep-aware history rules, especially across repeated model timesteps.

### Phase 8F — High-sigma tuning

Test `sigma_max` values of `35`, `40`, `45`, `50`, and the current native maximum while preserving the validated schedule shape.

### Phase 8G — Reference parity

Compare the production implementation against a test-local canonical DPM++ 2M integrator at every step.

### Phase 8H — Production integration

Promote the validated DPM++ configuration into the sampler registry with truthful manifest metadata and retained diagnostic overrides.

## Global Constraints

Throughout Phase 8:

- Do not adopt a production `sigma_max` near `14`.
- Preserve the native KES-compatible schedule shape unless a later controlled test proves otherwise.
- Keep UNet inference in the model's preferred dtype.
- Keep DPM++ solver state, sigma math, and denoised history in float32.
- Do not add more DPM-family samplers until DPM++ 2M passes Phase 8H.
- Keep experimental behavior opt-in until it passes its acceptance gate.
- Use fixed prompts and fixed seeds for comparisons.
- Save all per-step traces and manifests needed to reproduce a result.

## Recommended Control Prompts

Use at least:

```text
1. A straightforward single-subject prompt that Euler consistently passes.
2. A cat-at-table prompt.
3. A mountain-and-lake landscape prompt.
4. The dog-playing-poker prompt as a difficult stress test.
```

The dog-playing-poker prompt must not be the sole pass/fail criterion because the Euler paths have also struggled with it.

## Final Success Criteria

Phase 8 is complete when:

- DPM++ receives a verified canonical predicted-x0 value.
- First-order DPM++ produces coherent results.
- Second-order history is applied only when valid.
- The selected `sigma_max` remains within the empirically successful high-sigma range.
- The production implementation matches a canonical reference integrator.
- The sampler is stable across multiple prompts and seeds.
- The manifest accurately records prediction type, precision, history behavior, and schedule details.
