# Phase 8H — Production Integration

## Goal

Promote the validated DPM++ 2M configuration from experimental mode into the normal sampler registry.

## Proposed Production Defaults

Tentatively:

```text
sampler: dpmpp_2m
solver_dtype: float32
prediction_source: canonical_denoiser
history_policy: strict_timestep_progress
sigma_max: selected value within 35–50
scheduler: native KES-compatible schedule
```

These defaults remain provisional until Phases 8B through 8G pass.

## Registry Integration

Update the sampler registration so that:

- DPM++ 2M uses the canonical denoiser.
- Float32 solver state is the default.
- Strict timestep history is the default.
- The selected high-sigma range is used by default.
- Diagnostic compatibility overrides remain available.
- Invalid option combinations fail with clear errors.

## Manifest Additions

Record:

```text
prediction_type
prediction_conversion
solver_dtype
model_dtype
sigma_max_requested
sigma_max_actual
sigma_min_actual
schedule_name
history_policy
first_order_step_count
second_order_step_count
history_reset_count
history_rejection_reasons
repeated_timestep_count
model timestep range
initial latent scaling method
```

## Diagnostic Overrides

Retain advanced options:

```text
solver_dtype=latent
history_policy=always
history_policy=first_order_only
sigma_max=<value>
save_x0_previews=true
save_step_trace=true
```

These should remain advanced validation controls rather than normal user-facing defaults.

## Documentation

Document:

- Recommended use
- Default sigma range
- Precision behavior
- History behavior
- Prediction-type support
- Diagnostic options
- Known differences from Euler
- Reproduction instructions
- Acceptance-test procedure

## Final Validation Matrix

Run:

```text
4 prompts
3 fixed seeds per prompt
Simple Euler
KES Euler
Production DPM++ 2M
```

Review:

- Final images
- Predicted-x0 diagnostics
- Trace summaries
- Runtime
- Memory use
- Manifests
- Determinism

## Acceptance Gate

Phase 8H passes when:

- DPM++ 2M is available through the normal sampler registry.
- Its defaults match the validated configuration.
- It produces coherent prompt-related output across the acceptance matrix.
- Fixed seeds are deterministic.
- No trace or diagnostic failure can block normal image saving.
- Manifests truthfully describe all solver and denoising behavior.
- The experimental compatibility paths remain available but are not the default.
