# Phase 8B — Freeze the Baseline and Expand Diagnostics

## Goal

Establish one stable DPM++ 2M baseline and collect enough per-step evidence to determine where the failure begins.

Potential failure locations include:

- Model-input preparation
- Prediction-type handling
- Classifier-free guidance
- Epsilon-to-denoised conversion
- Solver-state precision
- Multistep history
- Repeated model timesteps
- Sigma-schedule interaction

## Baseline Configuration

Use:

```text
Scheduler: native Simple KES
Sigma maximum: current native value, approximately 50–54
Sampler: DPM++ 2M
Solver state: float32
UNet execution dtype: model dtype, normally float16
History policy: current behavior
```

Do not alter the scheduler shape in this phase.

## Implementation Scope

Add detailed per-step tracing to the DPM++ execution path.

Record:

```text
step index
solver sigma
next solver sigma
model timestep
model input dtype
model input norm
solver latent norm

unconditional model-output norm
conditional model-output norm
guided model-output norm

prediction type
predicted x0 / denoised norm
predicted x0 minimum
predicted x0 maximum
predicted x0 mean
predicted x0 standard deviation

difference from previous x0
cosine similarity with previous x0

first-order or second-order update
history accepted or rejected
history rejection reason

latent norm after update
finite / NaN / Inf status
```

## Predicted-x0 Diagnostic Previews

Decode predicted clean latents at:

```text
first step
last repeated-timestep-999 step
first distinct timestep after the plateau
middle step
penultimate step
```

Store these separately from normal output images.

Suggested structure:

```text
artifacts/
  phase08b_diagnostics/
    <run_id>/
      final/
      predicted_x0/
        step_000/
        step_004/
        step_005/
        step_010/
        step_019/
      traces/
      manifests/
```

## Tests

Add tests confirming:

- Tracing is optional and does not alter sampler results.
- Trace metadata is JSON serializable.
- Predicted-x0 previews use the denoised latent rather than the current noisy solver latent.
- Preview decoding failures do not prevent final output saving.
- All finite-value checks correctly identify NaN and Inf values.
- Baseline behavior remains unchanged when diagnostics are disabled.

## Acceptance Gate

Phase 8B passes when:

- The native high-sigma baseline runs successfully.
- Every DPM++ step records the required diagnostics.
- Predicted-x0 previews are saved at the selected steps.
- Diagnostic failures cannot block normal image saving.
- The traces clearly reveal whether degradation begins before or after multistep history is used.

## Decision

- If predicted-x0 previews are already invalid before second-order history begins, continue to Phase 8C.
- If predicted-x0 previews are coherent but the final image degrades after history begins, complete Phase 8C conversion verification and then proceed to Phase 8E.

## Implementation Status - 2026-07-25

The model-free Phase 8B implementation is complete. See `docs/audits/Phase_08B_Implementation_Report.md`.

Run the real-checkpoint acceptance workflow with:

```bat
phase08b_validate.bat "models\StableDiffusion\CheckPoints\your_model.safetensors"
```

Phase 8B remains pending final visual acceptance until that report and its predicted-x0 previews are reviewed.
