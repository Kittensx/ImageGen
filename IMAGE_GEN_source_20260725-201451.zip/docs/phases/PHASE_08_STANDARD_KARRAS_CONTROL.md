# Phase 08 control scheduler: Standard Karras

This targeted diagnostic addition introduces `standard_karras`, a plain fixed-step
scheduler intended to separate DPM++ 2M solver behavior from Simple KES policy.

The control scheduler performs only these operations:

1. Reconstruct the Stable Diffusion scaled-linear training sigma table.
2. Use the model training sigma minimum and maximum by default.
3. Generate a rho-7 Karras sequence with exactly the requested number of steps.
4. Append one terminal zero sigma.
5. Interpolate each sigma back into the model training timestep domain.

It deliberately does not use scheduler blending, tail steps, step expansion,
randomization, prepasses, sigma caches, noise-scale policies, automatic repair,
or stabilization.

Use `standard_karras` with `dpmpp_2m` as the apples-to-apples control. Simple KES
remains available and unchanged. The model-bounded maximum near 14.61 is used
only by this control scheduler; it does not replace the high-sigma Simple KES
workflow.
