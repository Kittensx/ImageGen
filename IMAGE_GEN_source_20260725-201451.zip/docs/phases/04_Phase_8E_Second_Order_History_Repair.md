# Phase 8E — Repair Second-Order History

## Goal

Reintroduce DPM++ 2M multistep behavior only after first-order denoising is proven correct.

The main hypothesis is that denoised history becomes unreliable while multiple solver sigmas map to the same discrete model timestep.

Example:

```text
sigma 50 -> timestep 999
sigma 44 -> timestep 999
sigma 38 -> timestep 999
```

The solver state changes while model conditioning remains on the same timestep.

## History Policies

Add:

```text
always
strict_timestep_progress
first_order_only
```

### `always`

Use current DPM++ 2M history behavior.

Retain for comparison and compatibility testing.

### `strict_timestep_progress`

Use second-order history only when model conditioning has genuinely progressed.

Reject history when:

- The model timestep is unchanged
- The model timestep moves in the wrong direction
- Sigma continuity is invalid
- Conditioning changes
- The previous denoised prediction is non-finite
- A terminal or discontinuous transition occurred

### `first_order_only`

Never use multistep history.

Retain as a diagnostic and fallback mode.

## Plateau Behavior

During repeated high-end timesteps:

```text
use first-order updates
do not extrapolate stale x0 history
do not carry history across the plateau
```

When distinct model timesteps resume:

1. Collect one valid x0 prediction.
2. Perform a first-order bootstrap.
3. Resume second-order updates on the following valid step.

## Suggested History State

Track:

```text
previous_denoised
previous_sigma
previous_model_timestep
previous_conditioning_signature
previous_transition_valid
history_generation
```

## Validation Matrix

| Variant | Sigma range | Precision | History |
|---|---:|---|---|
| C | Native high sigma | Float32 | Always |
| E | Native high sigma | Float32 | Strict timestep progress |
| F | Native high sigma | Float32 | First-order only |

Keep every other setting identical.

## Required Tests

Add tests for:

- Repeated timesteps force first-order behavior.
- History is cleared or suspended across plateaus.
- History resumes only after a valid bootstrap.
- Conditioning changes invalidate history.
- Non-finite previous denoised predictions invalidate history.
- Strict history matches always-history when every timestep is distinct.
- History reset counts are reported accurately.

## Manifest Requirements

Record:

```text
history_policy
first_order_step_count
second_order_step_count
history_accept_count
history_reject_count
history_reset_count
history_rejection_reasons
repeated_timestep_count
```

## Acceptance Gate

`strict_timestep_progress` must:

- Preserve coherent behavior during timestep plateaus
- Use second-order updates through the valid middle schedule
- Avoid NaNs and explosive latent growth
- Equal or outperform `always`
- Equal or outperform `first_order_only` in detail and structure
