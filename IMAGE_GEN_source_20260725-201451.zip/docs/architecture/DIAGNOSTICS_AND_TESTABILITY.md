# IMAGE_GEN Diagnostics and Testability Architecture

## Design Rule

Diagnostics surround systems; they do not replace system contracts or inference math.

```text
Txt2ImgRunner
  -> configuration / registry / model loading
  -> GenerationPipeline
       -> conditioning
       -> scheduling
       -> latent preparation
       -> denoising + sampling
       -> decoding
       -> result validation
  -> output

DiagnosticsSystem wraps every arrow and operation.
```

## Session Lifecycle

```text
start(request, effective_config, extras)
  -> assign run_id
  -> initialize in-memory events/timings
  -> optionally prepare sampler trace

run_stage(system, operation, callable)
  -> stage-start event
  -> timing start
  -> callable
  -> passed timing + completion event
  OR
  -> failed timing + error event
  -> failure bundle
  -> PipelineStageError

complete(result)
  -> successful summary
  -> optional events.jsonl and run_summary.json
```

The core pipeline creates its own session when used directly. `Txt2ImgRunner` creates a session before configuration validation and passes the same session through model loading, generation, and output so one run ID covers the complete request.

## Failure Ownership

The innermost named system owns the failure. `PipelineStageError` is never rewrapped by outer stages.

Example:

```text
sampling.sample
  -> denoising.predict_guided_noise
       -> UNet raises

assigned failure:
  system=denoising
  operation=predict_guided_noise
```

The sampling timing is marked `failed_nested`, preserving elapsed time without stealing ownership.

## Verbosity

| Mode | Console threshold | Successful artifact behavior |
|---|---:|---|
| `quiet` | error | none unless explicitly requested |
| `normal` | warning | none unless explicitly requested |
| `verbose` | info | optional through `export_events` |
| `trace` | debug | events and summary exported |

Failure bundles are independent from console verbosity.

## Artifact Ownership

All diagnostics write below the configured `diagnostics_dir`, normally:

```text
artifacts/diagnostics/
|-- failures/
|-- runs/
`-- traces/
```

The diagnostics system rejects source-tree trace locations by relocating them to this root. `.image-gen-ignore` excludes the entire `artifacts/` tree.

## Successful Result Metadata

A successful generation result receives:

```python
result.metadata["diagnostics"] = {
    "run_id": "...",
    "started_utc": "...",
    "verbosity": "normal",
    "timings": [...],
    "tensor_summaries": {...},
    "trace_exports": {...},
    "failure_bundle": None,
}
```

This metadata is JSON-safe and can be included in future UI, service, or job-state views without importing the diagnostics implementation.

## Failure Bundle Reproduction

A bundle stores two request views:

- `request.json`: the canonical `GenerationRequest`;
- `reproduction_request.json`: request plus portable extras, including model selection.

The bundle also records the effective project config and component types/counts. This separates reproducibility data from the live Python objects that originally executed the request.

## Test Architecture

```text
static
  -> active-source compile/import audit

unit
  -> pipeline correctness + diagnostics behavior

contract
  -> runtime objects + plugin descriptors

integration
  -> fake end-to-end pipeline, project context, composition, diagnostics

focused
  -> all phase-specific focused suites through Phase 06

checkpoint
  -> explicit user-supplied real checkpoint smoke command
```

No tier silently downloads a model or selects an arbitrary checkpoint.
