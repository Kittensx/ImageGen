# IMAGE_GEN System Module Architecture

## Purpose

Phase 04 keeps IMAGE_GEN as a Python application while adopting the same useful architectural idea applied in other projects: every major responsibility has an explicit module boundary and can be replaced without rewriting the whole application.

## Package Layers

```text
interfaces / compatibility
        |
        v
runtime use cases and composition
        |
        v
independent systems
        |
        v
canonical contracts
```

### Canonical contracts

`src/image_gen/contracts` is the only place that defines pipeline-facing data and protocols. The historical `modules/contracts` package only re-exports these objects.

### Runtime

`GenerationPipeline` controls order only. `PipelineCompositionRoot` creates the default systems and accepts named overrides. This makes a test, future GUI, service, or alternate workflow able to replace one system without subclassing a large pipeline object.

### Systems

Each system has a narrow public operation:

- `ConditioningSystem.encode()`
- `SchedulingSystem.build()`
- `LatentPreparationSystem.prepare()`
- `DenoisingSystem.predict_raw_noise()`
- `DenoisingSystem.predict_guided_noise()`
- `SamplingSystem.sample()`
- `DecodingSystem.decode()`
- `DiagnosticsSystem.start()` / `finish()`
- `ModelLoadingSystem.load()`
- `RuntimeRegistrySystem.resolve_entry()` / `instantiate_adapter()`
- `OutputSystem.build_manifest()` / `save()`

## Composition and Replacement

Default construction:

```python
root = PipelineCompositionRoot(
    components=components,
    prompt_adapter=prompt_adapter,
    scheduler_adapter=scheduler_adapter,
    sampler_adapter=sampler_adapter,
)
pipeline = root.build(state=state)
```

Single-system replacement:

```python
pipeline = PipelineCompositionRoot(
    components=components,
    prompt_adapter=prompt_adapter,
    scheduler_adapter=scheduler_adapter,
    sampler_adapter=sampler_adapter,
    system_overrides={"denoising": diagnostic_denoising_system},
).build(state=state)
```

Supported generation-system override names are:

```text
conditioning
scheduling
latent_preparation
denoising
sampling
decoding
diagnostics
```

Model loading, registry resolution, and output are use-case systems used above the core pipeline. They are injected into `Txt2ImgRunner` separately.

## Import Compatibility

The migration uses facades rather than maintaining two implementations. This is important: old and new imports return the same class object.

```text
modules.contracts.GenerationRequest
    is image_gen.contracts.GenerationRequest

modules.pipeline_builder.CustomSDPipeline
    is image_gen.runtime.CustomSDPipeline
```

The facades can be removed in a later cleanup phase after all production imports have moved to `image_gen.*`.

## Dependency Direction

The intended dependency direction is:

```text
contracts <- systems <- runtime <- interfaces
```

Compatibility modules may point inward to the canonical package. The canonical core must not import compatibility orchestration modules.

The lightweight core runtime intentionally does not import:

- checkpoint construction libraries
- registry scanners
- output persistence

Those dependencies are loaded only by their dedicated systems or the txt2img use case.

## Output Rule

`GenerationPipeline` returns tensors and metadata. It never creates directories, chooses filenames, or writes images. `OutputSystem` is the only Phase 04 persistence system.

## Phase 05 Registry Result

`RuntimeRegistrySystem` now owns a lazy, validated `PluginRegistry`. Samplers and schedulers export stable descriptors and are discovered from `ProjectContext.registry_root`. Generated Python maps are no longer runtime inputs. The generation pipeline remains unchanged because registry behavior stays above the core system composition.

## Phase 06 Diagnostics Result

`DiagnosticsSystem` now surrounds every system operation with structured events, timings, optional tensor summaries, sampler trace lifecycle, and failure-bundle creation. Diagnostics remain optional for successful runs and do not change plugin, scheduler, sampler, conditioning, or denoising contracts.

## Phase 8C denoising interface

The denoising system's narrow public surface now includes:

```text
DenoisingSystem.predict_model_output()
DenoisingSystem.predict_epsilon()
DenoisingSystem.predict_raw_noise()
DenoisingSystem.predict_guided_noise()
DenoisingSystem.predict_denoised()
```

`predict_raw_noise()` and `predict_guided_noise()` remain compatibility boundaries for epsilon-space samplers. `predict_denoised()` is the canonical float32 predicted-x0 boundary for DPM++ and future denoised-space solvers.
