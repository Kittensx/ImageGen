# Pipeline Correctness and Output Ownership

## Purpose

This document records the Phase 03 generation contracts that must remain stable while Phase 04 extracts the pipeline into system modules.

## Generation Flow

```text
GenerationRequest
    -> prompt adapter / conditioning resolver
    -> scheduler adapter -> SchedulerOutput(sigmas, timesteps)
    -> initial latent preparation
    -> sampler adapter
         -> raw or guided denoiser callback
              -> model-input scaling
              -> UNet epsilon prediction
         -> sampler-specific integration
    -> VAE decode normalization
    -> GenerationResult
    -> Txt2ImgRunner / output_saver
```

## Canonical Denoiser Callbacks

Raw callback:

```text
raw_model_fn(
    latents,
    sigma,
    timestep,
    conditioning,
    extra=None,
) -> epsilon
```

Guided callback:

```text
guided_model_fn(
    latents,
    sigma,
    timestep,
    cond,
    uncond,
    cfg_scale,
    extra=None,
) -> epsilon
```

Sigma and timestep are separate arguments. A sampler must never infer the model timestep from the loop index.

## Scheduler Contract

A valid `SchedulerOutput` provides:

- a one-dimensional, finite, non-negative, non-increasing sigma tensor
- at least two sigma values
- exactly `len(sigmas) - 1` effective transitions
- explicit timesteps with either one value per transition or one value per sigma
- requested and effective step counts
- compatibility and mapping metadata

The final sigma should be zero for the current deterministic baseline integration paths.

## Scaling Contract

Initial latent noise is sampled with the resolved request seed and multiplied by the first scheduler sigma.

Before each UNet call, the latent input is scaled using:

```text
scaled_input = latents / sqrt(sigma^2 + 1)
```

The UNet output is interpreted as epsilon/noise prediction.

## Sampler Parameterization

- **Simple Euler:** consumes epsilon directly to calculate the derivative.
- **DPM++ 2M:** converts epsilon to denoised prediction with `x - sigma * epsilon` before the multistep update.
- **KES:** retains sampler-owned CFG and publishes epsilon as its model prediction type.

A future sampler must declare its expected parameterization instead of relying on an undocumented convention.

## Step Conditioning

All samplers call the shared step-conditioning resolver. Prompt schedules must therefore change at the same logical denoising step regardless of sampler choice.

## Seed Contract

- `None` means generate and record a fresh seed.
- Any negative seed means generate and record a fresh seed.
- A non-negative integer is preserved exactly.
- Random tensors use a device-local `torch.Generator`.
- Auxiliary sampler noise must derive from the resolved request seed rather than the process-global random state.

## VAE Contract

VAE decode results may be:

- a tensor
- a tuple/list whose first item is the tensor
- an object exposing a `.sample` tensor

The normalized output must be finite BCHW data with at least three channels. The pipeline converts it into the display/output range and returns the first three channels.

## Output Ownership

`CustomSDPipeline` must not write files. It returns `GenerationResult` only.

`Txt2ImgRunner` decides whether the request should be persisted and calls `modules.txt2img.output_saver`. This layer owns:

- image filenames
- PNG writing
- infotext sidecars
- JSON manifests
- returned saved-path records

This is the single-write rule: one generation request passes through one persistence owner exactly once.

## Diagnostics

Normal runtime must remain quiet. Diagnostic output should be emitted through explicit debug/trace settings or future structured diagnostics systems. Tensor statistics and complete configuration dumps must not be printed unconditionally.

## Migration Rule for Phase 04

Phase 04 may relocate these responsibilities into `systems/` modules, but it must preserve the Phase 03 tests. Any intentional contract change requires a replacement test and an architecture-document update in the same phase.

## Phase 8C denoising correction

The earlier Phase 03 statement that DPM++ converts epsilon locally is superseded.

DPM++ 2M now requests a canonical float32 predicted-x0 tensor from `DenoisingSystem.predict_denoised()`. The denoising system, not the sampler, owns checkpoint prediction type, model-input preconditioning, CFG, optional CFG rescaling, and output conversion.

The conversion uses the solver-state sample and the exact solver sigma supplied for that model evaluation. The preconditioned UNet input is never substituted for the solver-state sample during x0 construction.
