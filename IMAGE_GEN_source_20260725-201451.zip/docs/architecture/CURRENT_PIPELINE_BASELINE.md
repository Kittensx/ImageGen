# IMAGE_GEN Current Pipeline Baseline

## Canonical execution path

After Phase 01, the supported interactive runtime is:

```text
run.bat
  -> python -m modules.txt2img.cli run --interactive
  -> ProjectContext loads user_config/user-config.yml
  -> project defaults + optional request source + CLI/interactive overrides
  -> configuration and path preflight
  -> sampler and scheduler registry discovery from ProjectContext
  -> Txt2ImgRunner
  -> checkpoint inspection and component construction
  -> PipelineBuilder / CustomSDPipeline
      -> prompt conditioning
      -> schedule construction
      -> latent creation
      -> sampler loop
      -> UNet denoising
      -> VAE decoding
  -> output saver and generation manifest
```

`run_cli.bat` is retained for compatibility and invokes the same runtime. `app/run.py` is a deprecated compatibility redirect to the same CLI.

## Configuration path

The canonical user configuration is:

```text
user_config/user-config.yml
```

`modules/project_context.py` resolves project, model, data, output, tokenizer, cache, temporary, and registry paths. Runtime path discovery no longer depends on `os.getcwd()`.

Preflight inspection is available without loading a checkpoint:

```text
python -m modules.txt2img.cli config show
python -m modules.txt2img.cli config validate
```

## Remaining noncanonical source

### Placeholder generation test

`modules/generation_test.py` imports adapter modules that do not exist and contains unresolved example names. It remains classified as a placeholder. The model-free Phase 00 harness provides the current executable diagnostic surface.

## Pipeline stage ownership

| Stage | Current representative source | Future system owner |
|---|---|---|
| Entrypoint and request construction | `modules/txt2img/cli.py` | interface / configuration |
| Project paths and visible config | `modules/project_context.py` | configuration / project context |
| Request orchestration and component assembly | `modules/txt2img/txt2img_runner.py` | runtime / model loading |
| Prompt conditioning | `modules/adapters/prompt_conditioning_adapter.py` | conditioning |
| Schedule construction | scheduler adapters under `modules/ss_registry/` | scheduling |
| Latent preparation and denoising calls | `modules/pipeline_builder.py` | runtime / denoising |
| Sampling integration | samplers under `modules/ss_registry/samplers/` | sampling |
| VAE decode | `modules/pipeline_builder.py` | decoding |
| Image and manifest output | `modules/txt2img/output_saver.py` and manifest modules | output |
| Registry discovery | `modules/ss_registry/master_sampler.py` and `master_scheduler.py` | registry / project context |

## Phase boundary

Phase 01 repairs launcher, path, and configuration ownership only. It does not repair the sampler/denoising contract, mathematical pipeline behavior, or duplicate output ownership. Those remain assigned to Phases 02 and 03.
