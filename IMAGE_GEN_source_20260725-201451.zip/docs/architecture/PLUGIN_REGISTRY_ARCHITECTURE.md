# IMAGE_GEN Plugin Registry Architecture

## Purpose

The plugin registry separates sampler and scheduler discovery from generation orchestration. The runtime asks for a named plugin and receives a validated adapter; it does not scan files, import generated maps, or contain sampler-specific branches.

## Layers

```text
plugin module
  -> PLUGIN_DESCRIPTOR
  -> PluginDiscovery
  -> PluginRegistry validation/indexing
  -> RuntimeRegistrySystem session boundary
  -> Txt2ImgRunner adapter resolution
  -> independent scheduling/sampling systems
```

## Plugin Module Contract

A plugin module exports its adapter and one descriptor:

```python
PLUGIN_DESCRIPTOR = {
    "plugin_id": "sampler.example",
    "kind": "sampler",
    "name": "example",
    "label": "Example Sampler",
    "module": __name__,
    "adapter_class": "ExampleSamplerAdapter",
    "aliases": ["example alias"],
    "capabilities": {...},
    "config_schema": {
        "type": "object",
        "properties": {...},
        "required": [],
        "additionalProperties": False,
    },
}
```

A new plugin is added by placing a descriptor-bearing module in the sampler or scheduler root. No `GenerationPipeline`, `PipelineCompositionRoot`, or `Txt2ImgRunner` edit is required.

## Identity Rules

The registry indexes these identities case-insensitively:

```text
plugin_id
name
label
aliases
```

Identity collisions are rejected within the same plugin kind. Sampler and scheduler namespaces are separate, allowing a sampler and scheduler to share a human-facing term without ambiguity when the requested kind is known.

## Adapter Validation

Registration imports the declared adapter class and applies the Phase 02 protocol checks:

```text
sampler adapter:
  sample(raw_model_fn, guided_model_fn, latents, schedule,
         conditioning, request, state=None)

scheduler adapter:
  build_schedule(request, state=None)
```

A missing class, incorrect method name, incorrect parameter order, or non-optional state argument prevents registration before generation begins.

## Capability Validation

Sampler capabilities reuse `SamplerCapabilities` and continue to declare:

- CFG ownership
- raw versus guided denoiser use
- step expansion support
- tail metadata support
- requested-step requirements
- forced pipeline mode

Scheduler descriptors declare:

- supported pipeline modes
- fixed-step support
- step expansion support
- tail metadata support
- scheduler-family features

`PluginRegistry.validate_pair()` performs a pre-generation capability check. Schedule tensor validation still occurs later because actual effective step counts and tail behavior are only known after schedule construction.

## Configuration Schema

The registry requires an object-style configuration schema. Phase 05 validates schema structure and required-field references; it does not yet perform full JSON Schema evaluation of every runtime override.

This schema is intended for:

- CLI validation
- future graphical settings forms
- plugin documentation
- upgrade compatibility checks
- manifest tooling

## Session Lifetime

`RuntimeRegistrySystem.registry` is lazy and lock-protected. The first lookup builds the registry; later lookups return the same instance.

The CLI shares one registry system with `Txt2ImgRunner`, preventing separate scans for menu population and generation.

## Legacy Compatibility

`modules.ss_registry.master_sampler.SamplerMap` and `master_scheduler.SchedulerMap` remain as facades. They derive their map-shaped output from canonical descriptors and are not the runtime authority.

Generated Python modules are not read. Optional JSON snapshots are diagnostic artifacts only.

## Error Ownership

| Failure | Owner | Example |
|---|---|---|
| missing descriptor field | descriptor validation | missing `config_schema` |
| invalid ID/name | descriptor validation | ID lacks `sampler.` prefix |
| duplicate name/alias | registry indexing | alias already owned |
| missing adapter class | registration | class absent from module |
| adapter signature drift | contract validation | wrong `sample()` parameters |
| incompatible capabilities | pair validation | expanded sampler with fixed-only scheduler |
| import failure | discovery | plugin dependency missing |
| constructor failure | instantiation | adapter initialization error |

## Upgrade Path

Future sampler or scheduler upgrades should keep the stable `plugin_id` when the plugin remains conceptually compatible. Labels and aliases may evolve without breaking manifests. A breaking replacement should use a new stable ID or increment descriptor version with a migration policy in a later phase.
