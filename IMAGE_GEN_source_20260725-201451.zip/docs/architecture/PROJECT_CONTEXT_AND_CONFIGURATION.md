# IMAGE_GEN Project Context and Configuration

## Canonical authority

`modules/project_context.py` is the single authority for project-relative paths and the visible user configuration.

The default project root is derived from the installed source location, not from the process working directory. The canonical configuration file is:

```text
user_config/user-config.yml
```

A caller may explicitly override the project root or project configuration, but relative configured paths are always resolved from the selected project root.

## ProjectContext paths

`ProjectContext` supplies the runtime with:

- project and modules roots
- sampler/scheduler registry root
- model and checkpoint roots
- VAE, LoRA, ControlNet, embedding, and hypernetwork roots
- local architecture-config root
- bundled tokenizer root
- data and registry-database paths
- output and txt2img output roots
- cache and temporary roots

Construction is read-only. It does not create any of these directories.

## Configuration precedence

For a generation request, settings are resolved in this order:

1. defaults from `user_config/user-config.yml`
2. one optional generation request source (`--config`, `--manifest`, or `--infotext`)
3. explicit CLI or interactive values

Later sources override earlier sources. Relative model, VAE, LoRA, and output paths are normalized against the project root before generation.

## Validation

The canonical preflight commands are:

```bat
venv\Scripts\python.exe -m modules.txt2img.cli config show
venv\Scripts\python.exe -m modules.txt2img.cli config validate
```

`config validate` checks the configured model file, checkpoint root, bundled tokenizer and required tokenizer files, local architecture configs, and output directory before model loading. Missing data, cache, and temporary paths are reported as warnings because the owning runtime subsystem may create them explicitly later.

JSON output is available for tooling:

```bat
venv\Scripts\python.exe -m modules.txt2img.cli config show --json
venv\Scripts\python.exe -m modules.txt2img.cli config validate --json
```

## Compatibility

`ConfigOptions` remains available as a compatibility view for existing model-loading code. It receives a `ProjectContext` and exposes the older string attributes, but its constructor no longer creates directories.

`app/run.py` remains only as a compatibility redirect to the canonical CLI. `run.bat` is the supported interactive launcher; `run_cli.bat` invokes the same runtime for existing workflows.
