# Real Checkpoint Validation Architecture

## Purpose

Phase 07 separates real-model proof from normal generation. A normal successful image does not by itself prove that the correct architecture, tokenizer, component weights, schedules, or deterministic metadata were used.

The validation system therefore treats a real checkpoint run as a structured evidence package.

## Flow

```text
phase07_validate.bat
  -> scripts/validation/phase07_validate.py
      -> ProjectContext
      -> CheckpointInspector header/fingerprint preflight
      -> architecture capability gate
      -> local tokenizer validation
      -> LoadModel / ModelLoadingSystem
      -> component coverage report
      -> Txt2ImgRunner
          -> baseline run
          -> reset request state
          -> baseline repeat
          -> reset request state
          -> KES comparison run
      -> RealCheckpointValidationSystem
          -> tensor statistics and digests
          -> reproducibility metrics
          -> sampler comparison
          -> acceptance checks
          -> JSON and Markdown reports
```

## Why the Capability Gate Runs First

The project contains SD1, SD2, and SDXL local configuration directories. Those files are configuration candidates, not proof that the active runtime supports each architecture.

A checkpoint must be identified from its own header evidence and approved by the capability matrix before its full tensors are loaded. This prevents an ambiguous SD2 checkpoint from being instantiated accidentally with SD1 configuration.

## Why Inspection Does Not Load Tensors

Safetensors stores key, dtype, shape, and metadata information in its header. Inspection uses that header and a streaming file checksum. Component construction performs the only full checkpoint load.

This reduces duplicate memory pressure and permits safe architecture rejection before model allocation.

## Why the Runner Caches Components

The controlled profile needs three equivalent model runs. Reconstructing the UNet, VAE, and text encoder for each run wastes time and GPU memory churn.

The runner caches one loaded model using:

```text
absolute checkpoint path
dtype
device
file size
file modification timestamp
```

The cache is cleared when any of those values changes. Mutable request state is reset independently between runs.

## Reproducibility Definition

Exact byte equality is recorded but is not the only signal. The acceptance gate uses `torch.allclose` with explicit absolute and relative tolerances and records the full error metrics. This recognizes that some supported CUDA kernels can be materially reproducible without being byte-identical.

## Report Trust Boundaries

The JSON report contains numerical evidence and is the authoritative Phase 07 artifact. The Markdown report is a human-readable summary.

Generated reports and validation images live under `artifacts/` and are excluded from source ZIPs. The checkpoint itself is never copied into a validation package.
