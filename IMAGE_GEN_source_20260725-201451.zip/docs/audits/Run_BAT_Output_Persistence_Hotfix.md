# run.bat Output Persistence Hotfix

## Purpose

Phase 07 proved that the canonical IMAGE_GEN pipeline can load an SD1 checkpoint,
condition a prompt, sample, decode, and persist PNG/TXT/JSON outputs. The normal
`run.bat` path used the same generation runtime but did not request persistence,
so it correctly completed inference while returning `No images were saved.`

This hotfix aligns the user-facing launcher with the validated output path without
changing model loading, conditioning, scheduling, sampling, or decoding behavior.

## Root cause

`GenerationRequest.save_images` is intentionally false by default for library and
test callers. The Phase 07 validator explicitly set it to true, while `run.bat`
started interactive CLI generation without an explicit save instruction. The
canonical project generation defaults also did not promote a save policy into the
request.

## Changes

- `run.bat` now invokes `run --interactive --save`.
- The CLI supports mutually exclusive `--save` and `--no-save` switches.
- Project generation defaults use `save_images: true` when the setting is absent.
- The configured txt2img output directory is created before path validation.
- The canonical runner repeats that directory preparation for non-CLI callers.
- A save request must produce at least one existing image file or the run fails in
  `output.save` rather than reporting a misleading success.
- Completion output prints the effective prompt, output directory, and exact PNG,
  TXT, and JSON paths.
- The canonical Phase 04 `OutputSystem` package, omitted from the supplied source
  archive, is restored with the Phase 07 JSON-safe metadata fixes.

## Normal output location

Unless `--output-dir` overrides it, `run.bat` writes under:

```text
output/txt2image/
```

Files are numbered without overwriting prior output:

```text
img_0000001.png
img_0000001.txt
img_0000001.json
```

## User test

Run:

```bat
run.bat
```

Use a clearly distinguishable prompt such as:

```text
a fluffy orange kitten sitting in a blue ceramic bowl
```

The completion summary must print at least one `Image:` path. Open that path and
confirm the visible content matches the interactive prompt rather than the fixed
Phase 07 teapot prompt.

To deliberately run without persistence from a terminal:

```bat
venv\Scripts\python.exe -m modules.txt2img.cli run --interactive --no-save
```

## Automated verification

```bat
venv\Scripts\python.exe -m unittest tests.hotfix.test_run_output_persistence -v
```

The implementation was also checked with the focused Phase 00-07 suites and the
Phase 00 active-source audit.
