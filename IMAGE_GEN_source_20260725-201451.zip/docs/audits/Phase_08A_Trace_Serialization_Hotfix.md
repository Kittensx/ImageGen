# Phase 08A Trace Serialization Hotfix

**Project:** IMAGE_GEN  
**Area:** Phase 08A sampler matrix  
**Date:** 2026-07-25

## Reported Failure

The real-checkpoint Phase 08A matrix completed sampling work but every run failed before decoding and output persistence with:

```text
TypeError: Object of type device is not JSON serializable
```

No images were saved because `GenerationPipeline.generate()` exported the optional sampler trace before decoding. The trace recorder attempted to serialize scheduler metadata containing a real `torch.device` object with raw `json.dumps()`.

## Root Cause

The Simple KES scheduler stores its runtime device in nested scheduler settings. Phase 08A intentionally copies that detailed schedule metadata into the trace summary. The general diagnostics and manifest systems already used the canonical `json_safe()` normalizer, but `StepTraceRecorder` and the Phase 8A aggregate report did not.

This was not caused by image saving being disabled. Phase 8A saves images by default unless `--no-save-images` is explicitly supplied.

## Changes

- Normalize complete JSON trace payloads through `image_gen.systems.diagnostics.serialization.json_safe()`.
- Normalize each CSV record's `extra_json` payload through the same serializer.
- Normalize the complete Phase 8A aggregate report before JSON and Markdown rendering.
- Add regression coverage for nested `torch.device` and `torch.dtype` values in trace and report metadata.

## Expected Result

The command below now proceeds past trace export, decodes each completed sample, and writes image and sidecar files under each run's `images` directory:

```bat
phase08a_sampler_matrix.bat --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors"
```

## Validation

Focused Phase 08A and serialization tests:

```text
11 passed
```

Related Phase 04, 06, 07, and 08 regression tests:

```text
34 passed, 14 subtests passed
```
