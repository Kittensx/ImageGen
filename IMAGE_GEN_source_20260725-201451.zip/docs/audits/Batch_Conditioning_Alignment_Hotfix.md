# Batch Conditioning Alignment Hotfix

## Problem

Generating multiple images from one prompt created latent tensors with the requested batch size, but prompt conditioning remained at batch size one. At the first UNet attention operation this produced a shape mismatch such as:

```text
The size of tensor a (38400) must match the size of tensor b (9600)
```

The fourfold difference matched the requested batch size of four.

## Cause

The prompt adapter intentionally encodes a single prompt once. The shared conditioning resolver previously moved the resulting tensor to the latent device and dtype but did not align its leading batch dimension with the latent batch.

## Fix

`modules/pipeline/conditioning_utils.py` now:

- Preserves conditioning that already matches the latent batch.
- Broadcasts singleton positive and negative conditioning to the latent batch.
- Applies the same behavior to static and stepwise conditioning.
- Rejects ambiguous non-singleton mismatches with a clear error.
- Returns contiguous tensors for compatibility with attention implementations.

The image count is not divided by the batch size, and CLIP is not redundantly run once per generated image.

## Coverage

Regression tests cover:

- Singleton-to-batch broadcasting.
- Existing matching batches.
- Clear rejection of ambiguous mismatches.
- Static conditioning.
- Scheduled conditioning.
- Batch-four generation through Simple Euler, KES, and DPM++ 2M.
