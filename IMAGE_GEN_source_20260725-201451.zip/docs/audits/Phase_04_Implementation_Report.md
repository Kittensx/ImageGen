# Phase 04 Implementation Report

**Project:** IMAGE_GEN  
**Phase:** 04 - System Module Extraction  
**Completed:** 2026-07-25

## Summary

Phase 04 converts the repaired monolithic pipeline responsibilities into a source-layout Python package containing canonical contracts, a composition root, a thin ordered runtime, and independent systems. Existing launch and import paths remain operational through compatibility facades.

No UI framework migration was performed. The modular design is independent of Avalonia and is appropriate for the current Python image-generation stack.

## Canonical Package Added

```text
src/image_gen/contracts/
src/image_gen/runtime/
src/image_gen/systems/
```

A small root `image_gen` bridge supports direct source-tree execution without requiring an editable install.

## Core Runtime Changes

The previous `modules/pipeline_builder.py` owned device setup, latent preparation, denoising math, sampler invocation, decoding, diagnostics, and orchestration. It is now a compatibility facade.

The canonical runtime is split between:

- `PipelineCompositionRoot`: constructs default systems and applies overrides.
- `GenerationSystems`: named system collection.
- `GenerationPipeline`: executes the systems in order and returns `GenerationResult`.
- `CustomSDPipeline`: compatibility constructor using the new composition root.

## Txt2Img Changes

The previous runner contained registry lookup, dynamic adapter construction, checkpoint orchestration, pipeline construction, manifest building, output saving, and use-case flow.

The canonical `Txt2ImgRunner` now delegates to:

- `RuntimeRegistrySystem`
- `ModelLoadingSystem`
- `PipelineCompositionRoot`
- `OutputSystem`

It remains responsible for use-case sequencing and request-level validation only.

## Compatibility Changes

Replaced with re-export facades:

- `modules/contracts/__init__.py`
- `modules/contracts/runtime.py`
- `modules/contracts/protocols.py`
- `modules/contracts/compatibility.py`
- `modules/pipeline_builder.py`
- `modules/txt2img/txt2img_runner.py`

The older `modules/pipeline/pipeline_builder.py` facade continues to route through `modules.pipeline_builder`.

## Tests Added

`tests/phase04/test_phase04_system_modules.py` verifies:

- canonical contract relocation and identity aliases
- conditioning and scheduling boundaries
- independent denoising and decoding
- independent latent preparation and sampling
- replacement of each generation system through the composition root
- registry entry resolution and adapter construction
- preservation of model-loader call order
- output persistence through `OutputSystem`
- txt2img coordination with injected systems
- lightweight core import without registry, output, or model-loading systems

The Phase 02 ownership test was updated to require canonical class definitions under `src/image_gen/contracts` and no duplicate definitions under `modules`.

## Validation Performed

```text
python -m unittest tests.phase00.test_phase00_baseline \
  tests.phase01.test_phase01_project_context \
  tests.phase02.test_phase02_runtime_contracts \
  tests.phase03.test_phase03_pipeline_correctness \
  tests.phase04.test_phase04_system_modules -v

Result: 40 tests passed
```

The Phase 00 audit also passed:

- active-source compilation
- internal-import validation including `image_gen.*`
- fake generation
- injected failure-stage ownership

## Limitations

- The model-loading system delegates to the current loader; it does not change checkpoint mapping behavior.
- The registry system resolves current maps; formal plugin descriptors, versions, compatibility declarations, and discovery redesign remain Phase 05 work.
- Diagnostics retain the existing trace recorder and its optional export behavior.
- No real checkpoint was included, so no real image-generation claim is made.
