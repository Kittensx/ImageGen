# Phase 03 Implementation Report

**Project:** IMAGE_GEN  
**Phase:** 03 - Pipeline Correctness Repair  
**Completed:** 2026-07-25

## Summary

Phase 03 repairs the existing Python generation path before the Phase 04 system-module extraction. The repair preserves the current interfaces while making denoising arguments, scheduler transitions, prediction parameterization, latent scaling, VAE normalization, seed handling, and output ownership explicit and testable.

No real model checkpoint was included in the reviewed package. All completed validation therefore uses deterministic fake components and contract-level tests. Real Stable Diffusion 1.x execution remains a separate validation gate.

## Correctness Defects Repaired

### Missing timestep arguments

Simple Euler and DPM++ 2M previously called the guided denoiser without the timestep required by the pipeline contract. Both now materialize the scheduler timesteps and pass the matching timestep for every sigma transition.

### Ambiguous denoiser parameterization

The pipeline now labels its UNet output as epsilon/noise prediction. Simple Euler consumes epsilon directly. DPM++ 2M explicitly converts epsilon into denoised prediction before applying the multistep update. KES advertises the same prediction metadata while retaining its sampler-owned CFG path.

### Incorrect or weak schedule handling

`SchedulerOutput` now checks:

- one-dimensional sigma tensors
- at least one transition
- finite and non-negative values
- non-increasing order
- equality between effective steps and sigma transitions
- one timestep per transition or per sigma value

The Simple KES scheduler now creates an explicit terminal zero sigma rather than repeating a positive sigma and producing a no-op final transition.

### Reversed sigma-to-timestep approximation

The previous logarithmic approximation could map decreasing sigmas in the wrong timestep direction. Phase 03 reconstructs the SD1 scaled-linear training beta schedule and interpolates requested sigmas in log-sigma space. Mapping metadata records training bounds and clipping counts.

### Scaling ambiguity

Initial random noise is multiplied by the schedule's first sigma. UNet inputs are normalized by `sqrt(sigma^2 + 1)` before inference. Tests independently verify both operations.

### Duplicate output ownership

The core pipeline no longer imports PIL, constructs filenames, or writes images. It returns `GenerationResult` tensors and metadata. `Txt2ImgRunner` and `modules.txt2img.output_saver` own persistence, eliminating the previous double-save possibility.

### Seed inconsistency

`None` and negative values now resolve to a fresh random non-negative seed. Explicit non-negative seeds are preserved, stored back on the request, and used with a device-local `torch.Generator`. KES auxiliary sampler noise uses a deterministic generator derived from the resolved request seed.

### Unconditional diagnostics

Normal prompt parsing, conditioning, pipeline, sampler, and runner execution no longer emits the previous tensor statistics and configuration dumps. Structured diagnostics remain a later system responsibility.

## Changed Production Areas

- `modules/contracts/runtime.py`
- `modules/pipeline_builder.py`
- `modules/pipeline/sampler_trace_mixin.py`
- `modules/txt2img/seed_utils.py`
- `modules/txt2img/txt2img_runner.py`
- `modules/adapters/prompt_conditioning_adapter.py`
- `modules/parser/prompt_parser_class.py`
- `modules/ss_registry/samplers/simple_samplers/simple_euler.py`
- `modules/ss_registry/samplers/simple_samplers/dpmpp_2m_sampler.py`
- `modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/cfg_strategy.py`
- `modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/kes_sampler.py`
- `modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/kes_sampler_adapter.py`
- `modules/ss_registry/schedulers/simple_kes_sched/simple_kes.py`
- `scripts/audit/phase00_audit.py`

## Tests Added

- `tests/phase03/__init__.py`
- `tests/phase03/test_phase03_pipeline_correctness.py`

## Validation Performed

```text
python -m unittest tests.phase00.test_phase00_baseline \
  tests.phase01.test_phase01_project_context \
  tests.phase02.test_phase02_runtime_contracts \
  tests.phase03.test_phase03_pipeline_correctness -v

Result: 30 tests passed
```

The Phase 00 audit also passed active-source compilation, internal-import validation, fake generation, and injected failure-stage identification.

## Limitations and Deferred Validation

- No compatible real SD1 checkpoint was present, so no production image is claimed.
- The current scheduler defaults can request sigma values above or below the reconstructed SD1 training range. Clipping is surfaced in metadata and must be evaluated during real-checkpoint testing.
- SD2 and SDXL support are not established by this phase.
- Phase 04 should move these now-stable responsibilities into explicit Python system modules without changing the repaired behavior.
