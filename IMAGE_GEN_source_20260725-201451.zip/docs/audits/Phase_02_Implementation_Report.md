# Phase 02 Implementation Report

## Result

Phase 02 is complete. IMAGE_GEN now has one authoritative runtime-contract package and registry-time adapter conformance checks.

## Implemented changes

### Canonical contract package

Added `modules/contracts/` containing:

- `GenerationRequest`
- `PipelineComponents`
- `ConditioningOutput`
- `SchedulerOutput`
- `SamplerOutput`
- `GenerationResult`
- `PromptAdapterProtocol`
- `SchedulerAdapterProtocol`
- `SamplerAdapterProtocol`
- raw and guided model callback protocols
- `SamplerCapabilities`
- `SchedulerCompatibilityResult`
- adapter conformance inspection and validation

### Removed contract drift

Removed local `SamplerOutput` definitions from:

- KES sampler core
- KES sampler adapter
- Simple Euler
- DPM++ 2M

`pipeline_builder.py` no longer defines request, component, conditioning, schedule, sampler, or adapter protocol classes. It imports and re-exports the canonical contracts for compatibility.

### Explicit schedule fields

`SchedulerOutput` now stores requested and effective step counts, compatibility mode, and scheduler override state as typed fields. Scheduler-specific details remain in metadata.

The legacy `extra` view is generated from those fields, preventing the requested/effective step contract from living only in arbitrary metadata.

### Explicit CFG ownership

- KES declares sampler-owned CFG and raw-model callback use.
- Simple Euler declares pipeline-owned CFG and guided-model callback use.
- DPM++ 2M declares pipeline-owned CFG and guided-model callback use.

Both callback protocols include sigma and timestep. The remaining baseline call-site repair is still assigned to Phase 03.

### Registry conformance checks

Sampler and scheduler registries now validate adapter signatures during registration. Invalid adapters raise `AdapterConformanceError` before they can be added to the runtime map.

Live registry discovery was checked and registered:

```text
samplers: dpmpp_2m, kes, simple_euler
schedulers: simple_kes
```

### Generation result contract

`CustomSDPipeline.generate()` now returns `GenerationResult` rather than constructing an untyped dictionary. `Txt2ImgRunner` consumes the typed result.

A compatibility dictionary view remains available during migration. JSON-safe serialization summarizes tensors and replaces arbitrary runtime objects with type descriptions.

### Compatibility imports

Added or retained compatibility exports at:

- `modules.pipeline_builder`
- `modules.pipeline.pipeline_builder`
- `modules.adapters.base`
- `modules.pipeline.schedule_compat`

These are aliases or facades, not duplicate contract definitions.

## Focused validation

```text
python -m unittest tests.phase02.test_phase02_runtime_contracts -v
python -m unittest tests.phase00.test_phase00_baseline tests.phase01.test_phase01_project_context -v
python scripts/audit/phase00_audit.py --print-known-issues
```

Results:

- Phase 02 focused tests: 11 passed
- Phase 00 regression tests: 2 passed
- Phase 01 regression tests: 7 passed
- active source compilation: passed
- no unapproved active internal-import gaps
- fake generation baseline: passed
- live sampler registry discovery: passed
- live scheduler registry discovery: passed

## Deliberately deferred

Phase 02 does not claim that the production denoising math is repaired.

The following remain assigned to Phase 03:

- Simple Euler must pass the explicit timestep to `guided_model_fn`.
- DPM++ 2M must pass the explicit timestep to `guided_model_fn`.
- sigma/timestep materialization and model-input scaling require correctness validation.
- output ownership and duplicate image saving require repair.
- seed and VAE decode semantics require normalization.

No real checkpoint was loaded during Phase 02.
