# Phase 07 Serialization and Failure-Bundle Hotfix

## Trigger

A real SD1 checkpoint validation reached image persistence and failed with:

```text
Object of type device is not JSON serializable
```

While diagnostics attempted to record that failure, a registry plugin descriptor containing immutable `mappingproxy` fields was passed through `dataclasses.asdict`. That deep-copy operation failed with:

```text
cannot pickle 'mappingproxy' object
```

The second diagnostics failure masked the original output failure.

## Root causes

1. Generation manifests retained live runtime values from scheduler and sampler settings, including `torch.device` and `torch.dtype` objects.
2. Text and JSON sidecar formatters called `json.dumps` directly on those values.
3. Diagnostic serialization processed dataclasses with `asdict` before honoring their explicit `to_dict` methods.
4. `PluginDescriptor` is intentionally frozen and stores capabilities and configuration schemas in `MappingProxyType`; `asdict` therefore attempted an unsupported deep copy.
5. Failure-bundle creation was allowed to raise while handling another exception, replacing the original pipeline error.

## Repairs

- Runtime manifest values are normalized before being stored.
- JSON manifest output uses the shared JSON-safe serializer.
- Text sidecar formatting uses the same normalized data.
- Manifest dataclasses no longer use deep-copying `asdict` for runtime-bearing fields.
- Diagnostic serialization now honors `to_serializable_dict` and `to_dict` before generic dataclass handling.
- Generic dataclass handling reads fields without deep copying.
- Serialization now detects cyclic object references.
- Failure-bundle capture is guarded so diagnostics cannot mask the original stage error.
- A minimal fallback bundle is written if the full bundle writer itself fails.

## Validation

```text
Phase 07 serialization hotfix tests: 5 passed
Focused Phase 00-07 regression tests: 72 passed
Phase 00 baseline audit: PASS
Active-source compilation: PASS
Internal import validation: PASS
```

The real checkpoint itself was not available in the implementation environment. Local Phase 07 validation remains the acceptance gate.

## Local rerun

```bat
phase07_validate.bat --model "models\StableDiffusion\CheckPoints\Animore_v1.safetensors"
```

The run should now pass sidecar serialization. If a later model or pipeline problem occurs, diagnostics should preserve that original error and write either the full failure bundle or a clearly identified fallback bundle.
