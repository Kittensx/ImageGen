# Phase 00 Baseline Audit Report

## Status

**Implemented and validated with model-free focused checks.**

The phase adds one repeatable command that inventories the repository, compiles active Python source, audits internal imports, records a module dependency graph, captures environment/dependency information, and runs the current pipeline contract with fake components.

Run on Windows from the project root:

```bat
phase00_audit.bat
```

Direct Python command:

```bat
python scripts\audit\phase00_audit.py --print-known-issues
```

The generated machine-readable report is written to:

```text
artifacts/phase00_audit/phase00_audit_report.json
```

`artifacts/` remains excluded from source packaging because the report contains machine-specific paths and dependency information.

## Delivered audit checks

The audit performs these gates:

1. Compile every Python file classified as active without importing it.
2. Parse active imports and verify internal module paths.
3. Record directed internal dependency edges in the JSON report.
4. Distinguish approved baseline gaps from newly introduced unresolved imports.
5. Probe the Python/platform environment and declared dependencies.
6. Run a deterministic fake-component request through the current `CustomSDPipeline` contract.
7. Inject failures into each test stage and verify that the report identifies the responsible stage and system owner.

## Fake pipeline coverage

The test-only harness supplies:

- fake tokenizer
- fake text encoder
- fake UNet
- fake scheduler
- fake sampler
- fake VAE

The successful baseline request uses a `32 x 32` output, three sampling steps, six UNet calls for cond/uncond guidance, and one VAE decode. It returns a finite `1 x 3 x 32 x 32` image tensor without loading a checkpoint.

Intentional failures are captured for:

- `conditioning.tokenizer`
- `conditioning.text_encoder`
- `scheduling`
- `latent_preparation`
- `sampling`
- `denoising.unet`
- `decoding.vae`
- `result_validation`

## Source classification decisions

### Active

The supported CLI path, current runtime modules, adapters, registry code, configuration, launch tooling, documentation, and the new focused audit/test files are active.

### Legacy and compatibility

- `app/run.py` is now a Phase 01 compatibility redirect to the canonical CLI.
- `modules/generation_test.py` is a compatibility launcher for the canonical checkpoint smoke test.
- `modules/_imagecore/image_saver.py` remains legacy.

`run.bat` is no longer legacy; Phase 01 converted it to the canonical interactive launcher.

### Experimental

Research files under `docs/ideas/`, historical planning documents, the legacy KES configuration tree, and explicitly named idea/refactor files are experimental.

`modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/sampler_advanced.py` remains an **archived experiment** because no active source imports or registers it. Its baseline syntax and indentation defects have been repaired so it can still participate in repository-wide static checks.

### Generated

Package manifests, audit artifacts, generated sampler/scheduler maps, image output, traces, caches, and similar runtime products are generated and are not treated as source.

## Known baseline failures and ownership

| ID | Stage | Finding | Status / owner |
|---|---|---|---|
| P00-ENTRY-001 | entrypoint | `app/run.py` imported missing `modules.basic_load` | **Resolved in Phase 01** |
| P00-TEST-001 | validation | obsolete placeholder generation test | **Resolved in baseline stabilization** |
| P00-SAMPLER-001 | sampling | archived helper had invalid indentation and incomplete methods | **Resolved in baseline stabilization; remains unregistered** |
| P00-CONTRACT-001 | sampling/denoising | baseline samplers omitted the required timestep argument | **Resolved in Phase 03** |
| P00-CONFIG-001 | configuration | code expected a different config path than `user_config/user-config.yml` | **Resolved in Phase 01** |
| P00-OUTPUT-001 | output | core pipeline and runner could both save images | **Resolved in Phases 03-04** |
| P00-REGISTRY-001 | registry | sampler and scheduler discovery depended on `os.getcwd()` | **Resolved in Phase 01** |
| P00-IMPORT-* | contracts | historical guarded contract imports | **Resolved in Phase 02** |

The historical guarded contract gaps were resolved in Phase 02. Any newly unresolved active internal import remains a blocking Phase 00 failure. The audit now prints the exact source, line, and target module for such failures.

## Focused validation performed

```text
python scripts/audit/phase00_audit.py --print-known-issues
python -m unittest tests.phase00.test_phase00_baseline tests.phase00.test_phase00_baseline_repairs -v
```

Validated results:

- active-source compile gate: passed
- unapproved active internal-import gap gate: passed
- fake request to decoded image: passed
- intentional stage-failure identification: passed
- Phase 00 focused unit tests: 6 passed
- Phase 00-06 focused regression tests: 60 passed

No production checkpoint was loaded, no image-quality claim was made, and no repository-wide historical test suite was run.
