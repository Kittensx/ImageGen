# Phase 07 Output Directory Hotfix

## Problem

The Phase 07 validator created the run root under `artifacts/phase07_validation/<timestamp>/`, but it did not create the request-specific `images/baseline/` and `images/kes/` directories before calling `Txt2ImgRunner.run_request()`.

The runner performs configuration validation before image persistence. Because the requested output directory did not yet exist, validation stopped with `OUTPUT_ROOT_MISSING` before model loading or generation began.

## Repair

When image saving is enabled, `scripts/validation/phase07_validate.py` now creates both validation-owned image directories before constructing and running the first request.

The cache and temporary-root messages remain warnings and do not block validation.

## Scope

This is an orchestration correction only. It does not alter checkpoint inspection, architecture gates, sampler behavior, scheduler behavior, model loading, or image comparison thresholds.
