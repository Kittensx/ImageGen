# Batch Seeds, Output Naming, Batch Count, and Unlimited Generation Hotfix

## Corrected behavior

Each image in a batch now has an explicit effective seed.

For a batch size of 3 and a base seed of `100`, the images use:

* `100`
* `101`
* `102`

The initial latent for each image is created with its own generator. Therefore, rerunning only the second image with seed `101` recreates the same initial latent rather than merely continuing an opaque shared random-number stream.

The KES sampler's optional initial and stochastic noise also use one persistent generator per image seed. This preserves individual-image reproducibility when those optional noise features are enabled.

## Batch size and batch count

`batch_size` is the number of images generated together in one pipeline run.

`batch_count` is the number of pipeline runs.

Example:

```yaml
batch_size: 2
batch_count: 3
```

With a fixed seed of `100`, the three batches use:

* Batch 1: `100`, `101`
* Batch 2: `102`, `103`
* Batch 3: `104`, `105`

With seed `-1` or `null`, every batch chooses a new random base seed, then the images inside that batch advance sequentially from that base.

## Unlimited generation

Unlimited generation repeats batches until `Ctrl+C`.

When the requested seed is `-1` or `null`, every completed batch starts from a newly randomized base seed. Images within that batch remain sequential.

The interactive launcher now asks for:

* Batch size
* Batch count
* Unlimited generation
* Filename pattern

CLI examples:

```bat
python -m modules.txt2img.cli run --interactive --save
```

```bat
python -m modules.txt2img.cli run --config request.yml --batch-size 2 --batch-count 3 --save
```

```bat
python -m modules.txt2img.cli run --config request.yml --batch-size 2 --unlimited --save
```

## Output naming

The default user-facing filename pattern is:

```text
{index:05d}-{seed}
```

Example output:

```text
00001-1444000354.png
00002-1444000355.png
00003-89273114.png
```

The sequential index is discovered from existing image files in the output directory. It starts at `00001` when no numbered output exists.

A plain legacy prefix remains supported. For example, `phase03` still produces `phase03_0000001.png`.

Filename pattern fields include:

* `{index:05d}`
* `{seed}`
* `{datetime}`
* `{date}`
* `{time}`
* `{model}` or `{model_name}`
* `{vae}` or `{vae_name}`
* `{lora}` or `{lora_names}`
* `{sampler}`
* `{scheduler}`
* `{width}`
* `{height}`
* `{steps}`
* `{cfg_scale}`
* `{prompt}`
* `{batch_number}` and `{batch_count}` during CLI batch runs
* `{generation_mode}` (`batch_count` or `unlimited`)

Simple scalar or scalar-list fields stored in the generation manifest's extra data may also be referenced by name.

Example:

```text
{index:05d}-{seed}-{model}-{lora}-{vae}-{sampler}
```

A datetime-first option is:

```text
{datetime}-{seed}-{model}
```

Use `filename_pattern` in YAML/JSON request data, or use either `--filename-pattern` or the backward-compatible `--prefix` CLI option.

## Sidecar correction

Every image now receives its own manifest copy. The TXT and JSON sidecars record:

* The image's actual seed
* The complete image path
* The complete TXT path
* The complete JSON path
* The full batch seed list under `batch_resolved_seeds`
* The current image seed under `image_seed`

This also fixes the prior stale-path issue caused by mutating and reusing one manifest object for every image in a batch.
