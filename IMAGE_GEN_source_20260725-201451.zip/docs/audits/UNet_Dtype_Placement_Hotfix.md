# UNet dtype placement hotfix

## Purpose

Remove the repeated Diffusers warning produced when IMAGE_GEN casts a manually
constructed `UNet2DConditionModel` with `ModelMixin.to(dtype=...)`, while keeping
mixed-precision placement explicit and verifiable.

## Root cause

IMAGE_GEN constructs the UNet from a local config and then loads a converted
single-file checkpoint state dictionary. It therefore cannot use Diffusers'
normal `from_pretrained(..., torch_dtype=...)` path. The previous implementation
cast the same components twice:

1. `ComponentBuilder` moved and cast the UNet and text encoder.
2. `PipelineCompositionRoot.prepare_components()` moved and cast every component
   again.

Recent Diffusers versions warn whenever a dtype is supplied to
`ModelMixin.to()`, including the SD1 case where `_keep_in_fp32_modules` resolves
to an empty list.

## Repair

- Added `modules/component_placement.py` as the single precision-aware placement
  implementation.
- Initial checkpoint placement remains owned by `ComponentBuilder` and
  `LDMVAEBuilder`.
- The helper calls the base `torch.nn.Module.to()` implementation, avoiding the
  warning-producing Diffusers override.
- Any tensor whose name matches `_keep_in_fp32_modules` is explicitly restored
  to float32 and placement is verified.
- `PipelineCompositionRoot` no longer recasts correctly placed components. It
  only performs a safe compatibility repair for externally injected legacy
  components whose device or dtype differs.
- Final device/dtype placement is attached to each component and included in
  `PipelineComponents.describe()` and generation metadata, which places it in
  normal JSON manifests through `pipeline_metadata`.

## Non-goals

This patch does not change:

- DPM++ equations
- the high-sigma schedule
- model input preconditioning
- solver-state float32 behavior
- MSLK or xFormers selection

## Validation

Focused tests cover:

- bypassing a model-specific dtype-aware `to()` override;
- preserving configured float32 submodules;
- avoiding a duplicate composition-root cast;
- safe compatibility repair for injected components; and
- runtime placement metadata.

## CUDA device-index follow-up

The first real CUDA run exposed a verifier-only bug: the requested device was
stored as the unindexed PyTorch device `cuda`, while CUDA tensors correctly
reported their concrete device as `cuda:0`. Direct `torch.device` equality treats
those spellings as different even though `cuda` means the current CUDA device.

The placement verifier now normalizes implicit accelerator indexes before
comparison. It accepts `cuda` and the current concrete CUDA device as equivalent,
while still rejecting genuinely different explicit indexes such as `cuda:0`
versus `cuda:1`.
