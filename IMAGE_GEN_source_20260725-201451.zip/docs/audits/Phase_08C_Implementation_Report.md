# Phase 08C Implementation Report

**Project:** IMAGE_GEN  
**Phase:** 08C - Establish a Canonical Denoising Contract  
**Implemented:** 2026-07-25

## Status

Phase 8C is implemented and passes its model-free acceptance gate.

DPM++ 2M no longer interprets checkpoint output or performs a local epsilon-to-x0 conversion. It receives a canonical float32 predicted clean latent from `DenoisingSystem.predict_denoised()`.

The native high-sigma schedule remains unchanged. This phase does not cap sigma near the SD1 training maximum and does not alter DPM++ history behavior.

## Canonical Denoising Responsibilities

`DenoisingSystem` now owns:

- model-input preconditioning;
- explicit checkpoint prediction type;
- unconditional inference followed by conditional inference;
- classifier-free guidance;
- optional CFG rescaling;
- conversion from `epsilon`, `v_prediction`, or direct `sample/x0` output;
- conversion to canonical predicted x0;
- the float32 solver boundary;
- per-call prediction metadata and scalar diagnostics.

The canonical model input remains:

```text
model_input = solver_sample / sqrt(sigma^2 + 1)
```

The x0 conversion always uses the unmodified solver-state sample, not the preconditioned model input.

## Prediction Conversions

### Epsilon

```text
x0 = solver_sample - sigma * guided_epsilon
```

### V-prediction

For the Karras sigma parameterization used by the pipeline:

```text
x0 = solver_sample / (sigma^2 + 1)
     - sigma / sqrt(sigma^2 + 1) * guided_v
```

### Sample / x0

```text
x0 = guided_model_output
```

All canonical x0 outputs are float32.

## DPM++ Boundary

The generation pipeline attaches the canonical `predict_denoised` callback to the pipeline-guided denoising boundary. DPM++ 2M requires that callback and refuses an epsilon-only callback.

DPM++ now owns only:

- solver-state integration;
- first-order and second-order update selection;
- denoised history;
- sampler tracing and sampler-owned metadata.

It no longer owns:

- checkpoint prediction-type interpretation;
- CFG math;
- model-input scaling;
- epsilon-to-x0 conversion;
- v-prediction conversion.

## Prediction-Type Declaration

`PipelineComponents` now records:

```text
prediction_type
prediction_type_source
```

The supported SD1 checkpoint path declares `epsilon`. `ModelLoadingSystem` records whether the value came from checkpoint reporting, an architecture contract, or the legacy supported-checkpoint default.

## Manifest Metadata

The generation manifest records:

```text
prediction_type
prediction_conversion
model_input_preconditioning
cfg_scale
cfg_rescale
model_dtype
solver_dtype
sigma_used_for_prediction
model_timestep
```

The complete denoising contract also remains available under:

```text
extra.denoising_contract
```

## Tests

Added `tests/phase08/test_phase08c_canonical_denoising.py` covering:

- epsilon to x0;
- v-prediction to x0;
- x0/sample output to x0;
- CFG before conversion;
- unconditional and conditional branch ordering;
- float16 model boundary and float32 solver output;
- exact sigma use;
- solver-state sample versus preconditioned model input;
- DPM++ consumption of canonical x0 without calling epsilon guidance;
- truthful manifest metadata.

Updated Phase 8A, Phase 8B, and Phase 03 harnesses to supply the canonical callback directly instead of preserving a local sampler conversion fallback.

## Validation

```text
111 tests passed
31 subtests passed
```

The broad test command was:

```text
python -m pytest -q tests
```

A project-local focused command is available through:

```text
phase08c_tests.bat
```

## Next Phase

Proceed to Phase 8D first-order validation. Phase 8D should disable multistep history and use the canonical predicted-x0 output established here to determine whether first-order DPM++ produces coherent real-checkpoint images.
