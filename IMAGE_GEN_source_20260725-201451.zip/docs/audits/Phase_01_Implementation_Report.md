# Phase 01 Implementation Report

## Result

Phase 01 is complete. IMAGE_GEN now has one supported runtime entry, one visible project configuration, and one authoritative project-path context.

## Implemented changes

### Entrypoint convergence

- `run.bat` now invokes `python -m modules.txt2img.cli run --interactive`.
- `run_cli.bat` is retained as a compatibility launcher and invokes the same command.
- `app/run.py` no longer imports the missing `modules.basic_load`; it redirects to the canonical CLI and emits a deprecation warning.

### Canonical configuration

- `user_config/user-config.yml` is now loaded by production code.
- Existing path and generation settings were retained and expanded with tokenizer, cache, temporary, ControlNet, embedding, and hypernetwork paths.
- Project configuration defaults are the base generation payload; request files and explicit CLI values override them.

### Project context

- Added `modules/project_context.py`.
- Project and runtime paths are resolved from the source location or an explicit project root.
- Relative paths do not depend on the current working directory.
- `ConfigOptions` is now a read-only compatibility facade over `ProjectContext`.
- `LoadModel`, `Txt2ImgRunner`, `ModelSelector`, and sampler/scheduler registry discovery receive or derive their paths from `ProjectContext`.

### Preflight commands

Added:

```text
python -m modules.txt2img.cli config show
python -m modules.txt2img.cli config validate
```

Both commands support `--json`, `--project-root`, and `--project-config`. Validation detects missing model, checkpoint, tokenizer, local-config, and output paths before model loading.

### Removed hidden configuration side effects

`ConfigOptions.__init__` no longer creates model libraries, data directories, output directories, or user configuration directories. An explicit `ensure_runtime_directories()` compatibility method is available for callers that intentionally want to create writable runtime directories.

## Resolved Phase 00 findings

- `P00-ENTRY-001`: resolved by canonical launcher convergence and compatibility redirect.
- `P00-CONFIG-001`: resolved by loading `user_config/user-config.yml` through `ProjectContext`.
- `P00-REGISTRY-001`: resolved by removing `os.getcwd()` from sampler and scheduler registry path discovery.

The Phase 00 audit generator no longer reports these findings as current issues.

## Focused validation

```text
python -m unittest tests.phase01.test_phase01_project_context -v
python -m unittest tests.phase00.test_phase00_baseline -v
python scripts/audit/phase00_audit.py --print-known-issues
```

Results:

- Phase 01 project-context tests: 7 passed
- Phase 00 fake-pipeline regression tests: 2 passed
- active-source compilation: passed
- unapproved active internal-import gaps: none
- project context is stable across working directories
- visible user configuration supplies effective generation defaults
- missing model/tokenizer/output paths are detected before generation

No production checkpoint was loaded, and Phase 01 does not claim that the image-generation math is repaired. Those corrections remain assigned to Phases 02 and 03.
