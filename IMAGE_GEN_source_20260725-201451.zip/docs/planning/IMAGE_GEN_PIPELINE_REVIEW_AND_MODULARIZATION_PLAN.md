# IMAGE_GEN Pipeline Review and Modularization Plan

## Decision

The current project should **not** be rewritten from scratch and does **not** need Avalonia to gain the modular benefits used in Illusive Walls and Entigra.

The source already contains the beginnings of a sound modular architecture:

- prompt conditioning adapter
- scheduler adapter
- sampler adapters
- sampler and scheduler registries
- model inspection and component construction
- generation request and result objects
- output manifest and image saver
- a CLI runner

The problem is not the choice of Python or the lack of Avalonia. The problem is that the module boundaries are only partially enforced. Several generations of the pipeline coexist, contracts have drifted, orchestration is duplicated, and diagnostic code is mixed into production execution.

The recommended direction is:

1. **Repair and characterize the existing pipeline first.**
2. **Establish one canonical set of runtime contracts.**
3. **Extract each pipeline responsibility into a Python system module.**
4. **Keep compatibility shims while the existing files are migrated.**
5. **Validate each system independently before judging final image quality.**

This is a repair-first, modularize-second plan.

---

## Current Pipeline Map

The intended active path appears to be:

```text
run_cli.bat
  -> modules.txt2img.cli
  -> sampler/scheduler registry discovery
  -> request loading and model selection
  -> Txt2ImgRunner
  -> checkpoint inspection and component construction
  -> PipelineBuilder / CustomSDPipeline
      -> prompt conditioning
      -> schedule construction
      -> latent creation
      -> sampler loop
      -> UNet noise prediction
      -> VAE decoding
  -> output saver and generation manifest
```

A second, older path still exists:

```text
run.bat
  -> app/run.py
  -> modules.basic_load.BasicLoad
```

That older path cannot currently start because `modules.basic_load` is not present in the supplied source.

---

## Important Findings From the Supplied Source

### 1. The project is repairable

The core pipeline concepts are already present. The source is not an unstructured prototype that requires a total rewrite. The best approach is to preserve working model-loading, parsing, KES scheduling, and registry behavior while replacing ambiguous boundaries around them.

### 2. There is no single canonical entry point

- `run.bat` starts the obsolete `app/run.py` path.
- `run_cli.bat` starts the newer `modules.txt2img.cli` path.
- `modules/generation_test.py` is a placeholder that imports adapter modules that do not exist.

The CLI path should become the only supported runtime entry point during stabilization.

### 3. The runtime contracts have drifted

The project correctly recognizes two sampler paths:

- **KES path:** raw UNet prediction; sampler owns cond/uncond mixing and CFG.
- **Baseline path:** guided prediction; pipeline owns CFG.

However, the baseline samplers call `guided_model_fn` without the timestep argument required by `CustomSDPipeline.predict_guided_noise`. This is a direct contract mismatch and should be repaired before image-quality debugging.

Other contract drift includes:

- `SchedulerOutput` stores requested/effective step information in `extra`, while callers sometimes read direct attributes.
- `SamplerOutput` is independently redefined in multiple files.
- adapter protocols are duplicated between `pipeline_builder.py` and `adapters/base.py`.
- some files import `modules.pipeline.pipeline_builder`, but the actual module is `modules.pipeline_builder`.

### 4. Output ownership is duplicated

`CustomSDPipeline.generate()` can save images, and `Txt2ImgRunner.run_request()` can save the same decoded images again through the manifest-aware output saver.

Only one layer should own file output. The recommended owner is the output system above the core pipeline. The core pipeline should return tensors/results and should not choose filenames or write sidecars.

### 5. Configuration paths are inconsistent

`ConfigOptions` looks for:

```text
modules/user_config/config.yaml
```

The supplied project contains:

```text
user_config/user-config.yml
```

As a result, the visible user configuration is not the configuration currently loaded by `ConfigOptions`.

### 6. Runtime discovery depends on the current working directory

The sampler and scheduler registries derive paths from `os.getcwd()`. This is fragile when launched from another directory, imported by tests, or eventually used by another interface.

All runtime roots should be resolved from an explicit project context or package path.

### 7. Debugging code is mixed into normal execution

`pipeline_builder.py`, `txt2img_runner.py`, prompt conditioning, scheduler adapters, and sampler adapters contain unconditional diagnostic printing. This makes failures noisy without creating a stable diagnostic record.

Diagnostics should become opt-in, structured, and associated with a generation run ID.

### 8. There are multiple incomplete or obsolete files

The supplied source contains:

- a syntax error in `sampler_advanced.py`
- a syntax error in `docs/ideas/more_mem_optim.py`
- missing imports in the obsolete launcher and placeholder generation test
- an old `_imagecore/image_saver.py` implementation with a mismatched `normalize_float` attribute
- an unused `FrozenCLIPEmbedder` import in component construction
- a duplicate module-level adapter-instantiation helper in `txt2img_runner.py`

These should be classified as active, experimental, compatibility-only, or retired rather than left in the same runtime surface.

### 9. There is no real automated test suite

There are useful diagnostic scripts, but no focused tests that prove contracts between systems. Without those tests, a sampler, scheduler, tokenizer, or model-loading upgrade can break a distant part of the pipeline.

### 10. Architecture support should be proven rather than inferred

The repository contains local SD1, SD2, and SDXL configuration manifests, but the active pipeline has a single text encoder/tokenizer contract and fixed four-channel latent construction. Each architecture should have an explicit capability declaration and validation suite. Presence of configuration files alone should not be treated as proof of complete runtime support.

---

## Recommended Modular Target

The target is a Python package with explicit system boundaries. Avalonia is not required.

```text
src/
`-- image_gen/
    |-- contracts/
    |   |-- requests.py
    |   |-- components.py
    |   |-- conditioning.py
    |   |-- schedules.py
    |   |-- sampling.py
    |   `-- results.py
    |
    |-- runtime/
    |   |-- composition.py
    |   |-- generation_pipeline.py
    |   |-- generation_session.py
    |   `-- project_context.py
    |
    |-- systems/
    |   |-- configuration/
    |   |-- model_loading/
    |   |-- conditioning/
    |   |-- scheduling/
    |   |-- sampling/
    |   |-- denoising/
    |   |-- decoding/
    |   |-- output/
    |   |-- registry/
    |   `-- diagnostics/
    |
    |-- interfaces/
    |   `-- cli/
    |
    `-- compatibility/
        `-- legacy_modules.py
```

### What each system owns

| System | Owns | Must not own |
|---|---|---|
| Configuration | project paths, user settings, defaults, validation | model loading or generation |
| Model loading | checkpoint inspection, architecture detection, state mapping, component construction | prompts, schedules, output naming |
| Conditioning | tokenization, prompt parsing, cond/uncond schedules | sampling integration |
| Scheduling | sigmas, timesteps, compatibility metadata | UNet calls or CFG |
| Sampling | integration loop, sampler-specific CFG policy | model loading, image saving |
| Denoising | the one canonical UNet call contract and model-input scaling | schedule discovery or output |
| Decoding | latent-to-image tensor conversion | filenames, manifests, registry scans |
| Output | image files, sidecars, manifests, collision-safe naming | inference math |
| Registry | plugin discovery, metadata, capability validation | current working directory assumptions |
| Diagnostics | structured events, traces, stage timing, failure reports | unconditional console noise |
| Runtime | composes systems and controls generation order | system-specific implementation details |

---

## Migration Rules

1. Do not move every file at once.
2. Do not combine architecture changes with image-quality tuning in the same phase.
3. Add tests around the existing behavior before moving a subsystem.
4. Move one responsibility at a time and leave a temporary import shim at the old path.
5. Keep KES and baseline sampler behavior distinct, but make both implement the same adapter contract.
6. The runtime pipeline returns data; the output system writes files.
7. Configuration and project paths are injected, not inferred from `os.getcwd()`.
8. No phase is complete unless its focused tests pass without requiring a production checkpoint, except the real-model validation phase.

---

## Phase Sequence

### Phase 00 - Baseline Audit and Reproducible Failure Capture

Create a repeatable baseline before changing runtime code.

Deliverables:

- canonical pipeline map
- active/legacy/experimental file classification
- import and syntax audit
- fake-component generation harness
- current failure report with stage ownership
- environment and dependency report

Exit gate:

- the project can reproduce failures through one command
- failures identify a named stage instead of presenting an undifferentiated stack trace

### Phase 01 - Entrypoint, Configuration, and Project Context

Make one supported launcher and one path/configuration authority.

Deliverables:

- `run.bat` and `run_cli.bat` converge on the canonical CLI runtime
- obsolete `app/run.py` path is retired or converted to a compatibility launcher
- user configuration location and filename are made canonical
- project, data, model, output, tokenizer, and cache paths come from a `ProjectContext`
- constructors stop creating unrelated directories as hidden side effects
- registry discovery stops depending on `os.getcwd()`

Exit gate:

- launch behavior is identical from the project root and from another working directory
- the effective configuration can be printed and validated before model loading

### Phase 02 - Canonical Contracts

Create a single contract package and remove type drift.

Deliverables:

- one `GenerationRequest`
- one `PipelineComponents`
- one `ConditioningOutput`
- one `SchedulerOutput`
- one `SamplerOutput`
- one `GenerationResult`
- one prompt/scheduler/sampler adapter protocol set
- explicit sampler capability metadata
- explicit scheduler compatibility result

Important decision retained:

- KES receives `raw_model_fn` and owns CFG.
- baseline samplers receive `guided_model_fn` and use pipeline-owned CFG.
- both paths receive sigma and timestep explicitly.

Exit gate:

- protocol conformance tests pass for KES, Simple Euler, and DPM++ 2M adapters
- no runtime contract dataclass is redefined in a sampler or adapter file

### Phase 03 - Pipeline Correctness Repair

Repair the existing end-to-end math and ownership before extracting more modules.

Deliverables:

- fix the baseline `guided_model_fn` timestep mismatch
- standardize sigma/timestep materialization
- validate initial latent scaling policy
- validate model-input scaling policy
- validate epsilon/noise versus denoised output conventions
- make scheduled conditioning resolution consistent across samplers
- normalize VAE decode return handling
- remove image writing from the core pipeline
- prevent double image saves
- normalize seed semantics, including random-seed requests

Exit gate:

- fake UNet/VAE tests complete a deterministic generation pass
- each sampler executes the expected number of model calls
- KES and baseline CFG ownership tests pass
- one request produces one saved image set and one manifest set

### Phase 04 - Extract System Modules

Move responsibilities out of the two orchestration-heavy files without changing behavior.

Deliverables:

- model-loading system
- conditioning system
- scheduling system
- denoising system
- sampling system
- decoding system
- output system
- thin runtime composition root
- compatibility imports for old module paths

`pipeline_builder.py` should become either a small compatibility facade or be retired after callers migrate.

`txt2img_runner.py` should become a thin use-case coordinator rather than owning registry resolution, model loading, composition, debugging, manifest construction, and output writing itself.

Exit gate:

- each system has a focused test suite
- runtime composition can substitute fake systems without loading Diffusers, Transformers, or a checkpoint

### Phase 05 - Registry and Plugin Architecture

**Status: implemented 2026-07-25.**

Turn sampler and scheduler discovery into validated plugins.

Deliverables:

- canonical plugin descriptor schema
- deterministic discovery from package/project context
- unique IDs, names, and aliases
- adapter class declaration
- capability declaration
- configuration schema declaration
- validation errors for incomplete plugins
- no generated Python registry map required for runtime
- generated registry reports remain optional diagnostics only

Exit gate:

- malformed plugins are rejected with actionable messages
- KES, Simple Euler, and DPM++ 2M are discoverable through the same registry contract

### Phase 06 - Diagnostics and Testability

Make troubleshooting a first-class system.

Deliverables:

- structured logging with run ID and stage name
- configurable verbosity
- per-stage timings
- tensor shape/dtype/device summaries without full tensor dumps
- optional sampler trace export
- failure bundle containing effective config, request, component report, schedule report, sampler report, and traceback
- unit, contract, integration, and checkpoint smoke-test tiers

Exit gate:

- a failed generation identifies the failing system and preserves enough context to reproduce it
- normal runs are readable without debug-print flooding

### Phase 07 - Real Checkpoint Validation

Validate correctness with controlled real models after the architecture is stable.

Deliverables:

- one known SD1 checkpoint validation profile
- fixed seeds and golden metadata
- tokenizer and conditioning checks
- model-load key coverage report
- sigma/timestep trace review
- latent statistics at defined checkpoints
- VAE decode validation
- sampler comparison matrix
- output reproducibility checks

SD2 and SDXL should be separate capability expansions after SD1 is proven. SDXL must not be declared supported until its dual-encoder and conditioning requirements are explicitly implemented and tested.

Exit gate:

- a fixed SD1 request produces a valid, reproducible image without contract warnings
- failures can be assigned to loading, conditioning, scheduling, denoising, sampling, decoding, or output

### Phase 08A - DPM++ 2M Controlled Failure Isolation

Prove why the first history-sensitive denoised-space sampler fails before changing production behavior.

Deliverables:

- sequential runner for every registered sampler under the current Simple KES scheduler
- three fixed prompt/seed cases reconstructed from the supplied sampler tests
- DPM++ 2M A/B/C/D matrix separating native versus model-bounded schedule behavior and latent versus float32 solver arithmetic
- complete sigma/timestep clipping and duplication evidence
- per-step epsilon, denoised, latent, coefficient, and history traces
- incremental JSON and Markdown reports

Exit gate:

- the local real-checkpoint matrix identifies whether schedule domain, solver precision, or both are responsible for the DPM++ 2M failure
- no normal generation default changes during isolation

### Phase 08B-08D - Standard Sampler Correctness

Use the Phase 08A evidence to implement the reusable standard-sampler schedule bridge, canonical denoised prediction boundary, float32 multistep solver core, reference parity tests, and real-checkpoint acceptance matrix.

Exit gate:

- DPM++ 2M produces coherent prompt-related images across the fixed matrix
- positive sigma clipping and duplicated positive timesteps are rejected for standard multistep samplers
- the integrator matches a test-local reference implementation under the same denoiser callback and schedule

### Phase 09 - Cleanup and Upgrade Readiness

Remove migration debris and document the extension process.

Deliverables:

- retire broken launchers and placeholder tests
- move experimental code out of runtime packages
- remove duplicate savers, contracts, and unused imports
- correct dependency declarations
- package initialization and import cleanup
- developer guide for adding a model architecture
- developer guide for adding a sampler
- developer guide for adding a scheduler
- troubleshooting runbook
- architecture decision record explaining raw versus guided denoiser paths

Exit gate:

- source compilation is clean
- active runtime imports are clean
- no production package contains known syntax errors
- extension guides are verified by adding or validating a small example plugin

---

## Recommended Test Layers

### Layer 1 - Static and import checks

- compile active Python source
- verify all internal imports
- validate configuration files
- validate registry descriptors

### Layer 2 - Contract tests with fakes

- fake tokenizer/text encoder
- fake UNet
- fake scheduler
- fake sampler
- fake VAE
- fake output store

These tests should run without a model checkpoint and without a GPU.

### Layer 3 - System integration tests

- request -> conditioning
- request -> schedule
- schedule + conditioning -> sampler
- latents -> decode
- result -> manifest/output

### Layer 4 - Real checkpoint smoke tests

- one prompt
- one seed
- low step count
- one supported architecture at a time
- no broad model matrix until the basic path is stable

### Layer 5 - Image-quality and regression tests

Image quality should be evaluated only after contract and numeric correctness are established. Otherwise, visual defects can be incorrectly blamed on the model, prompt, or sampler when the problem is actually a timestep, scaling, CFG, or decode mismatch.

---

## What Should Be Fixed Before Modular Extraction

These are immediate blockers and should be handled before large file moves:

1. Make the CLI the canonical entry point.
2. Fix configuration discovery.
3. Fix the baseline guided-denoiser signature.
4. Create one contract source.
5. Stop duplicate output saving.
6. Remove direct-attribute versus `extra` ambiguity from schedule results.
7. Add fake-component tests.
8. Classify or quarantine syntax-invalid experimental files.

---

## What Should Not Be Done Yet

- Do not move to Avalonia solely for modularity.
- Do not build a GUI before the runtime API is stable.
- Do not rewrite KES from scratch.
- Do not add more samplers or schedulers before the existing contracts are proven.
- Do not tune image quality while output conventions remain uncertain.
- Do not claim broad SDXL support based only on local config files.
- Do not delete legacy files until compatibility shims and tests prove they are no longer used.

---

## Final Recommendation

The modular system approach would significantly improve future troubleshooting and upgrades, but the right implementation is an **incremental Python modularization**, not a framework migration.

The source already has enough architecture to save. The highest-value work is to formalize its contracts, separate runtime responsibilities, and add tests that isolate each stage. After that, replacing a scheduler, upgrading Transformers or Diffusers, changing the tokenizer, adding a sampler, or introducing a future UI will affect one system rather than forcing another whole-pipeline investigation.
