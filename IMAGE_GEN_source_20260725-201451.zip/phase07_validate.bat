@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=%~dp0.venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=py -3.10"

if "%~1"=="" (
    echo IMAGE_GEN - Phase 07 Real Checkpoint Validation
    echo.
    echo Usage:
    echo   phase07_validate.bat --model "models\StableDiffusion\CheckPoints\model.safetensors"
    echo.
    echo Preflight only:
    echo   phase07_validate.bat --model "..." --preflight-only
    echo.
    echo Architecture capability status:
    echo   phase07_validate.bat --capabilities
    echo.
    pause
    exit /b 2
)

%PYTHON_EXE% scripts\validation\phase07_validate.py %*
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" (
    color 4F
    echo Phase 07 validation failed. Exit code: %EXIT_CODE%
) else (
    echo Phase 07 validation completed successfully.
)
pause
exit /b %EXIT_CODE%
