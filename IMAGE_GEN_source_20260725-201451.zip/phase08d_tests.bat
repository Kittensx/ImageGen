@echo off
setlocal
cd /d "%~dp0"

set "PYTHON_EXE=%CD%\venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" set "PYTHON_EXE=python"

"%PYTHON_EXE%" -m pytest -q tests\phase08\test_phase08d_first_order_validation.py
exit /b %ERRORLEVEL%
