@echo off
setlocal
cd /d "%~dp0"
title IMAGE_GEN - txt2img

set "PYTHON_EXE=%~dp0venv\Scripts\python.exe"
if not exist "%PYTHON_EXE%" (
    color 4F
    echo ERROR: IMAGE_GEN virtual environment was not found:
    echo   %PYTHON_EXE%
    echo.
    echo Create or restore the venv before launching IMAGE_GEN.
    pause
    exit /b 1
)

"%PYTHON_EXE%" -m modules.txt2img.cli run --interactive --save
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" echo IMAGE_GEN exited with code %EXIT_CODE%.
pause
exit /b %EXIT_CODE%
