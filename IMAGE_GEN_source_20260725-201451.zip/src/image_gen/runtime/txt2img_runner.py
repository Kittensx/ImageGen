from __future__ import annotations

import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any, Callable

import torch

from image_gen.contracts import GenerationRequest, GenerationResult
from image_gen.runtime.composition import PipelineCompositionRoot
from image_gen.systems.diagnostics import (
    DiagnosticSession,
    DiagnosticsSystem,
    PipelineStageError,
)
from image_gen.systems.model_loading import ModelLoadingSystem
from image_gen.systems.output import OutputSystem
from image_gen.systems.registry import RuntimeRegistrySystem
from modules.pipeline.progress_reporter import ProgressReporter
from modules.project_context import ProjectContext
from modules.shared_state import SharedState
from modules.txt2img.output_saver import SavedImageRecord
from modules.txt2img.request_loader import load_request_payload, payload_to_generation_request


@dataclass
class Txt2ImgRunResult:
    request: GenerationRequest
    request_extras: dict[str, Any] = field(default_factory=dict)
    pipeline_result: GenerationResult = field(default_factory=GenerationResult)
    manifest: Any | None = None
    saved_records: list[SavedImageRecord] = field(default_factory=list)
    generation_time_sec: float | None = None
    run_id: str | None = None
    diagnostics: dict[str, Any] = field(default_factory=dict)




def _prepare_output_directory(
    project_context: ProjectContext,
    request: GenerationRequest,
    *,
    should_save: bool,
) -> Path | None:
    """Create the runtime-owned output directory before path validation."""
    request.save_images = bool(should_save)
    if not should_save:
        return None

    configured_output = request.output_dir or project_context.txt2img_output_root
    output_path = Path(str(configured_output)).expanduser()
    if not output_path.is_absolute():
        output_path = project_context.resolve_project_path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    output_path = output_path.resolve()
    request.output_dir = str(output_path)
    return output_path


def _verify_saved_records(records: list[SavedImageRecord]) -> list[SavedImageRecord]:
    """Require at least one real image file when persistence was requested."""
    if not records:
        raise RuntimeError(
            "Image saving was requested, but the output system returned no saved records."
        )
    missing = [record.image_path for record in records if not Path(record.image_path).is_file()]
    if missing:
        raise RuntimeError(
            "The output system reported image paths that do not exist: "
            + ", ".join(missing)
        )
    return records


class Txt2ImgRunner:
    """Use-case coordinator for loading, generation, diagnostics, and output."""

    def __init__(
        self,
        *,
        prompt_adapter: Any | None = None,
        scheduler_adapter: Any | None = None,
        sampler_adapter: Any | None = None,
        prompt_adapter_factory: Callable[..., Any] | None = None,
        scheduler_adapter_factory: Callable[..., Any] | None = None,
        sampler_adapter_factory: Callable[..., Any] | None = None,
        model_loader: Any | None = None,
        project_context: ProjectContext | None = None,
        state: Any | None = None,
        tokenizer: Any = None,
        device: torch.device | None = None,
        dtype: torch.dtype | None = None,
        latent_scale_factor: int = 8,
        vae_scaling_factor: float = 0.18215,
        registry_system: RuntimeRegistrySystem | None = None,
        output_system: OutputSystem | None = None,
        model_loading_system: ModelLoadingSystem | None = None,
        diagnostics_system: DiagnosticsSystem | None = None,
        system_overrides: dict[str, Any] | None = None,
    ) -> None:
        self.prompt_adapter = prompt_adapter
        self.scheduler_adapter = scheduler_adapter
        self.sampler_adapter = sampler_adapter
        self.prompt_adapter_factory = prompt_adapter_factory
        self.scheduler_adapter_factory = scheduler_adapter_factory
        self.sampler_adapter_factory = sampler_adapter_factory

        inherited_context = getattr(model_loader, "context", None)
        self.project_context = project_context or inherited_context or ProjectContext.load()
        if model_loader is None:
            from modules.load_safetensors_model import LoadModel

            model_loader = LoadModel(project_context=self.project_context)
        self.model_loader = model_loader
        self.state = state or SharedState()
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.dtype = dtype or (torch.float16 if self.device.type == "cuda" else torch.float32)
        self.latent_scale_factor = int(latent_scale_factor)
        self.vae_scaling_factor = float(vae_scaling_factor)
        self.system_overrides = dict(system_overrides or {})

        override_diagnostics = self.system_overrides.get("diagnostics")
        self.diagnostics_system = (
            diagnostics_system
            or override_diagnostics
            or DiagnosticsSystem.from_project_context(self.project_context)
        )
        self.system_overrides["diagnostics"] = self.diagnostics_system

        self.registry_system = registry_system or RuntimeRegistrySystem(
            self.state, project_context=self.project_context
        )
        self.registry_system.bind_state(self.state)
        self.output_system = output_system or OutputSystem()
        self.model_loading_system = model_loading_system or ModelLoadingSystem(self.model_loader)
        self.tokenizer = tokenizer
        self._loaded_model_cache: dict[tuple[str, str, str, int, int], Any] = {}
        self.last_loaded_model: Any | None = None


    def clear_model_cache(self) -> None:
        """Release cached real-checkpoint components between validation sessions."""
        self._loaded_model_cache.clear()
        self.last_loaded_model = None
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def reset_runtime_state(self) -> None:
        """Reset request-scoped mutable state while retaining loaded components."""
        self.state = SharedState()
        self.registry_system.bind_state(self.state)

    def _build_local_tokenizer(self):
        local_dir = self.project_context.tokenizer_root
        if not local_dir.exists():
            raise FileNotFoundError(f"Missing local tokenizer directory: {local_dir}")
        from transformers import CLIPTokenizer

        return CLIPTokenizer.from_pretrained(str(local_dir), local_files_only=True)

    def _resolve_adapter(
        self,
        direct: Any,
        factory: Callable[..., Any] | None,
        *,
        request: GenerationRequest,
        extras: dict[str, Any],
        resolved_entry_key: str | None = None,
        resolved_descriptor_key: str | None = None,
    ) -> Any:
        if direct is not None:
            return direct
        if resolved_descriptor_key:
            adapter = self.registry_system.instantiate_adapter(extras.get(resolved_descriptor_key))
            if adapter is not None:
                return adapter
        if resolved_entry_key:
            adapter = self.registry_system.instantiate_adapter(extras.get(resolved_entry_key))
            if adapter is not None:
                return adapter
        if factory is None:
            raise ValueError("Missing adapter and factory for required pipeline component.")
        return factory(request=request, extras=extras, state=self.state)

    def _resolve_adapters(
        self,
        request: GenerationRequest,
        extras: dict[str, Any],
    ) -> tuple[Any, Any, Any]:
        return (
            self._resolve_adapter(
                self.prompt_adapter,
                self.prompt_adapter_factory,
                request=request,
                extras=extras,
            ),
            self._resolve_adapter(
                self.scheduler_adapter,
                self.scheduler_adapter_factory,
                request=request,
                extras=extras,
                resolved_entry_key="resolved_scheduler_entry",
                resolved_descriptor_key="resolved_scheduler_descriptor",
            ),
            self._resolve_adapter(
                self.sampler_adapter,
                self.sampler_adapter_factory,
                request=request,
                extras=extras,
                resolved_entry_key="resolved_sampler_entry",
                resolved_descriptor_key="resolved_sampler_descriptor",
            ),
        )

    def _configure_runtime_state(
        self,
        extras: dict[str, Any],
        session: DiagnosticSession,
    ) -> None:
        progress_reporter = ProgressReporter(
            enabled=session.config.progress,
            desc="Sampling",
            unit="step",
        )
        extras["progress_reporter"] = progress_reporter
        if hasattr(self.state, "extra"):
            self.state.extra["progress_reporter"] = progress_reporter
        if hasattr(self.state, "d"):
            self.state.d.device = self.device
            self.state.d.device_type = self.device.type
            if self.device.index is not None:
                self.state.d.device_index = self.device.index

    def _build_pipeline(
        self,
        request: GenerationRequest,
        extras: dict[str, Any],
        session: DiagnosticSession,
    ):
        prompt_adapter, scheduler_adapter, sampler_adapter = self._resolve_adapters(request, extras)
        model_path = extras.get("model_path") or self.model_loading_system.default_model_path
        if not model_path:
            raise ValueError("No model_path provided in request extras and no default MODEL_PATH found.")

        if self.tokenizer is None:
            self.tokenizer = self.diagnostics_system.run_stage(
                session,
                "model_loading",
                "load_tokenizer",
                self._build_local_tokenizer,
            )
        model_file = Path(str(model_path)).expanduser().resolve()
        if model_file.is_file():
            stat = model_file.stat()
            load_path = str(model_file)
            cache_key = (
                load_path,
                str(self.dtype),
                str(self.device),
                int(stat.st_size),
                int(stat.st_mtime_ns),
            )
        else:
            # Injected/fake loaders used by focused tests may use a symbolic path.
            load_path = str(model_path)
            cache_key = (str(model_file), str(self.dtype), str(self.device), -1, -1)
        loaded = self._loaded_model_cache.get(cache_key)
        if loaded is None:
            loaded = self.diagnostics_system.run_stage(
                session,
                "model_loading",
                "load_checkpoint",
                lambda: self.model_loading_system.load(
                    load_path,
                    tokenizer=self.tokenizer,
                    dtype=self.dtype,
                ),
            )
            self._loaded_model_cache.clear()
            self._loaded_model_cache[cache_key] = loaded
        else:
            self.diagnostics_system.emit(
                session,
                "info",
                "model_loading",
                "reuse_checkpoint",
                "reused loaded checkpoint components",
                model_path=str(model_file),
            )
        self.last_loaded_model = loaded
        self.diagnostics_system.update_components(session, loaded.components)
        return PipelineCompositionRoot(
            components=loaded.components,
            prompt_adapter=prompt_adapter,
            scheduler_adapter=scheduler_adapter,
            sampler_adapter=sampler_adapter,
            latent_scale_factor=self.latent_scale_factor,
            vae_scaling_factor=self.vae_scaling_factor,
            device=self.device,
            dtype=self.dtype,
            system_overrides=self.system_overrides,
        ).build(state=self.state)

    def run_request(
        self,
        request: GenerationRequest,
        extras: dict[str, Any] | None = None,
        *,
        save_images: bool | None = None,
        save_txt: bool = True,
        save_json: bool = True,
    ) -> Txt2ImgRunResult:
        should_save = request.save_images if save_images is None else bool(save_images)
        _prepare_output_directory(
            self.project_context,
            request,
            should_save=should_save,
        )

        extras = dict(extras or {})
        effective_config_fn = getattr(self.project_context, "effective_config", None)
        effective_config = (
            effective_config_fn()
            if callable(effective_config_fn)
            else {
                "project_root": str(
                    getattr(self.project_context, "project_root", ".")
                )
            }
        )
        session = self.diagnostics_system.start(
            request,
            effective_config=effective_config,
            request_extras=extras,
        )
        try:
            model_path = extras.get("model_path") or self.model_loading_system.default_model_path
            self.diagnostics_system.run_stage(
                session,
                "configuration",
                "validate_generation_paths",
                lambda: self.project_context.require_generation_ready(
                    model_path=model_path,
                    output_dir=request.output_dir,
                    require_output=should_save,
                ),
            )
            request.device = str(self.device)
            self._configure_runtime_state(extras, session)
            request, extras = self.diagnostics_system.run_stage(
                session,
                "registry",
                "resolve_plugins",
                lambda: self.registry_system.apply_resolution(request, extras),
            )
            session.request_extras.update(
                {
                    key: value
                    for key, value in extras.items()
                    if key != "progress_reporter"
                }
            )
            pipeline = self.diagnostics_system.run_stage(
                session,
                "runtime",
                "compose_pipeline",
                lambda: self._build_pipeline(request, extras, session),
            )

            started = time.perf_counter()
            pipeline_result = pipeline.generate(request, diagnostic_session=session)
            generation_time_sec = time.perf_counter() - started

            manifest = self.diagnostics_system.run_stage(
                session,
                "output",
                "build_manifest",
                lambda: self.output_system.build_manifest(
                    request=request,
                    extras=extras,
                    pipeline_result=pipeline_result,
                    generation_time_sec=generation_time_sec,
                    device_name=str(self.device),
                ),
            )
            saved_records: list[SavedImageRecord] = []
            if should_save:
                output_dir = request.output_dir or extras.get("output_dir")
                if not output_dir:
                    raise ValueError("An output directory is required when saving images.")
                def save_and_verify_outputs() -> list[SavedImageRecord]:
                    records = self.output_system.save(
                        pipeline_result=pipeline_result,
                        request=request,
                        manifest=manifest,
                        output_dir=str(output_dir),
                        save_txt=save_txt,
                        save_json=save_json,
                    )
                    return _verify_saved_records(records)

                saved_records = self.diagnostics_system.run_stage(
                    session,
                    "output",
                    "save",
                    save_and_verify_outputs,
                )

            diagnostics_summary = self.diagnostics_system.complete(
                session, result=pipeline_result
            )
            pipeline_result.metadata["diagnostics"] = diagnostics_summary
            return Txt2ImgRunResult(
                request=request,
                request_extras=extras,
                pipeline_result=pipeline_result,
                manifest=manifest,
                saved_records=saved_records,
                generation_time_sec=generation_time_sec,
                run_id=session.run_id,
                diagnostics=diagnostics_summary,
            )
        except PipelineStageError:
            raise
        except Exception as exc:
            raise self.diagnostics_system.fail_unassigned(
                session, exc, system="runtime", operation="run_request"
            ) from exc

    def run_from_sources(
        self,
        *,
        config_path: str | None = None,
        manifest_path: str | None = None,
        infotext_path: str | None = None,
        cli_overrides: dict[str, Any] | None = None,
        base_payload: dict[str, Any] | None = None,
        extras: dict[str, Any] | None = None,
        save_txt: bool = True,
        save_json: bool = True,
    ) -> Txt2ImgRunResult:
        payload = load_request_payload(
            config_path=config_path,
            manifest_path=manifest_path,
            infotext_path=infotext_path,
            cli_overrides=cli_overrides,
            base_payload=base_payload,
        )
        request, payload_extras = payload_to_generation_request(payload)
        merged_extras = dict(extras or {})
        merged_extras.update(payload_extras)
        return self.run_request(request, merged_extras, save_txt=save_txt, save_json=save_json)
