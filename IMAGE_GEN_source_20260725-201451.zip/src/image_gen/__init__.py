"""Canonical IMAGE_GEN Python package.

Phase 04 separates the generation runtime into replaceable systems while
preserving the historical ``modules.*`` import surface through compatibility
facades.
"""
from image_gen.contracts import (
    ConditioningOutput,
    GenerationRequest,
    GenerationResult,
    PipelineComponents,
    SamplerOutput,
    SchedulerOutput,
)

__all__ = [
    "ConditioningOutput",
    "GenerationRequest",
    "GenerationResult",
    "PipelineComponents",
    "SamplerOutput",
    "SchedulerOutput",
]
