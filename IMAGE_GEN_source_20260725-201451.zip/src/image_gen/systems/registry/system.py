from __future__ import annotations

import importlib
import inspect
import threading
from pathlib import Path
from typing import Any

from image_gen.systems.registry.descriptors import PluginDescriptor, PluginKind, normalize_identity
from image_gen.systems.registry.registry import PluginCompatibilityResult, PluginRegistry


class RuntimeRegistrySystem:
    """Session-scoped plugin registry and adapter construction boundary.

    Descriptor discovery is lazy and performed at most once for each system
    instance. The same instance should be shared by the CLI and Txt2ImgRunner.
    """

    def __init__(
        self,
        state: Any | None = None,
        *,
        project_context: Any | None = None,
        registry: PluginRegistry | None = None,
    ) -> None:
        self.state = state
        self.project_context = project_context
        self._registry = registry
        self._lock = threading.Lock()
        self._construction_count = 1 if registry is not None else 0

    @property
    def construction_count(self) -> int:
        return self._construction_count

    @property
    def registry(self) -> PluginRegistry:
        if self._registry is None:
            with self._lock:
                if self._registry is None:
                    root = self._registry_root()
                    self._registry = PluginRegistry.discover(root)
                    self._construction_count += 1
        return self._registry

    def _registry_root(self) -> Path:
        configured_root = getattr(self.project_context, "registry_root", None)
        if configured_root is not None:
            return Path(configured_root).resolve()
        return (Path(__file__).resolve().parents[4] / "modules" / "ss_registry").resolve()

    def bind_state(self, state: Any) -> None:
        self.state = state

    def descriptors(self, kind: PluginKind | None = None) -> tuple[PluginDescriptor, ...]:
        return self.registry.descriptors(kind)

    def legacy_map(self, kind: PluginKind) -> dict[str, dict[str, Any]]:
        return self.registry.legacy_map(kind)

    @staticmethod
    def _entries(registry: Any) -> list[tuple[Any, dict[str, Any]]]:
        if isinstance(registry, dict):
            return [(key, value) for key, value in registry.items() if isinstance(value, dict)]
        for attr in ("new_map", "sampler_map", "sched_map_index", "scheduler_map", "map", "registry"):
            candidate = getattr(registry, attr, None)
            if isinstance(candidate, dict):
                return [(key, value) for key, value in candidate.items() if isinstance(value, dict)]
        return []

    def resolve_descriptor(self, requested: Any, *, kind: PluginKind) -> PluginDescriptor | None:
        if kind == "scheduler" and normalize_identity(requested) == "karras exponential":
            requested = "simple_kes"
        return self.registry.resolve(str(requested or ""), kind=kind)

    def resolve_entry(
        self,
        requested: Any,
        registry: Any | None = None,
        *,
        kind: PluginKind,
    ) -> dict[str, Any] | None:
        if registry is None:
            descriptor = self.resolve_descriptor(requested, kind=kind)
            return descriptor.to_legacy_entry() if descriptor else None

        needle = normalize_identity(requested)
        if not needle:
            return None
        if kind == "scheduler" and needle == "karras exponential":
            needle = "simple_kes"
        for key, entry in self._entries(registry):
            candidates = {
                normalize_identity(key),
                normalize_identity(entry.get("plugin_id")),
                normalize_identity(entry.get("id")),
                normalize_identity(entry.get("name")),
                normalize_identity(entry.get("label")),
                *(normalize_identity(alias) for alias in entry.get("aliases", []) or []),
            }
            if needle in candidates:
                return entry
        return None

    def validate_pair(
        self,
        sampler: str | PluginDescriptor,
        scheduler: str | PluginDescriptor,
    ) -> PluginCompatibilityResult:
        return self.registry.validate_pair(sampler, scheduler)

    def apply_resolution(self, request: Any, extras: dict[str, Any]) -> tuple[Any, dict[str, Any]]:
        sampler_descriptor = self.resolve_descriptor(
            extras.get("sampler_label") or request.sampler_name,
            kind="sampler",
        )
        scheduler_descriptor = self.resolve_descriptor(
            extras.get("scheduler_label") or request.scheduler_name,
            kind="scheduler",
        )

        # Transitional fallback for callers injecting an old registry map.
        sampler_entry = None
        scheduler_entry = None
        if sampler_descriptor is None:
            sampler_entry = self.resolve_entry(
                extras.get("sampler_label") or request.sampler_name,
                extras.get("live_sampler_map") or extras.get("sampler_registry"),
                kind="sampler",
            )
        if scheduler_descriptor is None:
            scheduler_entry = self.resolve_entry(
                extras.get("scheduler_label") or request.scheduler_name,
                extras.get("live_scheduler_map") or extras.get("scheduler_registry"),
                kind="scheduler",
            )

        if sampler_descriptor is not None:
            request.sampler_name = sampler_descriptor.name
            sampler_entry = sampler_descriptor.to_legacy_entry()
            extras["resolved_sampler_descriptor"] = sampler_descriptor
        if scheduler_descriptor is not None:
            request.scheduler_name = scheduler_descriptor.name
            scheduler_entry = scheduler_descriptor.to_legacy_entry()
            extras["resolved_scheduler_descriptor"] = scheduler_descriptor

        if sampler_entry:
            request.sampler_name = sampler_entry.get("name") or request.sampler_name
            extras["resolved_sampler_entry"] = sampler_entry
            extras["resolved_sampler_name"] = sampler_entry.get("name")
            extras["resolved_sampler_label"] = sampler_entry.get("label")
        if scheduler_entry:
            request.scheduler_name = scheduler_entry.get("name") or request.scheduler_name
            extras["resolved_scheduler_entry"] = scheduler_entry
            extras["resolved_scheduler_name"] = scheduler_entry.get("name")
            extras["resolved_scheduler_label"] = scheduler_entry.get("label")

        if sampler_descriptor is not None and scheduler_descriptor is not None:
            compatibility = self.validate_pair(sampler_descriptor, scheduler_descriptor)
            compatibility.raise_if_incompatible()
            compatibility_payload = compatibility.to_dict()
            extras["plugin_compatibility"] = compatibility_payload

            if compatibility.step_expansion_clamped or compatibility.tail_metadata_clamped:
                scheduler_kwargs = dict(getattr(request, "scheduler_kwargs", {}) or {})
                scheduler_kwargs["pipeline_mode"] = compatibility.negotiated_pipeline_mode or "fixed_steps"
                negotiated = dict(scheduler_kwargs.get("compatibility", {}) or {})
                negotiated.update(
                    {
                        "requested_by_sampler": sampler_descriptor.name,
                        "scheduler_family": scheduler_descriptor.capabilities.get(
                            "scheduler_family", "unknown"
                        ),
                        "negotiated_pipeline_mode": compatibility.negotiated_pipeline_mode,
                        "step_expansion_clamped": compatibility.step_expansion_clamped,
                        "tail_metadata_clamped": compatibility.tail_metadata_clamped,
                        "warnings": list(compatibility.warnings),
                    }
                )
                scheduler_kwargs["compatibility"] = negotiated
                request.scheduler_kwargs = scheduler_kwargs

        return request, extras

    def instantiate_adapter(self, entry: PluginDescriptor | dict[str, Any] | None) -> Any | None:
        if not entry:
            return None
        if isinstance(entry, PluginDescriptor):
            return self.registry.instantiate(entry, state=self.state)

        plugin_id = entry.get("plugin_id") or entry.get("id")
        if plugin_id:
            descriptor = self.registry.resolve(str(plugin_id), kind=entry.get("kind"))
            if descriptor is not None:
                return self.registry.instantiate(descriptor, state=self.state)

        module_name = entry.get("module")
        class_name = entry.get("adapter_class") or entry.get("entry_class")
        if not module_name or not class_name:
            raise ValueError(f"Registry entry missing module/class info: {entry}")
        adapter_cls = getattr(importlib.import_module(module_name), class_name)
        signature = inspect.signature(adapter_cls)
        parameters = signature.parameters
        accepts_kwargs = any(
            parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()
        )
        if "state" in parameters or accepts_kwargs:
            return adapter_cls(state=self.state)
        if "shared_state" in parameters:
            return adapter_cls(shared_state=self.state)
        return adapter_cls()
