from __future__ import annotations

import torch

from image_gen.systems.denoising import DenoisingSystem


class DecodingSystem:
    """Own latent-to-image tensor conversion; never writes files."""

    def __init__(self, vae: torch.nn.Module, *, vae_scaling_factor: float = 0.18215) -> None:
        self.vae = vae
        self.vae_scaling_factor = float(vae_scaling_factor)
        if self.vae_scaling_factor <= 0:
            raise ValueError("vae_scaling_factor must be positive.")

    @torch.no_grad()
    def decode(self, latents: torch.Tensor) -> torch.Tensor:
        decoded = self.vae.decode(latents / self.vae_scaling_factor)
        images = DenoisingSystem.extract_model_tensor(decoded, owner="VAE decoder")
        if images.ndim != 4:
            raise ValueError(f"VAE decoder must return BCHW data, got {tuple(images.shape)}.")
        if images.shape[0] != latents.shape[0]:
            raise ValueError("VAE decoder batch size does not match latent batch size.")
        if images.shape[1] not in {1, 3, 4}:
            raise ValueError("VAE decoder must return 1, 3, or 4 image channels.")
        if not torch.isfinite(images).all():
            raise ValueError("VAE decoder returned non-finite values.")
        return (images / 2.0 + 0.5).clamp(0.0, 1.0)
