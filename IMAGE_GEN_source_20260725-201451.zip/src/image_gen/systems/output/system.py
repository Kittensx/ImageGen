from __future__ import annotations

from typing import Any

from image_gen.contracts import GenerationRequest, GenerationResult
from image_gen.systems.diagnostics.serialization import json_safe
from modules.txt2img.manifest_builder import build_generation_manifest
from modules.txt2img.output_saver import SavedImageRecord, save_generation_batch


class OutputSystem:
    """Own manifest construction and all normal txt2img file persistence."""

    def build_manifest(
        self,
        *,
        request: GenerationRequest,
        extras: dict[str, Any] | None,
        pipeline_result: GenerationResult,
        generation_time_sec: float | None = None,
        device_name: str | None = None,
    ):
        extras = dict(extras or {})
        schedule_extra = dict(pipeline_result.schedule_extra or {})
        sampler_extra = dict(pipeline_result.sampler_extra or {})
        seed = request.seed
        if seed is None:
            resolved = list(request.resolved_seeds or [])
            seed = resolved[0] if resolved else -1

        manifest = build_generation_manifest(
            positive_prompt=request.positive_prompt,
            negative_prompt=request.negative_prompt,
            seed=int(seed),
            width=int(request.width),
            height=int(request.height),
            steps=int(request.steps),
            cfg_scale=float(request.cfg_scale),
            sampler_name=str(request.sampler_name or ""),
            scheduler_name=str(request.scheduler_name or ""),
            model_path=str(extras.get("model_path") or ""),
            request=request,
            compatibility_mode=schedule_extra.get("compatibility_mode"),
            effective_steps=sampler_extra.get(
                "effective_steps", schedule_extra.get("effective_steps")
            ),
            scheduler_step_override_applied=sampler_extra.get(
                "scheduler_step_override_applied",
                schedule_extra.get("scheduler_step_override_applied"),
            ),
            active_blend_methods=schedule_extra.get("active_blend_methods"),
            active_blend_weights=schedule_extra.get("active_blend_weights"),
            tail_features_used=schedule_extra.get("tail_features_used"),
            predicted_stop_step=schedule_extra.get("predicted_stop_step"),
            device_name=device_name,
            generation_time_sec=generation_time_sec,
        )
        manifest.extra.update(json_safe(extras))
        pipeline_metadata = json_safe(pipeline_result.metadata or {})
        denoising_contract = dict(
            (pipeline_result.metadata or {}).get("denoising_contract") or {}
        )
        manifest.extra["pipeline_metadata"] = pipeline_metadata
        manifest.extra["denoising_contract"] = json_safe(denoising_contract)
        for key in (
            "prediction_type",
            "prediction_conversion",
            "model_input_preconditioning",
            "cfg_rescale",
            "model_dtype",
            "solver_dtype",
        ):
            if key in denoising_contract:
                manifest.extra[key] = json_safe(denoising_contract[key])
        manifest.extra["cfg_scale"] = float(request.cfg_scale)
        manifest.extra["sigma_used_for_prediction"] = json_safe(
            sampler_extra.get("sigma_used_for_prediction")
        )
        manifest.extra["model_timestep"] = json_safe(
            sampler_extra.get("model_timestep")
        )
        manifest.extra["schedule"] = json_safe(schedule_extra)
        manifest.extra["sampler"] = json_safe(sampler_extra)
        return manifest

    def save(
        self,
        *,
        pipeline_result: GenerationResult,
        request: GenerationRequest,
        manifest: Any | None,
        output_dir: str,
        save_txt: bool = True,
        save_json: bool = True,
    ) -> list[SavedImageRecord]:
        if pipeline_result.images is None:
            raise ValueError("Cannot save images because GenerationResult.images is None.")
        records = save_generation_batch(
            images=pipeline_result.images,
            output_dir=output_dir,
            prefix=request.output_prefix,
            manifest=manifest,
            save_txt=save_txt,
            save_json=save_json,
        )
        pipeline_result.saved_paths = [record.image_path for record in records]
        return records
