from image_gen.systems.output.system import OutputSystem

__all__ = ["OutputSystem"]
