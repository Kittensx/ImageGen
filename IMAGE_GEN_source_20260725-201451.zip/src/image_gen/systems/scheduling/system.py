from __future__ import annotations

from typing import Any

from image_gen.contracts import GenerationRequest, SchedulerAdapterProtocol, SchedulerOutput


class SchedulingSystem:
    """Own schedule construction and canonical schedule validation."""

    def __init__(self, adapter: SchedulerAdapterProtocol) -> None:
        self.adapter = adapter

    def build(self, request: GenerationRequest, state: Any | None = None) -> SchedulerOutput:
        output = self.adapter.build_schedule(request=request, state=state)
        if not isinstance(output, SchedulerOutput):
            raise TypeError("Scheduler adapter must return SchedulerOutput.")
        output.validate()
        return output
