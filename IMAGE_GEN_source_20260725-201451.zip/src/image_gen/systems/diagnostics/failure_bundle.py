from __future__ import annotations

import json
import re
import traceback
from pathlib import Path
from typing import Any

from image_gen.systems.diagnostics.models import DiagnosticSession
from image_gen.systems.diagnostics.serialization import json_safe


def _safe_name(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value).strip())
    return text.strip("._-") or "unknown"


def _write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(json_safe(value, redact_secrets=True), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def write_failure_bundle(
    session: DiagnosticSession,
    *,
    system: str,
    operation: str,
    error: BaseException,
) -> Path:
    """Persist a self-contained, sanitized failure-reproduction bundle."""

    bundle_dir = (
        session.config.artifacts_root
        / "failures"
        / f"{session.run_id}_{_safe_name(system)}_{_safe_name(operation)}"
    )
    bundle_dir.mkdir(parents=True, exist_ok=False)

    request_payload = (
        session.request.to_serializable_dict()
        if hasattr(session.request, "to_serializable_dict")
        else json_safe(session.request)
    )
    reproduction_payload = dict(request_payload or {})
    reproduction_payload.update(json_safe(session.request_extras, redact_secrets=True) or {})

    failure = {
        "format": "image-gen-failure-bundle-v1",
        "run_id": session.run_id,
        "started_utc": session.started_utc,
        "system": system,
        "operation": operation,
        "error_type": type(error).__name__,
        "error_message": str(error),
        "diagnostics": session.config.to_dict(),
        "bundle_files": [
            "failure.json",
            "request.json",
            "request_extras.json",
            "effective_config.json",
            "components.json",
            "schedule.json",
            "sampler.json",
            "timings.json",
            "tensor_summaries.json",
            "events.jsonl",
            "traceback.txt",
            "reproduction_request.json",
            "reproduce_command.txt",
        ],
    }

    _write_json(bundle_dir / "failure.json", failure)
    _write_json(bundle_dir / "request.json", request_payload)
    _write_json(bundle_dir / "request_extras.json", session.request_extras)
    _write_json(bundle_dir / "effective_config.json", session.effective_config)
    _write_json(bundle_dir / "components.json", session.component_report)
    _write_json(bundle_dir / "schedule.json", session.schedule_report)
    _write_json(bundle_dir / "sampler.json", session.sampler_report)
    _write_json(bundle_dir / "timings.json", [item.to_dict() for item in session.timings])
    _write_json(bundle_dir / "tensor_summaries.json", session.tensor_summaries)
    _write_json(bundle_dir / "reproduction_request.json", reproduction_payload)

    events_path = bundle_dir / "events.jsonl"
    events_path.write_text(
        "".join(json.dumps(event.to_dict(), ensure_ascii=False) + "\n" for event in session.events),
        encoding="utf-8",
    )
    (bundle_dir / "traceback.txt").write_text(
        "".join(traceback.format_exception(type(error), error, error.__traceback__)),
        encoding="utf-8",
    )

    project_root = session.effective_config.get("project_root") or "."
    config_path = session.effective_config.get("config_path")
    context_args = f'--project-root "{project_root}" '
    if config_path:
        context_args += f'--project-config "{config_path}" '
    command = (
        f'cd /d "{project_root}"\n'
        f'venv\\Scripts\\python.exe -m modules.txt2img.cli run '
        f'{context_args}'
        f'--config "{bundle_dir / "reproduction_request.json"}" '
        f'--diagnostics verbose\n'
    )
    (bundle_dir / "reproduce_command.txt").write_text(command, encoding="utf-8")
    return bundle_dir
