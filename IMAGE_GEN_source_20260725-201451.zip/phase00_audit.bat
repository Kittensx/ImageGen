@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo IMAGE_GEN - Phase 00 baseline audit
echo ============================================================

set "PYTHON_EXE="
if exist ".venv\Scripts\python.exe" set "PYTHON_EXE=.venv\Scripts\python.exe"
if not defined PYTHON_EXE if exist "venv\Scripts\python.exe" set "PYTHON_EXE=venv\Scripts\python.exe"

if defined PYTHON_EXE (
    "%PYTHON_EXE%" scripts\audit\phase00_audit.py --print-known-issues %*
) else (
    py -3.10 scripts\audit\phase00_audit.py --print-known-issues %*
)

set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" (
    echo Phase 00 audit completed successfully.
) else (
    echo Phase 00 audit found a blocking failure. Exit code: %EXIT_CODE%
)
echo.
pause
exit /b %EXIT_CODE%
