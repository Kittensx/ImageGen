from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    project_root = Path(__file__).resolve().parents[2]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

    from image_gen.systems.registry import RuntimeRegistrySystem
    from modules.project_context import ProjectContext

    context = ProjectContext.load(project_root=project_root)
    registry_system = RuntimeRegistrySystem(project_context=context)
    scheduler_map = registry_system.legacy_map("scheduler")

    print(f"[INFO] Project root: {project_root}")
    print(f"[OK] Discovered {len(scheduler_map)} scheduler plugin(s)")
    for plugin_id, entry in scheduler_map.items():
        print("-" * 60)
        print(f"plugin_id: {plugin_id}")
        print(f"  name: {entry['name']}")
        print(f"  label: {entry['label']}")
        print(f"  module: {entry['module']}")
        print(f"  adapter_class: {entry['adapter_class']}")
        print(f"  aliases: {entry['aliases']}")
        print(f"  capabilities: {entry['capabilities']}")

    output_dir = project_root / "artifacts" / "diagnostics" / "registry"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_json = output_dir / "scheduler_registry.json"
    output_json.write_text(
        json.dumps(
            {
                "schema": "image-gen-scheduler-registry-diagnostic-v1",
                "runtime_dependency": False,
                "construction_count": registry_system.construction_count,
                "schedulers": scheduler_map,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"[OK] Wrote diagnostic snapshot: {output_json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
