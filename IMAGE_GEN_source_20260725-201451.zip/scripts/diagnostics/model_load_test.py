from pathlib import Path
import sys

# IMAGE_GEN_PROJECT_ROOT_BOOTSTRAP
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from modules.load_safetensors_model import LoadModel

loader = LoadModel()
plan = loader.prepare_load_plan()
built = loader.build_components_from_plan(plan)
loader.debug_print_components(built)
loader.debug_print_component_key_samples(built, limit=20)