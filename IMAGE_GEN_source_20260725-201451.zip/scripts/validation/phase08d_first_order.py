#!/usr/bin/env python3
"""Run the Phase 8D Euler and first-order DPM++ comparison matrix."""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from image_gen.contracts import GenerationRequest
from image_gen.systems.diagnostics.serialization import json_safe
from image_gen.systems.validation import RealCheckpointValidationSystem
from image_gen.systems.validation.metrics import compare_tensors, tensor_digest, tensor_statistics
from modules.project_context import ProjectContext
from modules.pipeline.step_trace_recorder import StepTraceRecorder
from scripts.validation.phase08a_sampler_matrix import (
    load_cases,
    resolve_device,
    resolve_dtype,
    safe_name,
)

DEFAULT_CASES = (
    PROJECT_ROOT / "scripts" / "validation" / "profiles" / "phase08d_cases.json"
)
VARIANTS = (
    "euler_reference",
    "dpm_first_order_legacy",
    "dpm_first_order_canonical",
    "dpm_first_order_canonical_repeat",
)
DPM_REQUIRED_STEP_FIELDS = {
    "timestep",
    "solver_latent_before",
    "predicted_x0",
    "solver_latent_after",
    "finite_status",
    "history_policy",
    "prediction_mode",
    "update_order",
    "history_accepted",
    "history_rejection_reason",
    "difference_from_euler_reference",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", help="Full SD1 .safetensors checkpoint")
    parser.add_argument("--project-root")
    parser.add_argument("--project-config")
    parser.add_argument("--output-dir")
    parser.add_argument("--cases-json", default=str(DEFAULT_CASES))
    parser.add_argument("--case-limit", type=int, default=0)
    parser.add_argument("--scheduler", default="simple_kes")
    parser.add_argument("--device", default="auto")
    parser.add_argument(
        "--dtype",
        choices=("auto", "float16", "float32", "bfloat16"),
        default="auto",
    )
    parser.add_argument("--no-save-images", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    return parser.parse_args()


def build_request(
    *,
    case: dict[str, Any],
    scheduler_name: str,
    variant: str,
    run_dir: Path,
    save_images: bool,
) -> GenerationRequest:
    if variant == "euler_reference":
        sampler_name = "simple_euler"
        sampler_kwargs: dict[str, Any] = {}
        capture_previews = False
    else:
        sampler_name = "dpmpp_2m"
        prediction_mode = (
            "legacy_sampler_local_epsilon"
            if variant == "dpm_first_order_legacy"
            else "canonical_predicted_x0"
        )
        sampler_kwargs = {
            "solver_dtype": "float32",
            "history_policy": "first_order_only",
            "prediction_mode": prediction_mode,
        }
        if prediction_mode == "legacy_sampler_local_epsilon":
            sampler_kwargs["phase08d_validation_mode"] = True
        capture_previews = variant != "dpm_first_order_canonical_repeat"

    return GenerationRequest(
        positive_prompt=case["prompt"],
        negative_prompt=case["negative_prompt"],
        width=case["width"],
        height=case["height"],
        steps=case["steps"],
        cfg_scale=case["cfg_scale"],
        batch_size=1,
        seed=case["seed"],
        scheduler_name=scheduler_name,
        sampler_name=sampler_name,
        scheduler_kwargs=dict(case.get("scheduler_kwargs") or {}),
        sampler_kwargs={
            **dict(case.get("sampler_kwargs") or {}),
            **sampler_kwargs,
        },
        diagnostics={
            "artifacts_root": str(run_dir),
            "verbosity": "normal",
            "export_events": True,
            "tensor_summaries": True,
            "tensor_statistics": True,
            "progress": True,
            "failure_bundles": True,
            "sampler_trace": {
                "enabled": True,
                "export_json": True,
                "export_csv": True,
                "export_txt_summary": True,
                "capture_latents": True,
                "capture_latent_every_n": 1,
                "predicted_x0_previews": capture_previews,
                "run_name": f"phase08d_{safe_name(case['case_id'])}_{variant}",
                "output_dir": str(run_dir / "traces"),
            },
        },
        save_images=save_images,
        output_dir=str(run_dir / "final"),
        output_prefix=f"{{index:05d}}-{{seed}}-{variant}",
    )


def _recorder_for(request: GenerationRequest) -> StepTraceRecorder | None:
    value = dict(request.sampler_kwargs or {}).get("trace_recorder")
    return value if isinstance(value, StepTraceRecorder) else None


def _trace_payload(result: Any) -> tuple[Path | None, dict[str, Any]]:
    exports = dict(result.pipeline_result.trace_exports or {})
    raw_path = str(exports.get("json") or "")
    path = Path(raw_path) if raw_path else None
    if path is None or not path.is_file():
        return path, {}
    return path, json.loads(path.read_text(encoding="utf-8"))


def inspect_variant(
    *,
    variant: str,
    result: Any,
    request: GenerationRequest,
) -> dict[str, Any]:
    trace_path, trace = _trace_payload(result)
    records = list(trace.get("records") or [])
    sampler_extra = dict(result.pipeline_result.sampler_extra or {})
    schedule = result.pipeline_result.schedule
    checks: dict[str, Any] = {
        "trace_json_exists": bool(trace_path and trace_path.is_file()),
        "trace_step_count": len(records),
        "schedule_transitions": int(schedule.sigma_transitions),
        "step_count_matches_schedule": len(records) == int(schedule.sigma_transitions),
        "initial_sigma": float(schedule.initial_sigma),
        "native_high_sigma_preserved": 35.0 <= float(schedule.initial_sigma) <= 60.0,
        "latent_statistics": tensor_statistics(result.pipeline_result.latents),
        "image_statistics": tensor_statistics(result.pipeline_result.images),
        "latent_digest": tensor_digest(result.pipeline_result.latents),
        "image_digest": tensor_digest(result.pipeline_result.images),
        "saved_images": [item.image_path for item in result.saved_records],
        "trace_exports": dict(result.pipeline_result.trace_exports or {}),
    }
    recorder = _recorder_for(request)
    checks["captured_latent_steps"] = (
        sorted(int(key) for key in recorder.latents) if recorder is not None else []
    )
    checks["all_latents_finite"] = bool(
        torch.isfinite(result.pipeline_result.latents).all().item()
    )
    checks["final_dtype"] = str(result.pipeline_result.latents.dtype)

    if variant == "euler_reference":
        checks.update(
            {
                "sampler_name": "simple_euler",
                "dpm_required_fields_present": None,
                "all_recorded_values_finite": checks["all_latents_finite"],
                "first_order_only": None,
                "no_second_order_updates": None,
                "no_history_reads": None,
                "euler_reference_comparisons_present": None,
                "preview_saved_count": 0,
                "preview_failed_count": 0,
            }
        )
    else:
        extras = [dict(record.get("extra") or {}) for record in records]
        finite_rows = []
        for extra in extras:
            status = dict(extra.get("finite_status") or {})
            finite_rows.append(bool(status) and all(value is True for value in status.values()))
        checks.update(
            {
                "sampler_name": "dpmpp_2m",
                "history_policy": sampler_extra.get("history_policy"),
                "prediction_mode": sampler_extra.get("integration_prediction_type"),
                "solver_dtype": sampler_extra.get("solver_dtype"),
                "solver_state_return_dtype": sampler_extra.get(
                    "solver_state_return_dtype"
                ),
                "history_state_read_count": sampler_extra.get(
                    "history_state_read_count"
                ),
                "first_order_update_count": sampler_extra.get(
                    "first_order_update_count"
                ),
                "second_order_update_count": sampler_extra.get(
                    "second_order_update_count"
                ),
                "terminal_update_count": sampler_extra.get("terminal_update_count"),
                "dpm_required_fields_present": bool(records)
                and all(DPM_REQUIRED_STEP_FIELDS.issubset(extra) for extra in extras),
                "all_recorded_values_finite": bool(finite_rows) and all(finite_rows),
                "first_order_only": all(
                    extra.get("update_order") in {"first_order", "terminal_denoised"}
                    for extra in extras
                ),
                "no_second_order_updates": not any(
                    extra.get("update_order") == "second_order" for extra in extras
                ),
                "no_history_reads": all(
                    not bool(extra.get("history_applied", extra.get("history_accepted")))
                    for extra in extras
                )
                and sampler_extra.get("history_state_read_count") == 0,
                "euler_reference_comparisons_present": bool(records)
                and all(
                    bool((extra.get("difference_from_euler_reference") or {}).get("available"))
                    for extra in extras
                ),
            }
        )
        preview_manifest_raw = str(
            (result.pipeline_result.trace_exports or {}).get("predicted_x0_manifest")
            or ""
        )
        preview_manifest = Path(preview_manifest_raw) if preview_manifest_raw else None
        preview_payload = (
            json.loads(preview_manifest.read_text(encoding="utf-8"))
            if preview_manifest is not None and preview_manifest.is_file()
            else {}
        )
        preview_records = list(preview_payload.get("records") or [])
        checks["preview_manifest_exists"] = bool(
            preview_manifest is not None and preview_manifest.is_file()
        )
        checks["preview_saved_count"] = sum(
            item.get("status") == "saved" for item in preview_records
        )
        checks["preview_failed_count"] = sum(
            item.get("status") == "failed" for item in preview_records
        )
        checks["preview_selection"] = preview_payload.get("selection") or {}

    common_pass = all(
        [
            checks["trace_json_exists"],
            checks["step_count_matches_schedule"],
            checks["native_high_sigma_preserved"],
            checks["all_latents_finite"],
        ]
    )
    if variant == "euler_reference":
        checks["technical_pass"] = common_pass
    else:
        preview_required = variant != "dpm_first_order_canonical_repeat"
        checks["technical_pass"] = common_pass and all(
            [
                checks["dpm_required_fields_present"],
                checks["all_recorded_values_finite"],
                checks["first_order_only"],
                checks["no_second_order_updates"],
                checks["no_history_reads"],
                checks["euler_reference_comparisons_present"],
                checks["history_policy"] == "first_order_only",
                checks["solver_dtype"] == "torch.float32",
                (not preview_required) or checks["preview_saved_count"] > 0,
            ]
        )
    return checks


def _captured_latents(request: GenerationRequest) -> dict[int, torch.Tensor]:
    recorder = _recorder_for(request)
    if recorder is None:
        return {}
    return {
        int(step): value.detach().to(device="cpu", dtype=torch.float32).clone()
        for step, value in recorder.latents.items()
        if torch.is_tensor(value)
    }


def _set_seed(seed: int) -> None:
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _variant_summary(variant: str, checks: dict[str, Any]) -> list[str]:
    return [
        f"#### {variant}",
        "",
        f"Technical result: **{'PASS' if checks.get('technical_pass') else 'FAIL'}**",
        f"Saved images: `{len(checks.get('saved_images') or [])}`",
        f"Trace steps: `{checks.get('trace_step_count')}`",
        f"Final latent finite: `{checks.get('all_latents_finite')}`",
        f"History policy: `{checks.get('history_policy')}`",
        f"Prediction mode: `{checks.get('prediction_mode')}`",
        f"Second-order updates: `{checks.get('second_order_update_count')}`",
        f"History reads: `{checks.get('history_state_read_count')}`",
        f"Predicted-x0 previews saved: `{checks.get('preview_saved_count')}`",
        "",
    ]


def write_report(report: dict[str, Any], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = json_safe(report)
    json_path = output_dir / "phase08d_first_order_report.json"
    json_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    lines = [
        "# Phase 08D First-Order DPM++ Validation Report",
        "",
        f"Created: {payload.get('created_utc')}",
        f"Technical result: **{'PASS' if payload.get('technical_complete') else 'FAIL'}**",
        "",
        "The technical result verifies execution, finite values, first-order-only history behavior, fixed-seed repeatability, and artifact export. Final image coherence and prompt relevance still require manual review.",
        "",
        "## Cases",
        "",
    ]
    for case in payload.get("cases", []):
        lines.extend(
            [
                f"### {case.get('case_id')}",
                "",
                f"Status: `{case.get('status')}`",
                "",
            ]
        )
        for variant in VARIANTS:
            variant_data = (case.get("variants") or {}).get(variant) or {}
            if variant_data:
                lines.extend(_variant_summary(variant, variant_data.get("checks") or {}))
        lines.extend(
            [
                "#### Numeric comparisons",
                "",
                "```json",
                json.dumps(case.get("comparisons") or {}, indent=2),
                "```",
                "",
            ]
        )
    lines.extend(
        [
            "## Manual acceptance gate",
            "",
            "Review the Euler, legacy first-order, and canonical first-order final images side by side. Review the predicted-x0 sequences for both DPM variants. Phase 08D may proceed to Phase 08E only if canonical first-order produces coherent prompt-related images without a major regression from Euler.",
            "",
        ]
    )
    markdown_path = output_dir / "phase08d_first_order_report.md"
    markdown_path.write_text("\n".join(lines), encoding="utf-8")
    return json_path, markdown_path


def main() -> int:
    args = parse_args()
    if not args.model:
        print("ERROR: --model is required.", file=sys.stderr)
        return 2

    context = ProjectContext.load(
        project_root=args.project_root,
        config_path=args.project_config,
    )
    cases_path = context.resolve_project_path(args.cases_json)
    cases = load_cases(cases_path, limit=args.case_limit)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = (
        context.resolve_project_path(args.output_dir)
        if args.output_dir
        else context.project_root / "artifacts" / "phase08d_first_order" / stamp
    )
    report: dict[str, Any] = {
        "format": "image-gen-phase08d-first-order-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scheduler_name": args.scheduler,
        "history_policy": "first_order_only",
        "solver_dtype": "float32",
        "cases_file": str(cases_path),
        "variants": list(VARIANTS),
        "cases": [],
        "technical_complete": False,
        "manual_image_review_required": True,
    }
    write_report(report, output_dir)

    validator = RealCheckpointValidationSystem(context)
    model_path = context.resolve_project_path(args.model)
    try:
        checkpoint = validator.inspect_checkpoint(model_path)
        validator.require_supported_architecture(checkpoint)
        report["checkpoint"] = checkpoint.to_dict()

        from transformers import CLIPTokenizer

        tokenizer = CLIPTokenizer.from_pretrained(
            str(context.tokenizer_root), local_files_only=True
        )
        report["tokenizer"] = validator.validate_tokenizer(
            tokenizer,
            [case["prompt"] for case in cases]
            + [case["negative_prompt"] for case in cases]
            + [""],
        )
        write_report(report, output_dir)
        if args.preflight_only:
            print("PASS: Phase 8D preflight completed.")
            print(f"Report: {output_dir / 'phase08d_first_order_report.json'}")
            return 0

        from image_gen.runtime.txt2img_runner import Txt2ImgRunner
        from image_gen.systems.model_loading import ModelLoadingSystem
        from image_gen.systems.registry import RuntimeRegistrySystem
        from modules.adapters.prompt_conditioning_adapter import PromptConditioningAdapter
        from modules.load_safetensors_model import LoadModel

        device = resolve_device(args.device)
        dtype = resolve_dtype(args.dtype, device)
        if device.type == "cpu" and dtype == torch.float16:
            raise ValueError("float16 CPU validation is not supported; use --dtype float32.")

        torch.use_deterministic_algorithms(True, warn_only=True)
        registry = RuntimeRegistrySystem(project_context=context)
        loader = LoadModel(project_context=context)
        runner = Txt2ImgRunner(
            prompt_adapter_factory=lambda **_: PromptConditioningAdapter(),
            model_loader=loader,
            model_loading_system=ModelLoadingSystem(loader),
            project_context=context,
            registry_system=registry,
            tokenizer=tokenizer,
            device=device,
            dtype=dtype,
        )
        extras = {"model_path": str(model_path)}
        save_images = not args.no_save_images

        for case_index, case in enumerate(cases, start=1):
            print("=" * 72)
            print(f"Phase 8D case {case_index}/{len(cases)}: {case['case_id']}")
            case_record: dict[str, Any] = {
                "case_id": case["case_id"],
                "seed": case["seed"],
                "variants": {},
                "comparisons": {},
                "status": "running",
            }
            report["cases"].append(case_record)
            write_report(report, output_dir)
            results: dict[str, Any] = {}
            euler_reference_latents: dict[int, torch.Tensor] = {}

            for variant in VARIANTS:
                run_dir = (
                    output_dir
                    / "runs"
                    / f"{case_index:02d}_{safe_name(case['case_id'])}"
                    / variant
                )
                print(f"  {variant}: {run_dir}")
                request = build_request(
                    case=case,
                    scheduler_name=args.scheduler,
                    variant=variant,
                    run_dir=run_dir,
                    save_images=save_images,
                )
                if variant != "euler_reference":
                    setattr(
                        request,
                        "_phase08d_euler_reference_latents",
                        euler_reference_latents,
                    )
                _set_seed(int(case["seed"]))
                runner.reset_runtime_state()
                try:
                    result = runner.run_request(request, extras)
                    checks = inspect_variant(
                        variant=variant,
                        result=result,
                        request=request,
                    )
                    results[variant] = result
                    case_record["variants"][variant] = {
                        "status": "completed" if checks["technical_pass"] else "failed_checks",
                        "checks": checks,
                    }
                    if variant == "euler_reference":
                        euler_reference_latents = _captured_latents(request)
                        if len(euler_reference_latents) != int(
                            result.pipeline_result.schedule.sigma_transitions
                        ):
                            raise RuntimeError(
                                "Euler reference did not capture one latent for every schedule transition."
                            )
                except Exception as exc:
                    case_record["variants"][variant] = {
                        "status": "error",
                        "error": {
                            "error_type": type(exc).__name__,
                            "error": str(exc),
                            "traceback": traceback.format_exc(),
                        },
                    }
                    print(f"FAILED: {variant}: {type(exc).__name__}: {exc}", file=sys.stderr)
                    if args.fail_fast:
                        write_report(report, output_dir)
                        raise
                finally:
                    write_report(report, output_dir)

            required_results = {
                "euler_reference",
                "dpm_first_order_legacy",
                "dpm_first_order_canonical",
                "dpm_first_order_canonical_repeat",
            }
            if required_results.issubset(results):
                euler = results["euler_reference"].pipeline_result
                legacy = results["dpm_first_order_legacy"].pipeline_result
                canonical = results["dpm_first_order_canonical"].pipeline_result
                repeat = results["dpm_first_order_canonical_repeat"].pipeline_result
                case_record["comparisons"] = {
                    "canonical_repeat_latents": compare_tensors(
                        canonical.latents, repeat.latents, atol=0.0, rtol=0.0
                    ),
                    "canonical_repeat_images": compare_tensors(
                        canonical.images, repeat.images, atol=0.0, rtol=0.0
                    ),
                    "legacy_vs_canonical_latents": compare_tensors(
                        legacy.latents, canonical.latents, atol=1e-6, rtol=1e-6
                    ),
                    "legacy_vs_canonical_images": compare_tensors(
                        legacy.images, canonical.images, atol=1e-6, rtol=1e-6
                    ),
                    "euler_vs_canonical_latents": compare_tensors(
                        euler.latents, canonical.latents, atol=1e-6, rtol=1e-6
                    ),
                    "euler_vs_canonical_images": compare_tensors(
                        euler.images, canonical.images, atol=1e-6, rtol=1e-6
                    ),
                }
                repeat_pass = bool(
                    case_record["comparisons"]["canonical_repeat_latents"].get(
                        "materially_equivalent"
                    )
                    and case_record["comparisons"]["canonical_repeat_images"].get(
                        "materially_equivalent"
                    )
                )
            else:
                repeat_pass = False

            variants_pass = all(
                (case_record["variants"].get(variant) or {}).get("status")
                == "completed"
                for variant in VARIANTS
            )
            case_record["fixed_seed_repeatable"] = repeat_pass
            case_record["status"] = (
                "technical_pass" if variants_pass and repeat_pass else "technical_fail"
            )
            report["technical_complete"] = (
                len(report["cases"]) == len(cases)
                and all(item.get("status") == "technical_pass" for item in report["cases"])
            )
            write_report(report, output_dir)

        json_path, markdown_path = write_report(report, output_dir)
        print("=" * 72)
        print("IMAGE_GEN - PHASE 8D FIRST-ORDER VALIDATION")
        print(f"Technical result: {'PASS' if report['technical_complete'] else 'FAIL'}")
        print(f"JSON report:      {json_path}")
        print(f"Text report:      {markdown_path}")
        print("Manual review of Euler, legacy DPM, canonical DPM, and predicted-x0 images is required.")
        return 0 if report["technical_complete"] else 1
    except Exception as exc:
        report["fatal_error"] = {
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        write_report(report, output_dir)
        print(f"ERROR: {exc}", file=sys.stderr)
        print(f"Report: {output_dir / 'phase08d_first_order_report.json'}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
