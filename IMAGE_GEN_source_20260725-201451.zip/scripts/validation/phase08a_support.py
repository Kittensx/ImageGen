from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

import torch

from image_gen.contracts import SchedulerOutput
from modules.ss_registry.schedulers.simple_kes_sched.kes_scheduler_adapter import (
    SimpleKESSchedulerAdapter,
)

NATIVE_SCHEDULE = "native"
MODEL_BOUNDED_KARRAS = "model_bounded_karras"
LATENT_SOLVER_DTYPE = "latent"
FLOAT32_SOLVER_DTYPE = "float32"


@dataclass(frozen=True)
class Phase8AVariant:
    key: str
    label: str
    sampler_name: str
    schedule_mode: str = NATIVE_SCHEDULE
    solver_dtype: str = LATENT_SOLVER_DTYPE
    purpose: str = "registered sampler baseline"

    def to_dict(self) -> dict[str, str]:
        return {
            "key": self.key,
            "label": self.label,
            "sampler_name": self.sampler_name,
            "schedule_mode": self.schedule_mode,
            "solver_dtype": self.solver_dtype,
            "purpose": self.purpose,
        }


def build_phase8a_variants(
    sampler_names: Iterable[str],
    *,
    include_dpm_isolation: bool = True,
) -> list[Phase8AVariant]:
    """Build a stable sequential run order from registered sampler names.

    Every discovered sampler receives one native Simple KES schedule run. DPM++
    2M additionally receives the B/C/D isolation variants. Variant A is the
    normal registered DPM++ 2M run and is therefore not duplicated.
    """

    normalized = {str(name).strip().lower() for name in sampler_names if str(name).strip()}
    preferred = ["simple_euler", "kes", "dpmpp_2m"]
    ordered = [name for name in preferred if name in normalized]
    ordered.extend(sorted(normalized.difference(ordered)))

    variants: list[Phase8AVariant] = []
    for sampler_name in ordered:
        if sampler_name == "dpmpp_2m":
            variants.append(
                Phase8AVariant(
                    key="dpmpp_2m_A_native_latent",
                    label="DPM++ 2M A - native schedule / latent precision",
                    sampler_name=sampler_name,
                    purpose="reproduce the current DPM++ 2M failure condition",
                )
            )
        else:
            variants.append(
                Phase8AVariant(
                    key=f"{sampler_name}_native",
                    label=f"{sampler_name} - native schedule",
                    sampler_name=sampler_name,
                )
            )

    if include_dpm_isolation and "dpmpp_2m" in normalized:
        variants.extend(
            [
                Phase8AVariant(
                    key="dpmpp_2m_B_bounded_latent",
                    label="DPM++ 2M B - bounded Karras / latent precision",
                    sampler_name="dpmpp_2m",
                    schedule_mode=MODEL_BOUNDED_KARRAS,
                    purpose="isolate schedule-domain effects",
                ),
                Phase8AVariant(
                    key="dpmpp_2m_C_native_float32",
                    label="DPM++ 2M C - native schedule / float32 solver",
                    sampler_name="dpmpp_2m",
                    solver_dtype=FLOAT32_SOLVER_DTYPE,
                    purpose="isolate solver-precision effects",
                ),
                Phase8AVariant(
                    key="dpmpp_2m_D_bounded_float32",
                    label="DPM++ 2M D - bounded Karras / float32 solver",
                    sampler_name="dpmpp_2m",
                    schedule_mode=MODEL_BOUNDED_KARRAS,
                    solver_dtype=FLOAT32_SOLVER_DTYPE,
                    purpose="test the combined corrective baseline",
                ),
            ]
        )
    return variants


def _as_float_list(value: torch.Tensor | None) -> list[float] | None:
    if value is None:
        return None
    return [float(item) for item in value.detach().to(device="cpu", dtype=torch.float64).flatten()]


def analyze_schedule(schedule: SchedulerOutput) -> dict[str, Any]:
    sigmas = schedule.sigmas.detach().to(device="cpu", dtype=torch.float64).flatten()
    timesteps = (
        schedule.timesteps.detach().to(device="cpu", dtype=torch.float64).flatten()
        if schedule.timesteps is not None
        else None
    )
    positive = sigmas[sigmas > 0]
    timestep_mapping = dict(schedule.metadata.get("timestep_mapping") or {})
    training_min = timestep_mapping.get("training_sigma_min")
    training_max = timestep_mapping.get("training_sigma_max")

    duplicate_positive_timesteps = 0
    if timesteps is not None and positive.numel() > 0:
        transition_timesteps = timesteps[: max(int(sigmas.numel()) - 1, 0)]
        positive_transition_count = min(int(positive.numel()), int(transition_timesteps.numel()))
        selected = transition_timesteps[:positive_transition_count]
        duplicate_positive_timesteps = max(
            int(selected.numel()) - int(torch.unique(selected).numel()),
            0,
        )

    clipped_low = 0
    clipped_high = 0
    if training_min is not None:
        clipped_low = int(((positive < float(training_min))).sum().item())
    if training_max is not None:
        clipped_high = int(((positive > float(training_max))).sum().item())

    return {
        "sigma_values": _as_float_list(sigmas),
        "timestep_values": _as_float_list(timesteps),
        "sigma_count": int(sigmas.numel()),
        "transition_count": max(int(sigmas.numel()) - 1, 0),
        "positive_sigma_count": int(positive.numel()),
        "initial_sigma": float(sigmas[0].item()),
        "minimum_positive_sigma": float(positive.min().item()) if positive.numel() else None,
        "maximum_positive_sigma": float(positive.max().item()) if positive.numel() else None,
        "terminal_sigma": float(sigmas[-1].item()),
        "non_increasing": bool(torch.all(sigmas[1:] <= sigmas[:-1]).item()),
        "strictly_decreasing_positive": bool(
            positive.numel() < 2 or torch.all(positive[1:] < positive[:-1]).item()
        ),
        "duplicate_positive_timestep_count": duplicate_positive_timesteps,
        "clipped_low_count": clipped_low,
        "clipped_high_count": clipped_high,
        "timestep_mapping": timestep_mapping,
    }


def build_model_bounded_karras_sigmas(
    *,
    steps: int,
    sigma_min: float,
    sigma_max: float,
    rho: float,
    device: torch.device,
) -> torch.Tensor:
    if steps < 1:
        raise ValueError("steps must be at least 1")
    if not 0.0 < sigma_min < sigma_max:
        raise ValueError("model-bounded Karras requires 0 < sigma_min < sigma_max")
    if rho <= 0:
        raise ValueError("rho must be greater than zero")

    ramp = torch.linspace(0.0, 1.0, steps, device=device, dtype=torch.float64)
    min_inv_rho = float(sigma_min) ** (1.0 / float(rho))
    max_inv_rho = float(sigma_max) ** (1.0 / float(rho))
    body = (max_inv_rho + ramp * (min_inv_rho - max_inv_rho)) ** float(rho)
    return torch.cat(
        [
            body.to(dtype=torch.float32),
            torch.zeros(1, device=device, dtype=torch.float32),
        ]
    )


def map_sigmas_to_sd_timesteps(
    sigmas: torch.Tensor,
    *,
    num_train_timesteps: int = 1000,
    beta_start: float = 0.00085,
    beta_end: float = 0.012,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Independent fallback matching the current Simple KES SD1 mapper."""

    device = sigmas.device
    betas = torch.linspace(
        beta_start**0.5,
        beta_end**0.5,
        num_train_timesteps,
        device=device,
        dtype=torch.float64,
    ).square()
    alphas_cumprod = torch.cumprod(1.0 - betas, dim=0)
    training_sigmas = torch.sqrt((1.0 - alphas_cumprod) / alphas_cumprod)
    log_training_sigmas = training_sigmas.log()

    requested = sigmas.to(device=device, dtype=torch.float64).clamp(min=0.0)
    zero_mask = requested <= 0.0
    training_sigma_min = float(training_sigmas[0].detach().cpu())
    training_sigma_max = float(training_sigmas[-1].detach().cpu())
    clipped_low = int(((requested > 0.0) & (requested < training_sigma_min)).sum().item())
    clipped_high = int((requested > training_sigma_max).sum().item())

    log_requested = requested.clamp(min=training_sigma_min).log()
    log_requested = log_requested.clamp(
        min=float(log_training_sigmas[0]),
        max=float(log_training_sigmas[-1]),
    )
    upper = torch.searchsorted(log_training_sigmas, log_requested)
    upper = upper.clamp(min=1, max=num_train_timesteps - 1)
    lower = upper - 1
    low_log = log_training_sigmas[lower]
    high_log = log_training_sigmas[upper]
    weight = (log_requested - low_log) / (high_log - low_log).clamp(min=1e-12)
    timesteps = lower.to(torch.float64) + weight
    timesteps = torch.where(zero_mask, torch.zeros_like(timesteps), timesteps)
    metadata = {
        "type": "sd_scaled_linear_beta_log_sigma_interpolation",
        "num_train_timesteps": num_train_timesteps,
        "beta_start": beta_start,
        "beta_end": beta_end,
        "training_sigma_min": training_sigma_min,
        "training_sigma_max": training_sigma_max,
        "clipped_low_count": clipped_low,
        "clipped_high_count": clipped_high,
    }
    return timesteps.to(dtype=torch.float32), metadata


class Phase8ASchedulerAdapter:
    """Diagnostic wrapper around the real Simple KES scheduler adapter.

    Native mode is a pass-through with extra evidence. The bounded mode first
    builds the native schedule, preserves it as the candidate schedule, and
    then replaces only the execution schedule with a plain Karras sequence
    inside the model training sigma domain. It is used only by Phase 8A.
    """

    def __init__(self, base_adapter: Any | None = None) -> None:
        self.base_adapter = base_adapter or SimpleKESSchedulerAdapter()

    def build_schedule(self, request: Any, state: Any = None) -> SchedulerOutput:
        scheduler_kwargs = dict(getattr(request, "scheduler_kwargs", {}) or {})
        phase8a = scheduler_kwargs.pop("phase8a", {})
        if not isinstance(phase8a, Mapping):
            raise TypeError("scheduler_kwargs.phase8a must be a mapping")

        base_request = copy.copy(request)
        base_request.scheduler_kwargs = scheduler_kwargs
        native = self.base_adapter.build_schedule(base_request, state=state)
        native_analysis = analyze_schedule(native)
        mode = str(phase8a.get("schedule_mode", NATIVE_SCHEDULE)).strip().lower()

        if mode == NATIVE_SCHEDULE:
            metadata = dict(native.metadata)
            metadata["phase8a"] = {
                "schedule_mode": NATIVE_SCHEDULE,
                "candidate_schedule": native_analysis,
                "execution_schedule": native_analysis,
            }
            return SchedulerOutput(
                sigmas=native.sigmas,
                timesteps=native.timesteps,
                requested_steps=native.requested_steps,
                effective_steps=native.effective_steps,
                scheduler_step_override_applied=native.scheduler_step_override_applied,
                compatibility_mode=native.compatibility_mode,
                metadata=metadata,
            )

        if mode != MODEL_BOUNDED_KARRAS:
            raise ValueError(
                f"Unsupported Phase 8A schedule mode {mode!r}; expected "
                f"{NATIVE_SCHEDULE!r} or {MODEL_BOUNDED_KARRAS!r}."
            )

        mapping = dict(native.metadata.get("timestep_mapping") or {})
        if not mapping:
            _, mapping = map_sigmas_to_sd_timesteps(native.sigmas)
        training_min = float(mapping["training_sigma_min"])
        training_max = float(mapping["training_sigma_max"])
        sigma_min = float(phase8a.get("sigma_min", training_min))
        sigma_max = float(phase8a.get("sigma_max", training_max))
        rho = float(phase8a.get("rho", 7.0))
        sigma_min = max(sigma_min, training_min)
        sigma_max = min(sigma_max, training_max)

        sigmas = build_model_bounded_karras_sigmas(
            steps=int(request.steps),
            sigma_min=sigma_min,
            sigma_max=sigma_max,
            rho=rho,
            device=native.sigmas.device,
        )

        runtime_scheduler = None
        if state is not None and hasattr(state, "extra"):
            runtime_scheduler = state.extra.get("_scheduler_runtime_obj")
        mapper = getattr(runtime_scheduler, "_sigmas_to_timesteps", None)
        if callable(mapper):
            timesteps = mapper(sigmas)
            execution_mapping = dict(
                getattr(runtime_scheduler, "_timestep_mapping_metadata", {}) or {}
            )
        else:
            timesteps, execution_mapping = map_sigmas_to_sd_timesteps(
                sigmas,
                num_train_timesteps=int(mapping.get("num_train_timesteps", 1000)),
                beta_start=float(mapping.get("beta_start", 0.00085)),
                beta_end=float(mapping.get("beta_end", 0.012)),
            )

        metadata = dict(native.metadata)
        metadata.update(
            {
                "schedule_mode": "phase8a_model_bounded_karras",
                "active_blend_methods": ["karras"],
                "active_blend_weights": [1.0],
                "tail_features_used": {
                    "tail_steps_applied": False,
                    "decay_tail_applied": False,
                    "blended_tail_applied": False,
                    "progressive_decay_applied": False,
                    "auto_stabilization_applied": False,
                    "step_expansion_applied": False,
                },
                "prepass_used": False,
                "predicted_stop_step": int(request.steps),
                "timestep_mapping": execution_mapping,
            }
        )
        bounded = SchedulerOutput(
            sigmas=sigmas,
            timesteps=timesteps,
            requested_steps=int(request.steps),
            effective_steps=int(request.steps),
            scheduler_step_override_applied=False,
            compatibility_mode="fixed_steps",
            metadata=metadata,
        )
        metadata["phase8a"] = {
            "schedule_mode": MODEL_BOUNDED_KARRAS,
            "rho": rho,
            "training_sigma_min": training_min,
            "training_sigma_max": training_max,
            "execution_sigma_min": sigma_min,
            "execution_sigma_max": sigma_max,
            "candidate_schedule": native_analysis,
            "execution_schedule": analyze_schedule(bounded),
        }
        bounded.metadata = metadata
        return bounded
