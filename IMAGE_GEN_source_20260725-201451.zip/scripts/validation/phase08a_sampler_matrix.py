#!/usr/bin/env python3
"""Run the Phase 8A sequential sampler and DPM++ 2M isolation matrix."""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from image_gen.contracts import GenerationRequest
from image_gen.systems.diagnostics.serialization import json_safe
from image_gen.systems.validation.metrics import compare_tensors, tensor_digest, tensor_statistics
from image_gen.systems.validation import RealCheckpointValidationSystem, capability_matrix
from modules.project_context import ProjectContext
from scripts.validation.phase08a_support import (
    FLOAT32_SOLVER_DTYPE,
    LATENT_SOLVER_DTYPE,
    MODEL_BOUNDED_KARRAS,
    NATIVE_SCHEDULE,
    Phase8ASchedulerAdapter,
    Phase8AVariant,
    analyze_schedule,
    build_phase8a_variants,
)

DEFAULT_CASES = PROJECT_ROOT / "scripts" / "validation" / "profiles" / "phase08a_cases.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", help="Full SD1 .safetensors checkpoint")
    parser.add_argument("--project-root")
    parser.add_argument("--project-config")
    parser.add_argument("--output-dir")
    parser.add_argument("--cases-json", default=str(DEFAULT_CASES))
    parser.add_argument("--case-limit", type=int, default=0)
    parser.add_argument("--samplers", nargs="*", help="Optional registered sampler names")
    parser.add_argument("--scheduler", default="simple_kes")
    parser.add_argument("--device", default="auto")
    parser.add_argument(
        "--dtype",
        choices=("auto", "float16", "float32", "bfloat16"),
        default="auto",
    )
    parser.add_argument("--no-save-images", action="store_true")
    parser.add_argument("--skip-dpm-isolation", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    parser.add_argument("--list-samplers", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--capabilities", action="store_true")
    return parser.parse_args()


def resolve_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(value)


def resolve_dtype(value: str, device: torch.device) -> torch.dtype:
    if value == "auto":
        return torch.float16 if device.type == "cuda" else torch.float32
    return {
        "float16": torch.float16,
        "float32": torch.float32,
        "bfloat16": torch.bfloat16,
    }[value]


def load_cases(path: Path, *, limit: int = 0) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    cases = payload.get("cases")
    if not isinstance(cases, list) or not cases:
        raise ValueError(f"Phase 8A case file contains no cases: {path}")

    normalized: list[dict[str, Any]] = []
    required = {
        "case_id",
        "prompt",
        "negative_prompt",
        "seed",
        "width",
        "height",
        "steps",
        "cfg_scale",
    }
    for index, item in enumerate(cases, start=1):
        if not isinstance(item, dict):
            raise TypeError(f"Case {index} must be a JSON object.")
        missing = sorted(required.difference(item))
        if missing:
            raise ValueError(f"Case {index} is missing: {', '.join(missing)}")
        case = dict(item)
        case["case_id"] = str(case["case_id"]).strip()
        case["prompt"] = str(case["prompt"])
        case["negative_prompt"] = str(case["negative_prompt"])
        case["seed"] = int(case["seed"])
        case["width"] = int(case["width"])
        case["height"] = int(case["height"])
        case["steps"] = int(case["steps"])
        case["cfg_scale"] = float(case["cfg_scale"])
        normalized.append(case)
    if limit > 0:
        normalized = normalized[:limit]
    return normalized


def safe_name(value: str) -> str:
    cleaned = value.strip().replace(" ", "_")
    return "".join(ch for ch in cleaned if ch.isalnum() or ch in {"_", "-"}) or "run"


def build_request(
    *,
    case: dict[str, Any],
    variant: Phase8AVariant,
    scheduler_name: str,
    output_dir: Path,
    save_images: bool,
) -> GenerationRequest:
    trace_dir = output_dir / "trace"
    scheduler_kwargs = dict(case.get("scheduler_kwargs") or {})
    scheduler_kwargs["phase8a"] = {
        "schedule_mode": variant.schedule_mode,
    }
    sampler_kwargs = dict(case.get("sampler_kwargs") or {})
    if variant.sampler_name == "dpmpp_2m":
        sampler_kwargs["solver_dtype"] = variant.solver_dtype

    return GenerationRequest(
        positive_prompt=case["prompt"],
        negative_prompt=case["negative_prompt"],
        width=case["width"],
        height=case["height"],
        steps=case["steps"],
        cfg_scale=case["cfg_scale"],
        batch_size=1,
        seed=case["seed"],
        scheduler_name=scheduler_name,
        sampler_name=variant.sampler_name,
        scheduler_kwargs=scheduler_kwargs,
        sampler_kwargs=sampler_kwargs,
        diagnostics={
            "verbosity": "normal",
            "export_events": True,
            "tensor_summaries": True,
            "tensor_statistics": True,
            "progress": True,
            "failure_bundles": True,
            "sampler_trace": {
                "enabled": True,
                "export_json": True,
                "export_csv": True,
                "export_txt_summary": True,
                "capture_latents": False,
                "run_name": f"{variant.key}_{case['case_id']}",
                "output_dir": str(trace_dir),
            },
        },
        save_images=save_images,
        output_dir=str(output_dir / "images"),
        output_prefix=f"{safe_name(case['case_id'])}_{safe_name(variant.key)}",
    )


def run_record(
    *,
    case: dict[str, Any],
    variant: Phase8AVariant,
    result: Any,
) -> dict[str, Any]:
    pipeline_result = result.pipeline_result
    images = pipeline_result.images
    latents = pipeline_result.latents
    return {
        "status": "completed",
        "case": dict(case),
        "variant": variant.to_dict(),
        "run_id": result.run_id,
        "generation_time_sec": result.generation_time_sec,
        "output_paths": [record.image_path for record in result.saved_records],
        "manifest_paths": [
            path
            for record in result.saved_records
            for path in (record.txt_path, record.json_path)
            if path
        ],
        "schedule": analyze_schedule(pipeline_result.schedule),
        "schedule_metadata": dict(pipeline_result.schedule.extra or {}),
        "sampler": dict(pipeline_result.sampler.extra or {}),
        "final_latents": tensor_statistics(latents),
        "latent_digest": tensor_digest(latents),
        "decoded_images": tensor_statistics(images),
        "image_digest": tensor_digest(images),
        "diagnostics": dict(result.diagnostics or {}),
        "trace_exports": dict(pipeline_result.trace_exports or {}),
    }


def error_record(
    *,
    case: dict[str, Any],
    variant: Phase8AVariant,
    error: BaseException,
) -> dict[str, Any]:
    return {
        "status": "failed",
        "case": dict(case),
        "variant": variant.to_dict(),
        "error_type": type(error).__name__,
        "error": str(error),
        "traceback": traceback.format_exc(),
        "failure_bundle": getattr(error, "bundle_path", None),
    }


def write_report(report: dict[str, Any], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / "phase08a_sampler_matrix_report.json"
    markdown_path = output_dir / "phase08a_sampler_matrix_report.md"
    safe_report = json_safe(report)
    json_path.write_text(json.dumps(safe_report, indent=2), encoding="utf-8")

    lines = [
        "# Phase 8A - Sequential Sampler Isolation Report",
        "",
        f"Created: {safe_report['created_utc']}",
        f"Checkpoint: `{safe_report.get('checkpoint', {}).get('file_name', '<not loaded>')}`",
        f"Scheduler: `{safe_report['scheduler_name']}`",
        f"Technical completion: **{'PASS' if safe_report['technical_complete'] else 'FAIL'}**",
        "",
        "Image quality remains a manual review gate. A technically completed run is not automatically a visually correct sampler.",
        "",
        "## Run Matrix",
        "",
        "| Order | Case | Variant | Status | Seconds | High clips | Low clips | Duplicate positive timesteps |",
        "|---:|---|---|---|---:|---:|---:|---:|",
    ]
    for index, item in enumerate(safe_report.get("runs", []), start=1):
        case_id = item.get("case", {}).get("case_id", "")
        variant = item.get("variant", {}).get("key", "")
        status = item.get("status", "")
        seconds = item.get("generation_time_sec")
        seconds_text = f"{seconds:.3f}" if isinstance(seconds, (int, float)) else ""
        schedule = item.get("schedule", {})
        lines.append(
            "| "
            + " | ".join(
                [
                    str(index),
                    case_id,
                    variant,
                    status,
                    seconds_text,
                    str(schedule.get("clipped_high_count", "")),
                    str(schedule.get("clipped_low_count", "")),
                    str(schedule.get("duplicate_positive_timestep_count", "")),
                ]
            )
            + " |"
        )

    lines.extend(["", "## DPM++ 2M Numeric Comparisons", ""])
    comparisons = safe_report.get("dpm_comparisons", {})
    if not comparisons:
        lines.append("No completed DPM++ 2M variant comparisons were available.")
    else:
        for case_id, case_comparisons in comparisons.items():
            lines.append(f"### {case_id}")
            lines.append("")
            lines.append("```json")
            lines.append(json.dumps(case_comparisons, indent=2))
            lines.append("```")
            lines.append("")

    lines.extend(
        [
            "## Interpretation Order",
            "",
            "1. Compare A against B to measure schedule-domain impact.",
            "2. Compare A against C to measure float32 solver impact.",
            "3. Compare A against D to measure the combined correction.",
            "4. Compare all DPM images against the native Simple Euler and KES rows for the same case.",
            "",
        ]
    )
    markdown_path.write_text("\n".join(lines), encoding="utf-8")
    return json_path, markdown_path


def main() -> int:
    args = parse_args()
    if args.capabilities:
        print(json.dumps(capability_matrix(), indent=2))
        return 0

    context = ProjectContext.load(
        project_root=args.project_root,
        config_path=args.project_config,
    )

    from image_gen.systems.registry import RuntimeRegistrySystem

    registry = RuntimeRegistrySystem(project_context=context)
    available = [descriptor.name for descriptor in registry.descriptors("sampler")]
    if args.list_samplers:
        print("\n".join(available))
        return 0
    if not args.model:
        print("ERROR: --model is required unless --list-samplers or --capabilities is used.", file=sys.stderr)
        return 2

    selected = args.samplers or available
    unknown = sorted(set(selected).difference(available))
    if unknown:
        print(
            f"ERROR: Unknown sampler(s): {', '.join(unknown)}. Available: {', '.join(available)}",
            file=sys.stderr,
        )
        return 2

    variants = build_phase8a_variants(
        selected,
        include_dpm_isolation=not args.skip_dpm_isolation,
    )
    cases_path = context.resolve_project_path(args.cases_json)
    cases = load_cases(cases_path, limit=args.case_limit)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = (
        context.resolve_project_path(args.output_dir)
        if args.output_dir
        else context.project_root / "artifacts" / "phase08a_sampler_matrix" / stamp
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    report: dict[str, Any] = {
        "format": "image-gen-phase08a-sampler-matrix-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scheduler_name": args.scheduler,
        "cases_file": str(cases_path),
        "cases": cases,
        "available_samplers": available,
        "selected_samplers": selected,
        "variants": [variant.to_dict() for variant in variants],
        "runs": [],
        "dpm_comparisons": {},
        "technical_complete": False,
        "manual_image_review_required": True,
    }
    write_report(report, output_dir)

    validator = RealCheckpointValidationSystem(context)
    model_path = context.resolve_project_path(args.model)
    try:
        checkpoint = validator.inspect_checkpoint(model_path)
        validator.require_supported_architecture(checkpoint)
        report["checkpoint"] = checkpoint.to_dict()

        from transformers import CLIPTokenizer

        tokenizer = CLIPTokenizer.from_pretrained(
            str(context.tokenizer_root), local_files_only=True
        )
        report["tokenizer"] = validator.validate_tokenizer(
            tokenizer,
            [case["prompt"] for case in cases]
            + [case["negative_prompt"] for case in cases]
            + [""],
        )
        write_report(report, output_dir)
        if args.preflight_only:
            print("PASS: Phase 8A preflight completed.")
            print(f"Report: {output_dir / 'phase08a_sampler_matrix_report.json'}")
            return 0

        from image_gen.runtime.txt2img_runner import Txt2ImgRunner
        from image_gen.systems.model_loading import ModelLoadingSystem
        from modules.adapters.prompt_conditioning_adapter import PromptConditioningAdapter
        from modules.load_safetensors_model import LoadModel

        device = resolve_device(args.device)
        dtype = resolve_dtype(args.dtype, device)
        if device.type == "cpu" and dtype == torch.float16:
            raise ValueError("float16 CPU validation is not supported; use --dtype float32.")

        torch.use_deterministic_algorithms(True, warn_only=True)
        loader = LoadModel(project_context=context)
        runner = Txt2ImgRunner(
            prompt_adapter_factory=lambda **_: PromptConditioningAdapter(),
            scheduler_adapter=Phase8ASchedulerAdapter(),
            model_loader=loader,
            model_loading_system=ModelLoadingSystem(loader),
            project_context=context,
            registry_system=registry,
            tokenizer=tokenizer,
            device=device,
            dtype=dtype,
        )
        extras = {"model_path": str(model_path)}
        save_images = not args.no_save_images
        dpm_baselines: dict[str, dict[str, torch.Tensor | None]] = {}

        total = len(variants) * len(cases)
        run_number = 0
        for variant in variants:
            for case in cases:
                run_number += 1
                case_id = case["case_id"]
                run_dir = output_dir / "runs" / f"{run_number:02d}_{safe_name(variant.key)}" / safe_name(case_id)
                print("=" * 72)
                print(f"Phase 8A run {run_number}/{total}")
                print(f"Case:    {case_id}")
                print(f"Variant: {variant.label}")
                print(f"Output:  {run_dir}")

                request = build_request(
                    case=case,
                    variant=variant,
                    scheduler_name=args.scheduler,
                    output_dir=run_dir,
                    save_images=save_images,
                )
                torch.manual_seed(case["seed"])
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(case["seed"])
                runner.reset_runtime_state()

                try:
                    result = runner.run_request(request, extras)
                    record = run_record(case=case, variant=variant, result=result)
                    report["runs"].append(record)

                    if variant.key == "dpmpp_2m_A_native_latent":
                        dpm_baselines[case_id] = {
                            "latents": result.pipeline_result.latents.detach().cpu(),
                            "images": (
                                result.pipeline_result.images.detach().cpu()
                                if result.pipeline_result.images is not None
                                else None
                            ),
                        }
                    elif variant.sampler_name == "dpmpp_2m" and case_id in dpm_baselines:
                        baseline = dpm_baselines[case_id]
                        comparisons = report["dpm_comparisons"].setdefault(case_id, {})
                        item: dict[str, Any] = {}
                        if baseline["latents"] is not None:
                            item["latents_vs_A"] = compare_tensors(
                                baseline["latents"],
                                result.pipeline_result.latents.detach().cpu(),
                                atol=1e-5,
                                rtol=1e-5,
                            )
                        if (
                            baseline["images"] is not None
                            and result.pipeline_result.images is not None
                        ):
                            item["images_vs_A"] = compare_tensors(
                                baseline["images"],
                                result.pipeline_result.images.detach().cpu(),
                                atol=1e-5,
                                rtol=1e-5,
                            )
                        comparisons[variant.key] = item
                except Exception as exc:
                    report["runs"].append(
                        error_record(case=case, variant=variant, error=exc)
                    )
                    print(f"FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
                    if args.fail_fast:
                        write_report(report, output_dir)
                        raise
                finally:
                    report["technical_complete"] = bool(report["runs"]) and all(
                        item.get("status") == "completed" for item in report["runs"]
                    ) and len(report["runs"]) == total
                    write_report(report, output_dir)

        json_path, markdown_path = write_report(report, output_dir)
        print("=" * 72)
        print("IMAGE_GEN - PHASE 8A SAMPLER MATRIX")
        print(f"Technical result: {'PASS' if report['technical_complete'] else 'FAIL'}")
        print(f"Runs completed:   {sum(item['status'] == 'completed' for item in report['runs'])}/{total}")
        print(f"JSON report:      {json_path}")
        print(f"Text report:      {markdown_path}")
        print("Manual image review is required before selecting the Phase 8B repair path.")
        return 0 if report["technical_complete"] else 1
    except Exception as exc:
        report["fatal_error"] = {
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        write_report(report, output_dir)
        print(f"ERROR: {exc}", file=sys.stderr)
        print(f"Report: {output_dir / 'phase08a_sampler_matrix_report.json'}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
