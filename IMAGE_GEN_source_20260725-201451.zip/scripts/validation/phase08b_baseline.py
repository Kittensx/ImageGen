#!/usr/bin/env python3
"""Run the Phase 8B native high-sigma DPM++ 2M diagnostic baseline."""
from __future__ import annotations

import argparse
import json
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from image_gen.contracts import GenerationRequest
from image_gen.systems.diagnostics.serialization import json_safe
from image_gen.systems.validation import RealCheckpointValidationSystem
from modules.project_context import ProjectContext
from scripts.validation.phase08a_sampler_matrix import (
    load_cases,
    resolve_device,
    resolve_dtype,
    safe_name,
)

DEFAULT_CASES = (
    PROJECT_ROOT / "scripts" / "validation" / "profiles" / "phase08b_cases.json"
)
REQUIRED_STEP_FIELDS = {
    "timestep",
    "model_input",
    "solver_latent_before",
    "unconditional_model_output",
    "conditional_model_output",
    "guided_model_output",
    "prediction_type",
    "predicted_x0",
    "predicted_x0_comparison",
    "update_order",
    "history_accepted",
    "history_rejection_reason",
    "solver_latent_after",
    "finite_status",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", help="Full SD1 .safetensors checkpoint")
    parser.add_argument("--project-root")
    parser.add_argument("--project-config")
    parser.add_argument("--output-dir")
    parser.add_argument("--cases-json", default=str(DEFAULT_CASES))
    parser.add_argument("--case-limit", type=int, default=0)
    parser.add_argument("--scheduler", default="simple_kes")
    parser.add_argument("--device", default="auto")
    parser.add_argument(
        "--dtype",
        choices=("auto", "float16", "float32", "bfloat16"),
        default="auto",
    )
    parser.add_argument("--no-save-images", action="store_true")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--fail-fast", action="store_true")
    return parser.parse_args()


def build_request(
    *,
    case: dict[str, Any],
    scheduler_name: str,
    run_dir: Path,
    save_images: bool,
) -> GenerationRequest:
    return GenerationRequest(
        positive_prompt=case["prompt"],
        negative_prompt=case["negative_prompt"],
        width=case["width"],
        height=case["height"],
        steps=case["steps"],
        cfg_scale=case["cfg_scale"],
        batch_size=1,
        seed=case["seed"],
        scheduler_name=scheduler_name,
        sampler_name="dpmpp_2m",
        scheduler_kwargs=dict(case.get("scheduler_kwargs") or {}),
        sampler_kwargs={
            **dict(case.get("sampler_kwargs") or {}),
            "solver_dtype": "float32",
        },
        diagnostics={
            "artifacts_root": str(run_dir),
            "verbosity": "normal",
            "export_events": True,
            "tensor_summaries": True,
            "tensor_statistics": True,
            "progress": True,
            "failure_bundles": True,
            "sampler_trace": {
                "enabled": True,
                "export_json": True,
                "export_csv": True,
                "export_txt_summary": True,
                "capture_latents": False,
                "predicted_x0_previews": True,
                "run_name": f"phase08b_{safe_name(case['case_id'])}",
                "output_dir": str(run_dir / "traces"),
            },
        },
        save_images=save_images,
        output_dir=str(run_dir / "final"),
        output_prefix="{index:05d}-{seed}",
    )


def inspect_trace(result: Any) -> dict[str, Any]:
    exports = dict(result.pipeline_result.trace_exports or {})
    trace_path = Path(str(exports.get("json", "")))
    preview_manifest_path = Path(str(exports.get("predicted_x0_manifest", "")))
    checks: dict[str, Any] = {
        "trace_json_exists": trace_path.is_file(),
        "preview_manifest_exists": preview_manifest_path.is_file(),
        "required_fields_present": False,
        "step_count_matches_schedule": False,
        "all_recorded_values_finite": False,
        "first_second_order_step": None,
        "first_nonfinite_step": None,
        "preview_saved_count": 0,
        "preview_failed_count": 0,
    }
    if trace_path.is_file():
        trace = json.loads(trace_path.read_text(encoding="utf-8"))
        records = trace.get("records") or []
        transitions = int(result.pipeline_result.schedule.sigma_transitions)
        checks["step_count_matches_schedule"] = len(records) == transitions
        checks["required_fields_present"] = bool(records) and all(
            REQUIRED_STEP_FIELDS.issubset(set(record.get("extra") or {}))
            for record in records
        )
        finite = []
        for record in records:
            extra = record.get("extra") or {}
            status = extra.get("finite_status") or {}
            finite.append(all(value is True for value in status.values()))
            if checks["first_second_order_step"] is None and extra.get(
                "update_order"
            ) == "second_order":
                checks["first_second_order_step"] = record.get("step_index")
            if checks["first_nonfinite_step"] is None and status and not all(
                value is True for value in status.values()
            ):
                checks["first_nonfinite_step"] = record.get("step_index")
        checks["all_recorded_values_finite"] = bool(finite) and all(finite)

    if preview_manifest_path.is_file():
        preview = json.loads(preview_manifest_path.read_text(encoding="utf-8"))
        records = preview.get("records") or []
        checks["preview_saved_count"] = sum(
            item.get("status") == "saved" for item in records
        )
        checks["preview_failed_count"] = sum(
            item.get("status") == "failed" for item in records
        )
        checks["preview_selection"] = preview.get("selection") or {}

    schedule = result.pipeline_result.schedule
    checks["initial_sigma"] = float(schedule.initial_sigma)
    checks["native_high_sigma_preserved"] = 35.0 <= float(schedule.initial_sigma) <= 60.0
    checks["solver_dtype"] = result.pipeline_result.sampler_extra.get("solver_dtype")
    checks["solver_float32"] = checks["solver_dtype"] == "torch.float32"
    checks["passed"] = all(
        [
            checks["trace_json_exists"],
            checks["preview_manifest_exists"],
            checks["required_fields_present"],
            checks["step_count_matches_schedule"],
            checks["all_recorded_values_finite"],
            checks["native_high_sigma_preserved"],
            checks["solver_float32"],
            checks["preview_saved_count"] > 0,
        ]
    )
    return checks


def write_report(report: dict[str, Any], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = json_safe(report)
    json_path = output_dir / "phase08b_baseline_report.json"
    json_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    lines = [
        "# Phase 08B Baseline Diagnostic Report",
        "",
        f"Created: {payload.get('created_utc')}",
        f"Technical result: {'PASS' if payload.get('technical_complete') else 'FAIL'}",
        "",
        "## Runs",
        "",
    ]
    for item in payload.get("runs", []):
        lines.extend(
            [
                f"### {item.get('case_id')}",
                "",
                f"Status: {item.get('status')}",
                "",
                "```json",
                json.dumps(item.get("checks") or item.get("error"), indent=2),
                "```",
                "",
            ]
        )
    lines.extend(
        [
            "## Interpretation",
            "",
            "Use the predicted-x0 previews and trace fields to identify whether degradation begins before or after the first second-order history update.",
            "",
        ]
    )
    markdown_path = output_dir / "phase08b_baseline_report.md"
    markdown_path.write_text("\n".join(lines), encoding="utf-8")
    return json_path, markdown_path


def main() -> int:
    args = parse_args()
    if not args.model:
        print("ERROR: --model is required.", file=sys.stderr)
        return 2

    context = ProjectContext.load(
        project_root=args.project_root,
        config_path=args.project_config,
    )
    cases_path = context.resolve_project_path(args.cases_json)
    cases = load_cases(cases_path, limit=args.case_limit)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = (
        context.resolve_project_path(args.output_dir)
        if args.output_dir
        else context.project_root / "artifacts" / "phase08b_diagnostics" / stamp
    )
    report: dict[str, Any] = {
        "format": "image-gen-phase08b-baseline-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scheduler_name": args.scheduler,
        "sampler_name": "dpmpp_2m",
        "solver_dtype": "float32",
        "cases_file": str(cases_path),
        "runs": [],
        "technical_complete": False,
        "manual_image_review_required": True,
    }
    write_report(report, output_dir)

    validator = RealCheckpointValidationSystem(context)
    model_path = context.resolve_project_path(args.model)
    try:
        checkpoint = validator.inspect_checkpoint(model_path)
        validator.require_supported_architecture(checkpoint)
        report["checkpoint"] = checkpoint.to_dict()

        from transformers import CLIPTokenizer

        tokenizer = CLIPTokenizer.from_pretrained(
            str(context.tokenizer_root), local_files_only=True
        )
        report["tokenizer"] = validator.validate_tokenizer(
            tokenizer,
            [case["prompt"] for case in cases]
            + [case["negative_prompt"] for case in cases]
            + [""],
        )
        write_report(report, output_dir)
        if args.preflight_only:
            print("PASS: Phase 8B preflight completed.")
            print(f"Report: {output_dir / 'phase08b_baseline_report.json'}")
            return 0

        from image_gen.runtime.txt2img_runner import Txt2ImgRunner
        from image_gen.systems.model_loading import ModelLoadingSystem
        from image_gen.systems.registry import RuntimeRegistrySystem
        from modules.adapters.prompt_conditioning_adapter import PromptConditioningAdapter
        from modules.load_safetensors_model import LoadModel

        device = resolve_device(args.device)
        dtype = resolve_dtype(args.dtype, device)
        if device.type == "cpu" and dtype == torch.float16:
            raise ValueError("float16 CPU validation is not supported; use --dtype float32.")

        torch.use_deterministic_algorithms(True, warn_only=True)
        registry = RuntimeRegistrySystem(project_context=context)
        loader = LoadModel(project_context=context)
        runner = Txt2ImgRunner(
            prompt_adapter_factory=lambda **_: PromptConditioningAdapter(),
            model_loader=loader,
            model_loading_system=ModelLoadingSystem(loader),
            project_context=context,
            registry_system=registry,
            tokenizer=tokenizer,
            device=device,
            dtype=dtype,
        )
        extras = {"model_path": str(model_path)}
        save_images = not args.no_save_images

        for index, case in enumerate(cases, start=1):
            run_dir = output_dir / "runs" / f"{index:02d}_{safe_name(case['case_id'])}"
            print("=" * 72)
            print(f"Phase 8B case {index}/{len(cases)}: {case['case_id']}")
            print(f"Output: {run_dir}")
            request = build_request(
                case=case,
                scheduler_name=args.scheduler,
                run_dir=run_dir,
                save_images=save_images,
            )
            torch.manual_seed(case["seed"])
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(case["seed"])
            runner.reset_runtime_state()
            try:
                result = runner.run_request(request, extras)
                checks = inspect_trace(result)
                report["runs"].append(
                    {
                        "case_id": case["case_id"],
                        "status": "completed" if checks["passed"] else "failed_checks",
                        "checks": checks,
                        "saved_images": [record.image_path for record in result.saved_records],
                        "trace_exports": result.pipeline_result.trace_exports,
                    }
                )
            except Exception as exc:
                report["runs"].append(
                    {
                        "case_id": case["case_id"],
                        "status": "error",
                        "error": {
                            "error_type": type(exc).__name__,
                            "error": str(exc),
                            "traceback": traceback.format_exc(),
                        },
                    }
                )
                print(f"FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
                if args.fail_fast:
                    write_report(report, output_dir)
                    raise
            finally:
                report["technical_complete"] = (
                    len(report["runs"]) == len(cases)
                    and all(item.get("status") == "completed" for item in report["runs"])
                )
                write_report(report, output_dir)

        json_path, markdown_path = write_report(report, output_dir)
        print("=" * 72)
        print("IMAGE_GEN - PHASE 8B BASELINE AND DIAGNOSTICS")
        print(f"Technical result: {'PASS' if report['technical_complete'] else 'FAIL'}")
        print(f"JSON report:      {json_path}")
        print(f"Text report:      {markdown_path}")
        print("Manual review of final and predicted-x0 images is required.")
        return 0 if report["technical_complete"] else 1
    except Exception as exc:
        report["fatal_error"] = {
            "error_type": type(exc).__name__,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        write_report(report, output_dir)
        print(f"ERROR: {exc}", file=sys.stderr)
        print(f"Report: {output_dir / 'phase08b_baseline_report.json'}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
