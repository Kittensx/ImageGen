#!/usr/bin/env python3
"""Run the controlled IMAGE_GEN Phase 07 SD1 checkpoint validation profile."""
from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from typing import Any

import torch

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from image_gen.contracts import GenerationRequest
from image_gen.systems.validation import (
    RealCheckpointValidationSystem,
    ValidationProfile,
    capability_matrix,
)
from modules.project_context import ProjectContext


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", help="Full SD1 .safetensors checkpoint")
    parser.add_argument("--project-root")
    parser.add_argument("--project-config")
    parser.add_argument("--output-dir")
    parser.add_argument("--prompt", default=ValidationProfile.prompt)
    parser.add_argument("--negative-prompt", default=ValidationProfile.negative_prompt)
    parser.add_argument("--seed", type=int, default=ValidationProfile.seed)
    parser.add_argument("--steps", type=int, default=ValidationProfile.steps)
    parser.add_argument("--width", type=int, default=ValidationProfile.width)
    parser.add_argument("--height", type=int, default=ValidationProfile.height)
    parser.add_argument("--cfg-scale", type=float, default=ValidationProfile.cfg_scale)
    parser.add_argument("--scheduler", default=ValidationProfile.scheduler_name)
    parser.add_argument("--baseline-sampler", default=ValidationProfile.baseline_sampler)
    parser.add_argument("--comparison-sampler", default=ValidationProfile.comparison_sampler)
    parser.add_argument("--device", default="auto")
    parser.add_argument("--dtype", choices=("auto", "float16", "float32", "bfloat16"), default="auto")
    parser.add_argument("--atol", type=float, default=ValidationProfile.absolute_tolerance)
    parser.add_argument("--rtol", type=float, default=ValidationProfile.relative_tolerance)
    parser.add_argument("--no-save-images", action="store_true")
    parser.add_argument("--capabilities", action="store_true", help="Print architecture capability status and exit")
    parser.add_argument("--preflight-only", action="store_true", help="Inspect checkpoint and tokenizer without loading model components")
    return parser.parse_args()


def resolve_device(value: str) -> torch.device:
    if value == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(value)


def resolve_dtype(value: str, device: torch.device) -> torch.dtype:
    if value == "auto":
        return torch.float16 if device.type == "cuda" else torch.float32
    return {
        "float16": torch.float16,
        "float32": torch.float32,
        "bfloat16": torch.bfloat16,
    }[value]


def prepare_validation_output_dirs(
    output_dir: Path,
    *,
    save_images: bool,
) -> tuple[Path, Path]:
    """Create the Phase 07-owned image directories before path validation."""
    baseline_dir = output_dir / "images" / "baseline"
    comparison_dir = output_dir / "images" / "kes"
    if save_images:
        baseline_dir.mkdir(parents=True, exist_ok=True)
        comparison_dir.mkdir(parents=True, exist_ok=True)
    return baseline_dir, comparison_dir


def build_request(
    profile: ValidationProfile,
    *,
    sampler_name: str,
    output_dir: Path,
    output_prefix: str,
    save_images: bool,
) -> GenerationRequest:
    return GenerationRequest(
        positive_prompt=profile.prompt,
        negative_prompt=profile.negative_prompt,
        width=profile.width,
        height=profile.height,
        steps=profile.steps,
        cfg_scale=profile.cfg_scale,
        batch_size=profile.batch_size,
        seed=profile.seed,
        scheduler_name=profile.scheduler_name,
        sampler_name=sampler_name,
        scheduler_kwargs={
            # Keep the validation schedule within the SD1 training sigma range.
            "sigma_min": 0.03,
            "sigma_max": 14.0,
            "rho": 7.0,
            "tail_steps": 1,
            "verbose": False,
        },
        sampler_kwargs={"verbose": False},
        diagnostics={
            "verbosity": "normal",
            "export_events": True,
            "tensor_summaries": True,
            "tensor_statistics": True,
            "progress": True,
            "failure_bundles": True,
        },
        save_images=save_images,
        output_dir=str(output_dir),
        output_prefix=output_prefix,
    )


def write_preflight_failure(
    output_dir: Path,
    *,
    checkpoint: dict[str, Any] | None,
    error: BaseException,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "format": "image-gen-phase07-preflight-failure-v1",
        "checkpoint": checkpoint,
        "error_type": type(error).__name__,
        "error": str(error),
        "capabilities": capability_matrix(),
    }
    (output_dir / "phase07_preflight_failure.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )


def main() -> int:
    args = parse_args()
    if args.capabilities:
        print(json.dumps(capability_matrix(), indent=2))
        return 0
    if not args.model:
        print("ERROR: --model is required unless --capabilities is used.", file=sys.stderr)
        return 2

    context = ProjectContext.load(
        project_root=args.project_root,
        config_path=args.project_config,
    )
    model_path = context.resolve_project_path(args.model)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output_dir = (
        context.resolve_project_path(args.output_dir)
        if args.output_dir
        else context.project_root / "artifacts" / "phase07_validation" / stamp
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    profile = ValidationProfile(
        prompt=args.prompt,
        negative_prompt=args.negative_prompt,
        seed=args.seed,
        steps=args.steps,
        width=args.width,
        height=args.height,
        cfg_scale=args.cfg_scale,
        scheduler_name=args.scheduler,
        baseline_sampler=args.baseline_sampler,
        comparison_sampler=args.comparison_sampler,
        absolute_tolerance=args.atol,
        relative_tolerance=args.rtol,
    )
    validator = RealCheckpointValidationSystem(context)
    checkpoint_dict: dict[str, Any] | None = None
    try:
        checkpoint = validator.inspect_checkpoint(model_path)
        checkpoint_dict = checkpoint.to_dict()
        capability = validator.require_supported_architecture(checkpoint)

        from transformers import CLIPTokenizer

        tokenizer = CLIPTokenizer.from_pretrained(
            str(context.tokenizer_root), local_files_only=True
        )
        tokenizer_report = validator.validate_tokenizer(
            tokenizer,
            [profile.prompt, profile.negative_prompt, "a cat", ""],
        )
        preflight = {
            "checkpoint": checkpoint_dict,
            "architecture_capability": capability.to_dict(),
            "tokenizer": tokenizer_report,
            "profile": profile.to_dict(),
        }
        (output_dir / "phase07_preflight.json").write_text(
            json.dumps(preflight, indent=2), encoding="utf-8"
        )
        if args.preflight_only:
            print("PASS: Phase 07 preflight completed.")
            print(f"Report: {output_dir / 'phase07_preflight.json'}")
            return 0

        from image_gen.runtime.txt2img_runner import Txt2ImgRunner
        from image_gen.systems.model_loading import ModelLoadingSystem
        from image_gen.systems.registry import RuntimeRegistrySystem
        from modules.adapters.prompt_conditioning_adapter import PromptConditioningAdapter
        from modules.load_safetensors_model import LoadModel

        device = resolve_device(args.device)
        dtype = resolve_dtype(args.dtype, device)
        if device.type == "cpu" and dtype == torch.float16:
            raise ValueError("float16 CPU validation is not supported; use --dtype float32.")

        torch.manual_seed(profile.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(profile.seed)
        torch.use_deterministic_algorithms(True, warn_only=True)

        registry = RuntimeRegistrySystem(project_context=context)
        loader = LoadModel(project_context=context)
        model_loading = ModelLoadingSystem(loader)
        runner = Txt2ImgRunner(
            prompt_adapter_factory=lambda **_: PromptConditioningAdapter(),
            model_loader=loader,
            model_loading_system=model_loading,
            project_context=context,
            registry_system=registry,
            tokenizer=tokenizer,
            device=device,
            dtype=dtype,
        )
        extras = {"model_path": str(model_path)}
        save_images = not args.no_save_images

        baseline_dir, comparison_dir = prepare_validation_output_dirs(
            output_dir,
            save_images=save_images,
        )

        first_request = build_request(
            profile,
            sampler_name=profile.baseline_sampler,
            output_dir=baseline_dir,
            output_prefix="baseline_first",
            save_images=save_images,
        )
        first = runner.run_request(first_request, extras)
        loaded = runner.last_loaded_model
        if loaded is None:
            raise RuntimeError("The baseline run completed without exposing loaded components.")
        component_coverage = validator.component_coverage(loaded.built_components)

        runner.reset_runtime_state()
        repeat_request = build_request(
            profile,
            sampler_name=profile.baseline_sampler,
            output_dir=baseline_dir,
            output_prefix="baseline_repeat",
            save_images=save_images,
        )
        repeat = runner.run_request(repeat_request, extras)

        runner.reset_runtime_state()
        comparison_request = build_request(
            profile,
            sampler_name=profile.comparison_sampler,
            output_dir=comparison_dir,
            output_prefix="kes",
            save_images=save_images,
        )
        comparison = runner.run_request(comparison_request, extras)

        report = validator.build_report(
            profile=profile,
            checkpoint=checkpoint,
            tokenizer_report=tokenizer_report,
            component_coverage=component_coverage,
            baseline_first=first,
            baseline_repeat=repeat,
            comparison_run=comparison,
        )
        json_path, markdown_path = validator.write_report(report, output_dir)
        print("=" * 60)
        print("IMAGE_GEN - PHASE 07 REAL CHECKPOINT VALIDATION")
        print(f"Result:       {'PASS' if report.passed else 'FAIL'}")
        print(f"Checkpoint:   {checkpoint.file_name}")
        print(f"Architecture: {checkpoint.architecture}")
        print(f"SHA-256:      {checkpoint.sha256}")
        print(f"JSON report:  {json_path}")
        print(f"Text report:  {markdown_path}")
        for check in report.checks:
            print(f"[{check.status.upper()}] {check.check_id}: {check.summary}")
        return 0 if report.passed else 1
    except Exception as exc:
        write_preflight_failure(output_dir, checkpoint=checkpoint_dict, error=exc)
        print(f"ERROR: {exc}", file=sys.stderr)
        print(f"Failure report: {output_dir / 'phase07_preflight_failure.json'}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
