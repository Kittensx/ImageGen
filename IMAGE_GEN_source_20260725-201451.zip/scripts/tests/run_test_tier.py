#!/usr/bin/env python3
"""Run the documented IMAGE_GEN test tiers with focused, explicit commands."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]

TEST_TIERS = {
    "unit": [
        "tests.phase00.test_phase00_baseline_repairs",
        "tests.phase03.test_phase03_pipeline_correctness",
        "tests.phase06.test_phase06_diagnostics",
    ],
    "contract": [
        "tests.phase02.test_phase02_runtime_contracts",
        "tests.phase05.test_phase05_registry_plugins",
    ],
    "integration": [
        "tests.phase00.test_phase00_baseline",
        "tests.phase00.test_phase00_baseline_repairs",
        "tests.phase01.test_phase01_project_context",
        "tests.phase04.test_phase04_system_modules",
        "tests.phase06.test_phase06_diagnostics",
    ],
    "phase07": [
        "tests.phase07.test_phase07_real_checkpoint_validation",
    ],
    "phase08a": [
        "tests.phase08.test_phase08a_sampler_isolation",
        "tests.phase08.test_phase08b_baseline_diagnostics",
    ],
    "phase08b": [
        "tests.phase08.test_phase08b_baseline_diagnostics",
    ],
    "focused": [
        "tests.phase00.test_phase00_baseline",
        "tests.phase00.test_phase00_baseline_repairs",
        "tests.phase01.test_phase01_project_context",
        "tests.phase02.test_phase02_runtime_contracts",
        "tests.phase03.test_phase03_pipeline_correctness",
        "tests.phase04.test_phase04_system_modules",
        "tests.phase05.test_phase05_registry_plugins",
        "tests.phase06.test_phase06_diagnostics",
        "tests.phase07.test_phase07_real_checkpoint_validation",
        "tests.phase08.test_phase08a_sampler_isolation",
    ],
}


def run(command: list[str], *, env: dict[str, str] | None = None) -> int:
    print("+", subprocess.list2cmdline(command))
    completed = subprocess.run(
        command,
        cwd=PROJECT_ROOT,
        env=env,
        check=False,
    )
    return int(completed.returncode)


def run_static() -> int:
    output = PROJECT_ROOT / "artifacts" / "test_reports" / "phase06_static_audit.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    return run(
        [
            sys.executable,
            str(PROJECT_ROOT / "scripts" / "audit" / "phase00_audit.py"),
            "--output",
            str(output),
        ]
    )


def run_unittest_tier(tier: str) -> int:
    return run([sys.executable, "-m", "unittest", *TEST_TIERS[tier], "-v"])


def run_checkpoint(args: argparse.Namespace) -> int:
    model = args.model or os.environ.get("IMAGE_GEN_CHECKPOINT")
    if not model:
        print(
            "Checkpoint tier requires --model PATH or IMAGE_GEN_CHECKPOINT. "
            "No checkpoint smoke test was run.",
            file=sys.stderr,
        )
        return 2
    command = [
        sys.executable,
        "-m",
        "modules.txt2img.cli",
        "run",
        "--model",
        str(Path(model).expanduser()),
        "--prompt",
        "IMAGE_GEN Phase 06 checkpoint smoke test",
        "--negative-prompt",
        "",
        "--seed",
        "606",
        "--steps",
        str(args.steps),
        "--width",
        str(args.width),
        "--height",
        str(args.height),
        "--sampler",
        "simple_euler",
        "--scheduler",
        "simple_kes",
        "--no-save",
        "--no-progress",
        "--diagnostics",
        args.diagnostics,
    ]
    if args.project_root:
        command.extend(["--project-root", args.project_root])
    return run(command)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "tier",
        nargs="?",
        default="focused",
        choices=("static", "unit", "contract", "integration", "phase07", "phase08a", "phase08b", "focused", "checkpoint"),
    )
    parser.add_argument("--model", help="Checkpoint path for the checkpoint tier")
    parser.add_argument("--project-root")
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--width", type=int, default=64)
    parser.add_argument("--height", type=int, default=64)
    parser.add_argument(
        "--diagnostics",
        choices=("quiet", "normal", "verbose", "trace"),
        default="normal",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.tier == "static":
        return run_static()
    if args.tier == "checkpoint":
        return run_checkpoint(args)
    return run_unittest_tier(args.tier)


if __name__ == "__main__":
    raise SystemExit(main())
