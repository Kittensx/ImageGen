# IMAGE_GEN Test Tiers

The phase runner uses explicit, focused tiers rather than an implicit repository-wide suite.

```bat
phase06_tests.bat static
phase06_tests.bat unit
phase06_tests.bat contract
phase06_tests.bat integration
phase06_tests.bat phase07
phase06_tests.bat phase08a
phase06_tests.bat phase08b
phase06_tests.bat focused
```

The Phase 07 model-free validation tests can also be run directly:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py phase07
```

The Phase 8A sampler-isolation tests can be run without a checkpoint:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py phase08a
```

The Phase 8B baseline-diagnostics tests can be run without a checkpoint:

```bat
venv\Scripts\python.exe scripts\tests\run_test_tier.py phase08b
```

The full native high-sigma Phase 8B checkpoint run is:

```bat
phase08b_validate.bat "models\StableDiffusion\CheckPoints\model.safetensors"
```

The older two-step real-checkpoint smoke command remains available but is not run without an explicitly supplied model:

```bat
phase06_tests.bat checkpoint --model "models\StableDiffusion\CheckPoints\model.safetensors"
```

Formal checkpoint inspection, component coverage, tokenizer evidence, sampler comparison, and reproducibility validation now use:

```bat
phase07_validate.bat --model "models\StableDiffusion\CheckPoints\model.safetensors"
```
