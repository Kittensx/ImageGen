"""Static and model-free audit tooling for IMAGE_GEN."""
