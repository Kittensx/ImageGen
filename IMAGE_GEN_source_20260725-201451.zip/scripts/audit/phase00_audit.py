#!/usr/bin/env python3
"""Run the IMAGE_GEN Phase 00 baseline audit without loading a checkpoint.

The audit intentionally separates three kinds of results:

* blocking failures in files classified as active;
* approved baseline gaps that later phases are expected to repair; and
* legacy/experimental problems retained only for inventory purposes.

The generated JSON report is written under ``artifacts/phase00_audit`` by
default. That directory is intentionally excluded from source packages.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import re
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUTPUT = PROJECT_ROOT / "artifacts" / "phase00_audit" / "phase00_audit_report.json"
INTERNAL_ROOTS = {"app", "image_gen", "modules", "scripts", "tests"}

CANONICAL_PIPELINE = [
    "run.bat",
    "modules.txt2img.cli",
    "image_gen.runtime.txt2img_runner.Txt2ImgRunner",
    "image_gen.systems.registry.RuntimeRegistrySystem",
    "image_gen.systems.model_loading.ModelLoadingSystem",
    "image_gen.runtime.PipelineCompositionRoot",
    "image_gen.systems.conditioning.ConditioningSystem",
    "image_gen.systems.scheduling.SchedulingSystem",
    "image_gen.systems.sampling.LatentPreparationSystem",
    "image_gen.systems.sampling.SamplingSystem",
    "image_gen.systems.denoising.DenoisingSystem",
    "image_gen.systems.decoding.DecodingSystem",
    "image_gen.systems.diagnostics.DiagnosticsSystem",
    "image_gen.systems.output.OutputSystem",
]

LEGACY_PATHS = {
    "app/run.py": "Compatibility launcher retained for callers that still invoke the older Python entry point.",
    "modules/generation_test.py": "Compatibility launcher for the explicit canonical checkpoint smoke test.",
    "modules/_imagecore/image_saver.py": "Older image saver retained for reference; txt2img/output_saver.py is the active saver.",
}

EXPERIMENTAL_PREFIXES = (
    "docs/ideas/",
    "docs/planning/historical/",
    "modules/ss_registry/schedulers/simple_kes_sched/legacy_kes_config/",
)

EXPERIMENTAL_PATHS = {
    "modules/database_models_idea.txt": "Design note, not runtime source.",
    "modules/ss_registry/samplers/kes_sampler/ideas.docx": "Sampler design note.",
    "modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/sampler_advanced.py": (
        "Archived advanced-sampler helper experiment. It is valid Python but remains outside the active sampler path."
    ),
    "modules/ss_registry/schedulers/refactor_plan.txxt": "Historical scheduler refactor note.",
}

GENERATED_PATHS = {
    "_image_gen_package_manifest.json",
    "modules/ss_registry/sampler_map.py",
    "modules/ss_registry/scheduler_map.py",
}
GENERATED_PREFIXES = (
    "artifacts/",
    "outputs/",
    "output/",
    "logs/",
    "traces/",
    "modules/pipeline/image_generation_data/",
)

# These imports are intentionally preserved as baseline evidence. Both callers
# catch the failure and define a local SamplerOutput fallback. Phase 02 owns the
# contract repair, so Phase 00 reports them without treating them as new drift.
APPROVED_INTERNAL_IMPORT_GAPS = {
    (
        "modules/ss_registry/samplers/simple_samplers/dpmpp_2m_sampler.py",
        "modules.pipeline.pipeline_builder",
    ): "Guarded fallback import; canonical contract currently lives at modules.pipeline_builder.",
    (
        "modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/kes_sampler.py",
        "modules.pipeline.pipeline_builder",
    ): "Guarded fallback import; canonical contract currently lives at modules.pipeline_builder.",
}

RUNTIME_DEPENDENCY_PROBES = {
    "torch": "torch",
    "Pillow": "PIL",
    "PyYAML": "yaml",
    "safetensors": "safetensors",
    "transformers": "transformers",
    "diffusers": "diffusers",
    "accelerate": "accelerate",
}


@dataclass(frozen=True)
class InventoryItem:
    path: str
    classification: str
    reason: str
    size_bytes: int
    sha256: str
    syntax_status: Optional[str] = None
    syntax_error: Optional[str] = None


@dataclass(frozen=True)
class ImportRecord:
    source: str
    module: str
    resolved: bool
    approved_gap: bool
    reason: str
    line: int


def _relative(path: Path) -> str:
    return path.relative_to(PROJECT_ROOT).as_posix()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _classify(rel: str) -> tuple[str, str]:
    if rel in GENERATED_PATHS or rel.startswith(GENERATED_PREFIXES):
        return "generated", "Generated runtime, discovery, package, or audit output."
    if rel in LEGACY_PATHS:
        return "legacy", LEGACY_PATHS[rel]
    if rel in EXPERIMENTAL_PATHS:
        return "experimental", EXPERIMENTAL_PATHS[rel]
    if rel.startswith(EXPERIMENTAL_PREFIXES):
        return "experimental", "Research, historical planning, or legacy configuration material."
    return "active", "Part of the current source, configuration, documentation, launcher, or validation surface."


def _syntax_result(path: Path) -> tuple[Optional[str], Optional[str]]:
    if path.suffix.lower() != ".py":
        return None, None
    try:
        source = path.read_text(encoding="utf-8-sig")
        compile(source, str(path), "exec", dont_inherit=True)
        return "pass", None
    except (SyntaxError, UnicodeError) as exc:
        return "fail", f"{type(exc).__name__}: {exc}"


def build_inventory() -> list[InventoryItem]:
    items: list[InventoryItem] = []
    for path in sorted(PROJECT_ROOT.rglob("*"), key=lambda item: item.as_posix().casefold()):
        if not path.is_file():
            continue
        if any(part in {".git", ".venv", "venv", "__pycache__"} for part in path.parts):
            continue
        rel = _relative(path)
        classification, reason = _classify(rel)
        syntax_status, syntax_error = _syntax_result(path)
        items.append(
            InventoryItem(
                path=rel,
                classification=classification,
                reason=reason,
                size_bytes=path.stat().st_size,
                sha256=_sha256(path),
                syntax_status=syntax_status,
                syntax_error=syntax_error,
            )
        )
    return items


def _module_exists(module: str) -> bool:
    parts = module.split(".")
    candidate = PROJECT_ROOT.joinpath(*parts)
    if candidate.with_suffix(".py").is_file() or candidate.is_dir():
        return True
    if parts and parts[0] == "image_gen":
        src_candidate = PROJECT_ROOT / "src" / "image_gen" / Path(*parts[1:])
        return src_candidate.with_suffix(".py").is_file() or src_candidate.is_dir()
    return False


def _module_name_for_file(path: Path) -> str:
    rel = path.relative_to(PROJECT_ROOT).with_suffix("")
    parts = list(rel.parts)
    if parts and parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def _resolve_relative_module(source_path: Path, level: int, module: Optional[str]) -> str:
    source_module = _module_name_for_file(source_path)
    package_parts = source_module.split(".")[:-1]
    if source_path.name == "__init__.py":
        package_parts = source_module.split(".")
    if level > len(package_parts) + 1:
        return module or ""
    base = package_parts[: len(package_parts) - level + 1]
    if module:
        base.extend(module.split("."))
    return ".".join(part for part in base if part)


def _iter_imports(path: Path) -> Iterable[tuple[str, int]]:
    tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                yield alias.name, int(getattr(node, "lineno", 0))
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                module = _resolve_relative_module(path, node.level, node.module)
            else:
                module = node.module or ""
            if module:
                yield module, int(getattr(node, "lineno", 0))


def audit_internal_imports(inventory: list[InventoryItem]) -> tuple[list[ImportRecord], list[dict[str, Any]]]:
    active_python = {
        item.path
        for item in inventory
        if item.classification == "active" and item.path.endswith(".py") and item.syntax_status == "pass"
    }
    records: list[ImportRecord] = []
    edges: list[dict[str, Any]] = []

    for rel in sorted(active_python):
        source_path = PROJECT_ROOT / rel
        for module, line in _iter_imports(source_path):
            root = module.split(".", 1)[0]
            if root not in INTERNAL_ROOTS:
                continue
            resolved = _module_exists(module)
            gap_reason = APPROVED_INTERNAL_IMPORT_GAPS.get((rel, module), "")
            approved_gap = bool(gap_reason and not resolved)
            reason = "resolved" if resolved else gap_reason or "Internal module path was not found."
            records.append(
                ImportRecord(
                    source=rel,
                    module=module,
                    resolved=resolved,
                    approved_gap=approved_gap,
                    reason=reason,
                    line=line,
                )
            )
            edges.append(
                {
                    "source": _module_name_for_file(source_path),
                    "target": module,
                    "resolved": resolved,
                    "approved_gap": approved_gap,
                    "line": line,
                }
            )
    return records, edges


def _requirement_names() -> list[str]:
    names: set[str] = set()
    for filename in ("requirements/requirements.txt", "requirements/requirements-blackwell.txt"):
        path = PROJECT_ROOT / filename
        if not path.exists():
            continue
        for raw in path.read_text(encoding="utf-8-sig").splitlines():
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            match = re.match(r"([A-Za-z0-9_.-]+)", line)
            if match:
                names.add(match.group(1))
    return sorted(names, key=str.casefold)


def _installed_version(distribution: str) -> Optional[str]:
    candidates = [distribution, distribution.replace("_", "-"), distribution.replace("-", "_")]
    for candidate in candidates:
        try:
            return importlib.metadata.version(candidate)
        except importlib.metadata.PackageNotFoundError:
            continue
    return None


def build_environment_report() -> dict[str, Any]:
    requirements = []
    for name in _requirement_names():
        version = _installed_version(name)
        requirements.append({"distribution": name, "installed": version is not None, "version": version})

    probes = []
    for distribution, import_name in RUNTIME_DEPENDENCY_PROBES.items():
        spec = importlib.util.find_spec(import_name)
        probes.append(
            {
                "distribution": distribution,
                "import_name": import_name,
                "importable": spec is not None,
                "version": _installed_version(distribution),
            }
        )

    return {
        "python": {
            "version": sys.version,
            "version_info": list(sys.version_info[:3]),
            "executable": sys.executable,
            "implementation": platform.python_implementation(),
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        },
        "working_directory": os.getcwd(),
        "project_root": str(PROJECT_ROOT),
        "requirements": requirements,
        "runtime_import_probes": probes,
    }


def _line_for(path: str, needle: str) -> Optional[int]:
    file_path = PROJECT_ROOT / path
    if not file_path.exists():
        return None
    for number, line in enumerate(file_path.read_text(encoding="utf-8-sig", errors="replace").splitlines(), start=1):
        if needle in line:
            return number
    return None


def build_known_issues(inventory: list[InventoryItem], imports: list[ImportRecord]) -> list[dict[str, Any]]:
    syntax_failures = {item.path: item.syntax_error for item in inventory if item.syntax_status == "fail"}
    unresolved = {(item.source, item.module): item for item in imports if not item.resolved}

    issues: list[dict[str, Any]] = []

    generation_test_path = "modules/generation_test.py"
    generation_test = PROJECT_ROOT / generation_test_path
    generation_text = generation_test.read_text(encoding="utf-8-sig", errors="replace") if generation_test.exists() else ""
    placeholder_markers = (
        "ExistingPromptParserAdapter",
        "YourPromptParserClass",
        "your_scheduler_registry",
        "your_sampler_registry",
    )
    if any(marker in generation_text for marker in placeholder_markers):
        issues.append(
            {
                "id": "P00-TEST-001",
                "severity": "known",
                "stage": "validation",
                "owner": "tests/compatibility",
                "path": generation_test_path,
                "line": _line_for(generation_test_path, "ExistingPromptParserAdapter"),
                "summary": "Placeholder generation test references nonexistent adapters and unresolved example symbols.",
                "classification": "legacy",
                "target_phase": "Phase 06",
            }
        )
    else:
        issues.append(
            {
                "id": "P00-TEST-001",
                "severity": "resolved",
                "stage": "validation",
                "owner": "tests/compatibility",
                "path": generation_test_path,
                "line": _line_for(generation_test_path, "CHECKPOINT_RUNNER"),
                "summary": "Resolved: the obsolete placeholder is now a compatibility launcher for the canonical checkpoint smoke test.",
                "classification": "legacy",
                "target_phase": "Complete - baseline stabilization",
            }
        )

    sampler_path = "modules/ss_registry/samplers/kes_sampler/simple_kes_sampler/sampler_advanced.py"
    sampler_error = syntax_failures.get(sampler_path)
    issues.append(
        {
            "id": "P00-SAMPLER-001",
            "severity": "known" if sampler_error else "resolved",
            "stage": "sampling",
            "owner": "sampling",
            "path": sampler_path,
            "line": 1,
            "summary": sampler_error or (
                "Resolved: the archived advanced-sampler helper is UTF-8, consistently indented, and importable."
            ),
            "classification": "experimental",
            "decision": "Archived experiment; not used by the active sampler registry.",
            "target_phase": "Phase 08" if sampler_error else "Complete - baseline stabilization",
        }
    )

    research_path = "docs/ideas/more_mem_optim.py"
    research_error = syntax_failures.get(research_path)
    issues.append(
        {
            "id": "P00-RESEARCH-001",
            "severity": "informational" if research_error else "resolved",
            "stage": "documentation",
            "owner": "research",
            "path": research_path,
            "line": 1,
            "summary": research_error or (
                "Resolved: the research sketch was normalized to UTF-8 and valid Python while remaining experimental documentation."
            ),
            "classification": "experimental",
            "target_phase": "None; not runtime source" if research_error else "Complete - baseline stabilization",
        }
    )

    issues.extend(
        [
            {
                "id": "P00-CONTRACT-001",
                "severity": "resolved",
                "stage": "sampling/denoising",
                "owner": "runtime contracts",
                "path": "modules/ss_registry/samplers/simple_samplers/simple_euler.py",
                "line": _line_for("modules/ss_registry/samplers/simple_samplers/simple_euler.py", "guided_model_fn("),
                "summary": "Resolved in Phase 03: baseline samplers now pass the explicit schedule timestep to the guided denoiser.",
                "classification": "active",
                "target_phase": "Complete - Phase 03",
            },
            {
                "id": "P00-OUTPUT-001",
                "severity": "resolved",
                "stage": "output",
                "owner": "output/runtime",
                "path": "src/image_gen/runtime/generation_pipeline.py",
                "line": _line_for("src/image_gen/runtime/generation_pipeline.py", "output_owner"),
                "summary": "Resolved in Phases 03-04: the core pipeline returns tensors and the dedicated output system is the sole file writer.",
                "classification": "active",
                "target_phase": "Complete - Phase 04",
            },
        ]
    )

    for (source, module), record in sorted(unresolved.items()):
        issues.append(
            {
                "id": f"P00-IMPORT-{len(issues) + 1:03d}",
                "severity": "known" if record.approved_gap else "blocking",
                "stage": "imports/contracts",
                "owner": "runtime contracts",
                "path": source,
                "line": record.line,
                "summary": f"Unresolved internal import: {module}. {record.reason}",
                "classification": _classify(source)[0],
                "target_phase": "Phase 02" if record.approved_gap else "Phase 00",
            }
        )
    return issues


def _counts(items: Iterable[str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return dict(sorted(counts.items()))


def run_audit(output_path: Path) -> tuple[dict[str, Any], int]:
    if str(PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(PROJECT_ROOT))

    inventory = build_inventory()
    import_records, dependency_edges = audit_internal_imports(inventory)

    active_syntax_failures = [
        asdict(item)
        for item in inventory
        if item.classification == "active" and item.syntax_status == "fail"
    ]
    unapproved_import_gaps = [
        asdict(item)
        for item in import_records
        if not item.resolved and not item.approved_gap
    ]
    approved_import_gaps = [
        asdict(item)
        for item in import_records
        if not item.resolved and item.approved_gap
    ]

    fake_checks: dict[str, Any]
    try:
        from tests.phase00.harness import run_fake_pipeline_checks

        fake_checks = run_fake_pipeline_checks()
    except Exception as exc:
        fake_checks = {
            "status": "fail",
            "error_type": type(exc).__name__,
            "error": str(exc),
        }

    gates = {
        "active_source_compiles": not active_syntax_failures,
        "no_unapproved_active_internal_import_gaps": not unapproved_import_gaps,
        "fake_request_reaches_decoded_image": fake_checks.get("status") == "pass",
        "intentional_failures_identify_stage": bool(fake_checks.get("all_failure_stages_identified")),
    }
    blocking_failures = [name for name, passed in gates.items() if not passed]

    report = {
        "schema": "image-gen-phase00-audit-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "phase": "Phase 00 - Baseline Audit and Reproducible Failure Capture",
        "project_root": str(PROJECT_ROOT),
        "canonical_pipeline": CANONICAL_PIPELINE,
        "classification_decisions": {
            "legacy": LEGACY_PATHS,
            "experimental": EXPERIMENTAL_PATHS,
            "sampler_advanced_decision": (
                "Archived experimental helper. It is valid Python but remains excluded from the active sampler registry."
            ),
        },
        "summary": {
            "status": "pass" if not blocking_failures else "fail",
            "blocking_failures": blocking_failures,
            "inventory_count": len(inventory),
            "classification_counts": _counts(item.classification for item in inventory),
            "python_syntax_counts": _counts(
                item.syntax_status for item in inventory if item.syntax_status is not None
            ),
            "active_syntax_failure_count": len(active_syntax_failures),
            "internal_import_count": len(import_records),
            "approved_internal_import_gap_count": len(approved_import_gaps),
            "unapproved_internal_import_gap_count": len(unapproved_import_gaps),
        },
        "gates": gates,
        "environment": build_environment_report(),
        "inventory": [asdict(item) for item in inventory],
        "syntax": {
            "active_failures": active_syntax_failures,
            "all_failures": [
                asdict(item) for item in inventory if item.syntax_status == "fail"
            ],
        },
        "imports": {
            "records": [asdict(item) for item in import_records],
            "approved_gaps": approved_import_gaps,
            "unapproved_gaps": unapproved_import_gaps,
        },
        "dependency_graph": {
            "format": "directed-import-edges",
            "edges": dependency_edges,
        },
        "fake_pipeline": fake_checks,
        "known_issues": build_known_issues(inventory, import_records),
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report, 0 if not blocking_failures else 1


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run syntax, internal-import, dependency, environment, and fake-pipeline Phase 00 checks."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help="JSON report path (default: artifacts/phase00_audit/phase00_audit_report.json)",
    )
    parser.add_argument(
        "--print-known-issues",
        action="store_true",
        help="Print the known-issue list after the summary.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output = args.output
    if not output.is_absolute():
        output = PROJECT_ROOT / output

    report, exit_code = run_audit(output.resolve())
    summary = report["summary"]
    gates = report["gates"]

    print("IMAGE_GEN - PHASE 00 BASELINE AUDIT")
    print(f"Project: {PROJECT_ROOT}")
    print(f"Report:  {output.resolve()}")
    print(f"Files:   {summary['inventory_count']}")
    print(f"Classes: {summary['classification_counts']}")
    for name, passed in gates.items():
        print(f"[{'PASS' if passed else 'FAIL'}] {name}")

    active_failures = report["syntax"]["active_failures"]
    if active_failures:
        print("\nBlocking active-source syntax failures:")
        for failure in active_failures:
            print(f"  {failure['path']} | {failure.get('syntax_error') or 'compile failure'}")

    import_failures = report["imports"]["unapproved_gaps"]
    if import_failures:
        print("\nBlocking unresolved internal imports:")
        for failure in import_failures:
            print(
                f"  {failure['source']}:{failure['line']} -> {failure['module']}"
                f" | {failure['reason']}"
            )

    approved_count = summary["approved_internal_import_gap_count"]
    if approved_count:
        print(f"[KNOWN] {approved_count} guarded internal import gap(s) retained for Phase 02.")

    if args.print_known_issues:
        outstanding = [
            issue for issue in report["known_issues"]
            if issue.get("severity") != "resolved"
        ]
        print("\nOutstanding known issues:")
        if not outstanding:
            print("  None")
        for issue in outstanding:
            print(
                f"  {issue['id']} | {issue['stage']} | {issue['path']}"
                f" | {issue['summary']}"
            )

    print(f"RESULT:  {summary['status'].upper()}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
