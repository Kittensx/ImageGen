from __future__ import annotations

from typing import Optional

try:
    from tqdm import tqdm
except Exception:
    tqdm = None


class ProgressReporter:
    def __init__(
        self,
        total: int = 0,
        *,
        enabled: bool = True,
        desc: str = "Sampling",
        unit: str = "step",
    ):
        self.total = int(total or 0)
        self.enabled = bool(enabled)
        self.desc = desc
        self.unit = unit
        self.current = 0
        self._bar = None

    def start(self, total: Optional[int] = None, desc: Optional[str] = None):
        if total is not None:
            self.total = int(total)
        if desc is not None:
            self.desc = desc

        if not self.enabled:
            return self

        if tqdm is not None:
            self._bar = tqdm(total=self.total, desc=self.desc, unit=self.unit)
        else:
            print(f"{self.desc}: 0/{self.total}")
        return self

    def update(self, n: int = 1):
        self.current += int(n)
        if not self.enabled:
            return

        if self._bar is not None:
            self._bar.update(n)
        else:
            print(f"\r{self.desc}: {self.current}/{self.total}", end="", flush=True)

    def set_total(self, total: int):
        self.total = int(total)
        if self._bar is not None:
            self._bar.total = self.total
            self._bar.refresh()

    def close(self):
        if self._bar is not None:
            self._bar.close()
            self._bar = None
        elif self.enabled and self.total:
            print()

    def __enter__(self):
        return self.start()

    def __exit__(self, exc_type, exc, tb):
        self.close()