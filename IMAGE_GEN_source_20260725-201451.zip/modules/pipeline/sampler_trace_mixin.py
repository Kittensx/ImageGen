# modules/pipeline/sampler_trace_mixin.py
from __future__ import annotations

from typing import Any, Optional
import torch


class SamplerTraceMixin:
    def _get_trace_recorder(self, request) -> Optional[Any]:
        sampler_kwargs = getattr(request, "sampler_kwargs", {}) or {}
        return sampler_kwargs.get("trace_recorder")

    def _trace_step(
        self,
        request,
        *,
        step_index: int,
        sigma=None,
        sigma_next=None,
        latent_before=None,
        latent_after=None,
        noise_pred=None,
        guided_noise=None,
        cfg_scale=None,
        stopping_candidate=None,
        extra=None,
        latent_snapshot=None,
        predicted_x0_snapshot=None,
    ) -> None:
        recorder = self._get_trace_recorder(request)
        if recorder is None or not getattr(recorder, "enabled", False):
            return

        recorder.record_step(
            step_index=step_index,
            sigma=sigma,
            sigma_next=sigma_next,
            latent_before=latent_before,
            latent_after=latent_after,
            noise_pred=noise_pred,
            guided_noise=guided_noise,
            cfg_scale=cfg_scale,
            stopping_candidate=stopping_candidate,
            extra=extra,
            latent_snapshot=latent_snapshot,
            predicted_x0_snapshot=predicted_x0_snapshot,
        )

    def _trace_sampler_summary(
        self,
        request,
        *,
        requested_steps=None,
        effective_steps=None,
        stopping_index=None,
    ) -> None:
        recorder = self._get_trace_recorder(request)
        if recorder is None or not getattr(recorder, "enabled", False):
            return

        recorder.set_runtime_summary(
            requested_steps=requested_steps,
            effective_steps=effective_steps,
            stopping_index=stopping_index,
        )
        
    def _resolve_effective_steps(
        self,
        request: Any,
        schedule: Any,
        sigmas: torch.Tensor,
    ) -> tuple[int, int]:
        """
        Prefer scheduler-reported step counts when available.
        Fall back to request.steps and len(sigmas) - 1 otherwise.
        """
        schedule_extra = getattr(schedule, "extra", None)

        requested_steps = getattr(request, "steps", None)
        effective_steps = int(sigmas.numel() - 1)

        if isinstance(schedule_extra, dict):
            sched_requested = schedule_extra.get("requested_steps", None)
            sched_effective = schedule_extra.get("effective_steps", None)

            if sched_requested is not None:
                try:
                    requested_steps = int(sched_requested)
                except (TypeError, ValueError):
                    pass

            if sched_effective is not None:
                try:
                    effective_steps = int(sched_effective)
                except (TypeError, ValueError):
                    pass

        if requested_steps is None:
            requested_steps = int(sigmas.numel() - 1)
        else:
            requested_steps = int(requested_steps)

        return requested_steps, effective_steps
        
    def _materialize_sigmas(
        self,
        schedule: Any,
        reference_tensor: torch.Tensor,
    ) -> torch.Tensor:
        sigmas = getattr(schedule, "sigmas", None)
        if sigmas is None:
            raise ValueError("schedule must provide `sigmas`.")

        if callable(sigmas):
            sigmas = sigmas()

        if not torch.is_tensor(sigmas):
            sigmas = torch.tensor(
                sigmas,
                dtype=reference_tensor.dtype,
                device=reference_tensor.device,
            )
        else:
            sigmas = sigmas.to(
                device=reference_tensor.device,
                dtype=reference_tensor.dtype,
            )

        return sigmas.flatten()
    def _materialize_timesteps(
        self,
        schedule: Any,
        reference_tensor: torch.Tensor,
    ) -> torch.Tensor:
        timesteps = getattr(schedule, "timesteps", None)
        if timesteps is None:
            raise ValueError("schedule must provide `timesteps`.")

        if callable(timesteps):
            timesteps = timesteps()

        if not torch.is_tensor(timesteps):
            timesteps = torch.tensor(
                timesteps,
                dtype=torch.float32,
                device=reference_tensor.device,
            )
        else:
            timesteps = timesteps.to(
                device=reference_tensor.device,
                dtype=torch.float32,
            )

        timesteps = timesteps.flatten()
        transition_count = int(self._materialize_sigmas(schedule, reference_tensor).numel() - 1)
        valid_lengths = {transition_count, transition_count + 1}
        if int(timesteps.numel()) not in valid_lengths:
            raise ValueError(
                "schedule.timesteps must provide one value per transition or one per sigma."
            )
        return timesteps

