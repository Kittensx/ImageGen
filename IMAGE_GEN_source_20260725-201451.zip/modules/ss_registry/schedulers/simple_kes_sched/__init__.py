from __future__ import annotations

import os

from modules.ss_registry.schedulers.simple_kes_sched.simple_kes import SimpleKEScheduler, SCHEDULER_CLASS
from modules.ss_registry.schedulers.simple_kes_sched.kes_scheduler_adapter import SimpleKESSchedulerAdapter, SCHEDULER_ADAPTER_CLASS

PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))

config_root = os.path.join(PACKAGE_DIR, "kes_config")
default_config = os.path.join(config_root, "default_config.yaml")
user_config = os.path.join(config_root, "user_config.yaml")
presets_path = os.path.join(config_root, "presets")

inferred_settings_yaml = os.path.join(config_root, "inferred_scheduler_settings.yaml")
inferred_settings_json = os.path.join(config_root, "inferred_scheduler_settings.json")

settings_file = default_config

ARG_SCHEMA_ORDER = ["type", "default", "short_desc", "long_desc", "choices", "range", "required"]

_REQUIRED_ARGS_RAW = {
    "steps": ["int", 25, "Number of denoising steps", "", None, [1, 150], True],
    "sigma_min": ["Optional[float]", 0.2, "Minimum sigma value", "", None, [0.0, 50.0], False],
    "sigma_max": ["Optional[float]", 50, "Maximum sigma value", "", None, [15, 60], False],
    "decay_mode": ["Optional[str]", "blend", "Tail behavior", "", ["blend", "append", "replace"], None, False],
    "decay_pattern": ["Optional[str]", "extrapolate", "Decay pattern", "", [None, "linear", "harmonic"], None, False],
    "rho": ["Optional[float]", 7, "Rho value for Karras noise schedule curvature", "Only applies to Karras schedules", None, [], False],
    "tail_steps": ["Optional[int]", 1, "Number of tail-end steps used for blending or decay control", "", None, [], False],
}


def _build_args(raw_args: dict[str, list]) -> dict[str, dict]:
    result: dict[str, dict] = {}
    for name, values in raw_args.items():
        if len(values) != len(ARG_SCHEMA_ORDER):
            continue
        entry = dict(zip(ARG_SCHEMA_ORDER, values))
        entry["name"] = name
        result[name] = entry
    return result


def _build_meta() -> dict:
    github_repo = "https://github.com/Kittensx/Simple_KES"
    author_link = {
        "author": "KittensX",
        "author links": {
            "civitai": "https://civitai.com/user/KittensX",
            "github": "https://github.com/Kittensx",
            "ko-fi": "https://ko-fi.com/kittensx",
        },
    }

    return {
        "name": "simple_kes",
        "label": "Simple Karras Exponential Scheduler",
        "summary_text": "Custom KES scheduler with scheduler blending.",
        "optional_links": {
            "github_repo": github_repo,
            "author": author_link,
        },
        "args": _build_args(_REQUIRED_ARGS_RAW),
        "config_file": {
            "yaml": inferred_settings_yaml,
            "json": inferred_settings_json,
        },
        "supports_pipeline_modes": ["fixed_steps", "compatible"],
        "supports_step_expansion": True,
        "supports_tail_steps": True,
        "supports_decay_tail": True,
        "supports_blended_tail": True,
        "supports_progressive_decay": True,
        "scheduler_family": "kes",
        "config_root": config_root,
        "default_config": default_config,
        "user_config": user_config,
        "presets_path": presets_path,
        "inferred_settings_yaml": inferred_settings_yaml,
        "inferred_settings_json": inferred_settings_json,
    }


meta = _build_meta()

PLUGIN_DESCRIPTOR = {
    "plugin_id": "scheduler.simple_kes",
    "kind": "scheduler",
    "name": "simple_kes",
    "label": "Simple Karras Exponential Scheduler",
    "description": meta["summary_text"],
    "version": "1",
    "module": __name__,
    "adapter_class": "SimpleKESSchedulerAdapter",
    "aliases": ["simple kes", "karras exponential", "kes scheduler"],
    "capabilities": {
        "pipeline_modes": ["fixed_steps", "extended_steps", "compatible"],
        "supports_fixed_steps": True,
        "supports_step_expansion": True,
        "supports_tail_metadata": True,
        "supports_tail_steps": True,
        "supports_decay_tail": True,
        "supports_blended_tail": True,
        "supports_progressive_decay": True,
        "scheduler_family": "kes",
    },
    "config_schema": {
        "type": "object",
        "properties": dict(meta["args"]),
        "required": [
            name for name, spec in meta["args"].items() if spec.get("required")
        ],
        "additionalProperties": True,
    },
}

__all__ = [
    "SimpleKEScheduler",
    "SimpleKESSchedulerAdapter",
    "SCHEDULER_CLASS",
    "SCHEDULER_ADAPTER_CLASS",
    "meta",
    "config_root",
    "default_config",
    "user_config",
    "presets_path",
    "settings_file",
    "PLUGIN_DESCRIPTOR",
]