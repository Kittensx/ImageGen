# kes_sampler.py

from __future__ import annotations

import math
from typing import Any, Dict, Optional

import torch

from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.cfg_strategy import CFGStrategy
from modules.sampler_state import SamplerState
from modules.ss_registry.samplers.sampler_config_loader import prepare_sampler_config

from modules.pipeline.conditioning_utils import resolve_step_conditioning
from modules.pipeline.sampler_trace_mixin import SamplerTraceMixin
from modules.txt2img.seed_utils import create_torch_generator, offset_seed

from modules.contracts import SamplerCapabilities, SamplerOutput


class KESSampler(SamplerTraceMixin):
    """
    Pipeline-facing sampler adapter.

    Expected call shape:
        sample(
            raw_model_fn,
            latents,
            schedule,
            conditioning,
            request,
            state=None,
        ) -> SamplerOutput

    Notes:
    - Consumes request/schedule/conditioning/state as inputs.
    - Returns final latents.
    - Returns only sampler-owned metadata in `extra`.
    """

    SAMPLER_NAME = "kes_sampler"
    SAMPLER_CAPABILITIES = SamplerCapabilities(
        sampler_name=SAMPLER_NAME,
        guidance_owner="sampler",
        uses_raw_model_fn=True,
        uses_guided_model_fn=False,
        supports_step_expansion=True,
        supports_tail_metadata=True,
        requires_requested_step_schedule=False,
        strict_validation=True,
        forced_pipeline_mode="extended_steps",
    )
    SAMPLER_SCHEDULE_CAPABILITIES = SAMPLER_CAPABILITIES

    def __init__(
        self,
        config_path: Optional[str] = None,
        preset_name: Optional[str] = None,
        sampler_state: Optional[SamplerState] = None,
        verbose: bool = False,
        **overrides: Any,
    ) -> None:
        self.verbose = verbose
        self.sampler_state = sampler_state or SamplerState()
        self._ensure_state_shape(self.sampler_state)

        self.settings = prepare_sampler_config(
            sampler_name="kes",
            sampler_state=self.sampler_state,
            config_path=config_path,
            preset_name=preset_name,
            overrides=overrides,
        )

    def _materialize_sigmas(self, schedule, latents: torch.Tensor) -> torch.Tensor:
        return super()._materialize_sigmas(schedule, latents)

    def _materialize_timesteps(
        self,
        schedule,
        sigmas: torch.Tensor,
        latents: torch.Tensor,
    ) -> torch.Tensor:
        del sigmas
        return super()._materialize_timesteps(schedule, latents)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sample(
        self,
        raw_model_fn,        
        latents: torch.Tensor,
        schedule,
        conditioning,
        request,
        state: Optional[Any] = None,
    ) -> SamplerOutput:
        """
        Args:
            model_fn:
                Callable used like:
                    model_fn(x, sigma, cond)
                and expected to return noise prediction.

            latents:
                Starting latent tensor.

            schedule:
                Object with `sigmas`.

            conditioning:
                Object with `cond` and `uncond`.

            request:
                Object with at least:
                    steps
                    cfg_scale
                and optionally:
                    batch_size
                    shape
                    width / height
                    seed
                    positive_prompt / negative_prompt

            state:
                Optional shared pipeline state.

        Returns:
            SamplerOutput(latents=..., extra={sampler metadata only})
        """
        progress = None
        if state is not None:
            progress = getattr(state, "extra", {}).get("progress_reporter")
    
        if latents is None:
            raise ValueError("KESSampler.sample requires `latents`.")

        sigmas = self._materialize_sigmas(schedule, latents)
        timesteps = self._materialize_timesteps(schedule, sigmas, latents)
        if sigmas.numel() < 2:
            raise ValueError("KESSampler.sample requires at least 2 sigma values.")

        requested_steps, effective_steps = self._resolve_effective_steps(
            request=request,
            schedule=schedule,
            sigmas=sigmas,
        )

        #
        x = latents
        cond = getattr(conditioning, "cond", None)
        uncond = getattr(conditioning, "uncond", None)

        if cond is None or uncond is None:
            raise ValueError("conditioning must provide both `cond` and `uncond`.")

        resolver = None
        conditioning_extra = getattr(conditioning, "extra", None)
        if isinstance(conditioning_extra, dict):
            resolver = conditioning_extra.get("resolver")

        cfg_scale = float(getattr(request, "cfg_scale", 1.0))
        image_seeds = list(getattr(request, "resolved_seeds", []) or [])
        if len(image_seeds) != int(x.shape[0]):
            base_seed = int(getattr(request, "seed", 0) or 0)
            image_seeds = [offset_seed(base_seed, index) for index in range(int(x.shape[0]))]
        noise_generators = [
            create_torch_generator(offset_seed(seed, 1), device=x.device)
            for seed in image_seeds
        ]

        def next_batch_noise(reference: torch.Tensor) -> torch.Tensor:
            return torch.cat(
                [
                    torch.randn(
                        (1, *reference.shape[1:]),
                        generator=generator,
                        device=reference.device,
                        dtype=reference.dtype,
                    )
                    for generator in noise_generators
                ],
                dim=0,
            )
        #

        # Sync runtime data with sampler_state.
        self._prepare_runtime_state(
            x=x,
            sigmas=sigmas,
            request=request,
            steps=effective_steps,
            cfg_scale=cfg_scale,
            shared_state=state,
        )

        # Create strategy only after runtime state is prepared.
        strategy = CFGStrategy(
            shared_state=state,
            sampler_state=self.sampler_state,
            verbose=self.verbose,
        )

        # Resolve effective settings actually used by the sampler.
        sampler_type = str(self._setting("sampler_type", "euler")).lower()
        eta = float(self._setting("eta", 0.0))
        add_noise = bool(self._setting("add_noise", eta > 0.0))
        initial_noise_strength = float(self._setting("initial_noise_strength", 0.0))
        rescale_cfg = bool(self._setting("rescale_cfg", False))
        rescale_cfg_factor = float(self._setting("rescale_cfg_factor", 1.0))
        noise_schedule_scaling = self._setting("noise_schedule_scaling", "none")
        eta_schedule_mode = self._setting("eta_schedule_mode", "none")
        use_adaptive_eta = bool(self._setting("use_adaptive_eta", False))
        clamp_range = self._normalize_clamp_range(self._setting("clamp_range", [-1.0, 1.0]))

        # Track what actually happened.
        metadata: Dict[str, Any] = {
            "sampler_name": self.SAMPLER_NAME,
            "sampler_type_used": sampler_type,
            "sigma_transitions": int(sigmas.numel() - 1),
            "requested_steps": requested_steps,
            "effective_steps": effective_steps,
            "scheduler_step_override_applied": effective_steps != requested_steps,
            "stepwise_conditioning_used": resolver is not None,
            "model_prediction_type": "epsilon",
            "integration_prediction_type": "epsilon_to_denoised",
        }

        schedule_extra = getattr(schedule, "extra", None)
        if isinstance(schedule_extra, dict):
            metadata["schedule_extra"] = dict(schedule_extra)
            capability_clamp = dict(schedule_extra.get("sampler_capability_clamp") or {})
            clamp_active = bool(capability_clamp.get("active", False))
            metadata["sampler_capability_clamp"] = capability_clamp
            metadata["step_expansion_clamped"] = bool(
                capability_clamp.get("step_expansion_clamped", False)
            )
            metadata["tail_metadata_clamped"] = bool(
                capability_clamp.get("tail_metadata_clamped", False)
            )
            if clamp_active:
                if effective_steps != requested_steps or int(sigmas.numel() - 1) != requested_steps:
                    raise ValueError(
                        "KES fixed-step compatibility clamp requires exactly the requested "
                        "number of sigma transitions."
                    )
                metadata["compatibility_mode_used"] = "fixed_steps_clamped"
            else:
                metadata["compatibility_mode_used"] = str(
                    schedule_extra.get("compatibility_mode") or "native"
                )
            if "schedule_mode" in schedule_extra:
                metadata["schedule_mode"] = schedule_extra["schedule_mode"]
                metadata["schedule_mode_used"] = schedule_extra["schedule_mode"]

            if "requested_steps" in schedule_extra:
                metadata["scheduler_reported_requested_steps"] = schedule_extra["requested_steps"]

            if "effective_steps" in schedule_extra:
                metadata["scheduler_reported_effective_steps"] = schedule_extra["effective_steps"]

            if "scheduler_step_override_applied" in schedule_extra:
                metadata["scheduler_step_override_applied"] = bool(
                    schedule_extra["scheduler_step_override_applied"]
                )

            if "tail_features_used" in schedule_extra:
                metadata["tail_features_used"] = schedule_extra["tail_features_used"]

            if "active_blend_methods" in schedule_extra:
                metadata["active_blend_methods"] = schedule_extra["active_blend_methods"]

            if "active_blend_weights" in schedule_extra:
                metadata["active_blend_weights"] = schedule_extra["active_blend_weights"]

            if "prepass_used" in schedule_extra:
                metadata["scheduler_prepass_used"] = bool(schedule_extra["prepass_used"])

            if "predicted_stop_step" in schedule_extra:
                metadata["scheduler_predicted_stop_step"] = schedule_extra["predicted_stop_step"]

            if "compatibility_mode" in schedule_extra:
                metadata["scheduler_compatibility_mode"] = schedule_extra["compatibility_mode"]

        # Initial noise injection.
        if initial_noise_strength > 0.0:
            x = x + next_batch_noise(x) * initial_noise_strength
            metadata["initial_noise_applied"] = True
            metadata["initial_noise_strength_used"] = initial_noise_strength
        else:
            metadata["initial_noise_applied"] = False

        # Main sampling loop.
        stochastic_noise_applied = False
        cfg_rescale_applied = False
        heun_used = False
        
        for i in range(sigmas.numel() - 1):
            sigma = sigmas[i]
            sigma_next = sigmas[i + 1]
            timestep = timesteps[i]
            timestep_next = timesteps[i + 1]
            
            latent_before = x.detach()

            cond, uncond = resolve_step_conditioning(
                conditioning=conditioning,
                step_index=i,
                latents=x,
                state=state,
            )

            noise_uncond = raw_model_fn(x, sigma, timestep, uncond)
            noise_cond = raw_model_fn(x, sigma, timestep, cond)

            
            if rescale_cfg:
                noise = strategy.apply_cfg_rescale(noise_uncond, noise_cond)
                cfg_rescale_applied = True
            else:
                noise = noise_uncond + cfg_scale * (noise_cond - noise_uncond)

            denoised = x - sigma * noise
            dt = sigma_next - sigma

            if sampler_type == "heun" and i < (sigmas.numel() - 2):
                # Predictor
                x_pred = denoised + (sigma_next * noise)

                # Corrector uses conditioning for the next step when available
                cond_2, uncond_2 = resolve_step_conditioning(
                    conditioning=conditioning,
                    step_index=i + 1,
                    latents=x_pred,
                    state=state,
                )

                noise_uncond_2 = raw_model_fn(x_pred, sigma_next, timestep_next, uncond_2)
                noise_cond_2 = raw_model_fn(x_pred, sigma_next, timestep_next, cond_2)

                if rescale_cfg:
                    noise_2 = strategy.apply_cfg_rescale(noise_uncond_2, noise_cond_2)
                else:
                    noise_2 = noise_uncond_2 + cfg_scale * (noise_cond_2 - noise_uncond_2)

                x = x + 0.5 * (noise + noise_2) * dt
                heun_used = True
            else:
                # Euler
                x = denoised + sigma_next * noise

            if use_adaptive_eta:
                gamma = strategy.get_eta_noise_gamma_adaptive(
                    step=i,
                    sigma=sigma,
                    sigma_next=sigma_next,
                    total_steps=effective_steps,
                    x=x,
                    denoised=denoised,
                )
            else:
                gamma = strategy.get_eta_noise_gamma(
                    step=i,
                    sigma=sigma,
                    sigma_next=sigma_next,
                    total_steps=effective_steps,
                    mode=noise_schedule_scaling,
                )

            if add_noise and gamma > 0:
                stochastic_noise = next_batch_noise(x)
                x = x + stochastic_noise * gamma
                stochastic_noise_applied = True

            # Optional clamp after update if CFG rescale is enabled.
            if rescale_cfg:
                x = torch.clamp(x, clamp_range[0], clamp_range[1])
            
            # Traceback
            self._trace_step(
                request,
                step_index=i,
                sigma=sigma,
                sigma_next=sigma_next,
                latent_before=latent_before,
                latent_after=x,
                noise_pred=noise_cond,
                guided_noise=noise,
                cfg_scale=cfg_scale,
                extra={
                    "sampler_name": self.SAMPLER_NAME,
                    "integration_mode": "heun" if (sampler_type == "heun" and i < (sigmas.numel() - 2)) else "euler",
                    "used_resolver": resolver is not None,
                    "rescale_cfg": rescale_cfg,
                    "cfg_rescale_applied": cfg_rescale_applied,
                    "add_noise": add_noise,
                    "gamma": float(gamma) if gamma is not None else None,
                    "used_stochastic_noise": bool(add_noise and gamma > 0),
                },
            )
            if progress is not None:
                progress.update(1)
            # Keep state fresh for downstream tools/debugging.
            self._update_tensor_state(x=x, sigma=sigma, denoised=denoised)

        metadata["cfg_rescale_applied"] = cfg_rescale_applied
        if cfg_rescale_applied:
            metadata["cfg_rescale_factor_used"] = rescale_cfg_factor
            metadata["clamp_applied"] = True
            metadata["clamp_range_used"] = list(clamp_range)
        else:
            metadata["clamp_applied"] = False

        metadata["stochastic_noise_applied"] = stochastic_noise_applied
        metadata["gamma_strategy_used"] = "adaptive" if use_adaptive_eta else "standard"
        metadata["eta_schedule_mode_used"] = eta_schedule_mode

        if stochastic_noise_applied:
            metadata["eta_used"] = eta
            metadata["noise_schedule_scaling_used"] = noise_schedule_scaling

        if heun_used:
            metadata["integration_mode_used"] = "heun"
        else:
            metadata["integration_mode_used"] = "euler"

        stopping_index = None
        if isinstance(schedule_extra, dict):
            stopping_index = schedule_extra.get("predicted_stop_step")

        self._trace_sampler_summary(
            request,
            requested_steps=requested_steps,
            effective_steps=effective_steps,
            stopping_index=stopping_index,
        )
        

        return SamplerOutput(
            latents=x,
            extra=metadata,
            
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
            
    def _ensure_state_shape(self, sampler_state: SamplerState) -> None:
        """
        Smooth over naming drift while you refactor.
        Supports either:
          - sampler_state.tensor_data
          - sampler_state.sigdata
        """
        if hasattr(sampler_state, "tensor_data") and not hasattr(sampler_state, "sigdata"):
            sampler_state.sigdata = sampler_state.tensor_data

        if hasattr(sampler_state, "sigdata") and not hasattr(sampler_state, "tensor_data"):
            sampler_state.tensor_data = sampler_state.sigdata

    def _setting(self, key: str, default: Any = None) -> Any:
        """
        Read the effective sampler setting.
        Prefers sampler_state.cfg when present, then resolved settings dict.
        """
        cfg_obj = getattr(self.sampler_state, "cfg", None)
        if cfg_obj is not None and hasattr(cfg_obj, key):
            value = getattr(cfg_obj, key)
            if value is not None:
                return value
        return self.settings.get(key, default)

    

    def _prepare_runtime_state(
        self,
        x: torch.Tensor,
        sigmas: torch.Tensor,
        request: Any,
        steps: int,
        cfg_scale: float,
        shared_state: Optional[Any],
    ) -> None:
        ss = self.sampler_state

        gen = getattr(ss, "gen", None)
        if gen is not None:
            if hasattr(gen, "steps"):
                gen.steps = steps
            if hasattr(gen, "cfg_scale"):
                gen.cfg_scale = cfg_scale
            if hasattr(gen, "batch_size"):
                gen.batch_size = getattr(request, "batch_size", x.shape[0] if x.ndim > 0 else 1)
            if hasattr(gen, "shape"):
                gen.shape = getattr(request, "shape", tuple(x.shape))
            if hasattr(gen, "device"):
                gen.device = str(x.device)

        tensor_data = getattr(ss, "tensor_data", None)
        if tensor_data is not None:
            if hasattr(tensor_data, "sigmas"):
                tensor_data.sigmas = sigmas
            if hasattr(tensor_data, "sample"):
                tensor_data.sample = x
            if hasattr(tensor_data, "model"):
                tensor_data.model = None

        if shared_state is not None:
            setattr(ss, "shared_state", shared_state)

    def _update_tensor_state(
        self,
        x: torch.Tensor,
        sigma: torch.Tensor,
        denoised: torch.Tensor,
    ) -> None:
        tensor_data = getattr(self.sampler_state, "tensor_data", None)
        if tensor_data is None:
            return

        if hasattr(tensor_data, "sample"):
            tensor_data.sample = x
        if hasattr(tensor_data, "sigma"):
            tensor_data.sigma = sigma
        if hasattr(tensor_data, "denoised"):
            tensor_data.denoised = denoised

    def _normalize_clamp_range(self, value: Any) -> tuple[float, float]:
        if isinstance(value, (list, tuple)) and len(value) == 2:
            return float(value[0]), float(value[1])
        return -1.0, 1.0
        
SAMPLER_CLASS = KESSampler
