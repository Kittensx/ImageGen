from .simple_kes_sampler.kes_sampler import KESSampler, SAMPLER_CLASS
from .simple_kes_sampler.kes_sampler_adapter import KESSamplerAdapter, SAMPLER_ADAPTER_CLASS

required_args = {
    "raw_model_fn": "callable",
    "latents": "torch.Tensor",
    "schedule": "SchedulerOutput-like object with sigmas",
    "conditioning": "ConditioningOutput-like object with cond/uncond",
    "request": "request object with steps/cfg_scale",
}

optional_args = {
    "state": "shared pipeline state",
    "config_path": "optional sampler config path",
    "preset_name": "optional sampler preset name",
}

meta = {
    "name": "kes",
    "label": "KES Sampler",
    "description": "Pipeline-facing Euler/Heun sampler with config-driven CFG strategy support.",
    "config_key": "kes",
}

PLUGIN_DESCRIPTOR = {
    "plugin_id": "sampler.kes",
    "kind": "sampler",
    "name": "kes",
    "label": "KES Sampler",
    "description": meta["description"],
    "version": "1",
    "module": __name__,
    "adapter_class": "KESSamplerAdapter",
    "aliases": ["kes_sampler", "simple_kes_sampler"],
    "capabilities": KESSamplerAdapter.SAMPLER_CAPABILITIES.to_serializable_dict(),
    "config_schema": {
        "type": "object",
        "properties": {
            "config_path": {"type": ["string", "null"]},
            "preset_name": {"type": ["string", "null"]},
            "verbose": {"type": "boolean"},
        },
        "required": [],
        "additionalProperties": True,
    },
}

__all__ = [
    "KESSampler",
    "KESSamplerAdapter",
    "SAMPLER_CLASS",
    "SAMPLER_ADAPTER_CLASS",
    "meta",
    "required_args",
    "optional_args",
    "PLUGIN_DESCRIPTOR",
]