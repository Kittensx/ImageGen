# prompt_conditioning_adapter.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import torch

from modules.contracts import ConditioningOutput, PromptAdapterProtocol

PromptAdapter = PromptAdapterProtocol
from modules.parser.prompt_parser_class import (
    PromptParserClass,
    MulticondLearnedConditioning,
    ScheduledPromptConditioning,
)
from modules.adapters.local_clip_conditioning_wrapper import LocalCLIPConditioningWrapper

@dataclass
class StepConditioningResolver:
    positive_multicond: MulticondLearnedConditioning
    negative_multicond: MulticondLearnedConditioning
    total_steps: int

    def _select_schedule_cond(
        self,
        schedules: list[ScheduledPromptConditioning],
        step_index: int,
    ) -> torch.Tensor:
        """
        step_index is expected to be 0-based from the sampler loop.
        Prompt scheduling in your parser is effectively 1-based, so we convert here.
        """
        step_1_based = step_index + 1

        if not schedules:
            raise ValueError("No schedules found for conditioning item.")

        for sched in schedules:
            if step_1_based <= sched.end_at_step:
                return sched.cond

        return schedules[-1].cond

    def _resolve_multicond_for_step(
        self,
        multicond: MulticondLearnedConditioning,
        step_index: int,
    ) -> torch.Tensor:
        """
        Resolves the active conditioning tensor for a given step.

        Output shape:
          [batch, tokens, dim]  or whatever the underlying text encoder returns
        """
        batch_outputs = []

        for batch_items in multicond.batch:
            item_tensors = []
            item_weights = []

            for item in batch_items:
                schedules = item.schedules

                # Defensive unwrap for legacy nesting:
                # some existing code stores one ScheduledPromptConditioning whose
                # .cond is itself a list[ScheduledPromptConditioning].
                if (
                    len(schedules) == 1
                    and isinstance(schedules[0].cond, list)
                    and schedules[0].cond
                    and isinstance(schedules[0].cond[0], ScheduledPromptConditioning)
                ):
                    schedules = schedules[0].cond

                cond_tensor = self._select_schedule_cond(schedules, step_index)

                if not isinstance(cond_tensor, torch.Tensor):
                    raise TypeError(
                        f"Resolved conditioning must be a tensor, got {type(cond_tensor)}"
                    )

                item_tensors.append(cond_tensor)
                item_weights.append(float(getattr(item, "weight", 1.0)))

            if not item_tensors:
                raise ValueError("No composable conditioning tensors found for batch item.")

            if len(item_tensors) == 1:
                combined = item_tensors[0]
            else:
                weight_tensor = torch.tensor(
                    item_weights,
                    device=item_tensors[0].device,
                    dtype=item_tensors[0].dtype,
                )
                weight_sum = weight_tensor.sum().clamp(min=1e-8)
                weight_tensor = weight_tensor / weight_sum

                stacked = torch.stack(item_tensors, dim=0)
                view_shape = [len(item_tensors)] + [1] * (stacked.ndim - 1)
                combined = (stacked * weight_tensor.view(*view_shape)).sum(dim=0)

            batch_outputs.append(combined)

        return torch.stack(batch_outputs, dim=0)

    def resolve(self, step_index: int) -> tuple[torch.Tensor, torch.Tensor]:
        cond = self._resolve_multicond_for_step(self.positive_multicond, step_index)
        uncond = self._resolve_multicond_for_step(self.negative_multicond, step_index)
        return cond, uncond


class PromptConditioningAdapter(PromptAdapter):
    """
    Pipeline-facing adapter for:
      prompt text -> parsed schedules -> learned conditioning -> step resolver
    """

    def __init__(self, hires_steps: Optional[int] = None):
        self.hires_steps = hires_steps

    

    def _get_conditioning_model(self, components, state: Optional[Any]):
        text_encoder = getattr(components, "text_encoder", None)
        tokenizer = getattr(components, "tokenizer", None)


        if text_encoder is not None and tokenizer is not None:
            wrapper = LocalCLIPConditioningWrapper(
                text_encoder=text_encoder,
                tokenizer=tokenizer,
                device=next(text_encoder.parameters()).device,
            )
            return wrapper

        if text_encoder is not None and hasattr(text_encoder, "encode"):
            return text_encoder

        if state is not None:
            cfgm = getattr(state, "cfgm", None)
            if cfgm is not None and hasattr(cfgm, "model"):
                model = cfgm.model
                if hasattr(model, "get_learned_conditioning") or hasattr(model, "encode"):
                    return model

        raise AttributeError("Could not find or construct a conditioning model.")

    def _parse_prompt(
        self,
        *,
        state: Any,
        prompt: str,
        steps: int,
        hires_steps: Optional[int],
        model: Any,
    ):
        return PromptParserClass(
            shared_state=state,
            prompts=[prompt],
            steps=steps,
            model=model,
            hires_steps=hires_steps,
        )()

    def encode(
        self,
        components,
        request,
        state: Optional[Any] = None,
    ) -> ConditioningOutput:
        cond_model = self._get_conditioning_model(components, state)
        
        
        hires_steps = request.parser_kwargs.get("hires_steps", self.hires_steps)
        if state is not None and hasattr(state, "p"):
            state.p.steps = request.steps
            state.p.batch_size = request.batch_size
            state.p.cfg_scale = request.cfg_scale
            state.p.width = request.width
            state.p.height = request.height
            state.p.positive_prompt = request.positive_prompt
            state.p.negative_prompt = request.negative_prompt or ""
            if request.seed is not None:
                state.p.seed = request.seed
        pos_result = self._parse_prompt(
            state=state,
            prompt=request.positive_prompt,
            steps=request.steps,
            hires_steps=hires_steps,
            model=cond_model,
        )

        neg_result = self._parse_prompt(
            state=state,
            prompt=request.negative_prompt or "",
            steps=request.steps,
            hires_steps=hires_steps,
            model=cond_model,
        )

        resolver = StepConditioningResolver(
            positive_multicond=pos_result.multicond,
            negative_multicond=neg_result.multicond,
            total_steps=request.steps,
        )

        # Initial tensors for step 0 so the pipeline has direct cond/uncond fields.
        cond0, uncond0 = resolver.resolve(step_index=0)

        prompt_schedules = {
            "positive": pos_result.flat_list,
            "negative": neg_result.flat_list,
        }

        if state is not None and hasattr(state, "p"):
            state.p.cond = cond0
            state.p.uncond = uncond0
            state.p.prompt_schedules = prompt_schedules
            
       
            cond = state.p.cond
            uncond = state.p.uncond
            diff = (cond - uncond).abs().mean().item()
            
            
           
        
        return ConditioningOutput(
            cond=cond0,
            uncond=uncond0,
            prompt_schedules=prompt_schedules,
            pooled_cond=None,
            pooled_uncond=None,
            extra={
                "positive_parsed": pos_result,
                "negative_parsed": neg_result,
                "resolver": resolver,
            },
        )
