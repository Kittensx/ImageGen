from __future__ import annotations

from typing import Any

from modules.txt2img.generation_manifest import GenerationManifest


def manifest_to_request_kwargs(
    manifest: GenerationManifest,
    include_optional_for_rerun: bool = True,
    ui_model_path: str | None = None,
) -> dict[str, Any]:
    payload = manifest.to_rerun_payload(
        include_optional_for_rerun=include_optional_for_rerun
    )

    # Local fallback policy for base model:
    # prefer manifest requested model path if present,
    # otherwise fall back to UI-selected model.
    model_path = payload.get("model_path") or ""
    if not model_path and ui_model_path:
        payload["model_path"] = ui_model_path

    return payload


def apply_manifest_to_existing_request(
    request: Any,
    manifest: GenerationManifest,
    include_optional_for_rerun: bool = True,
) -> Any:
    payload = manifest.to_rerun_payload(
        include_optional_for_rerun=include_optional_for_rerun
    )

    for key, value in payload.items():
        if hasattr(request, key):
            setattr(request, key, value)

    return request