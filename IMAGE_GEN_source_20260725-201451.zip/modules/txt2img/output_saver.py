from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

import torch
from PIL import Image

from image_gen.systems.diagnostics.serialization import json_safe
from modules.txt2img.generation_manifest import GenerationManifest
from modules.txt2img.manifest_io import save_manifest_json, save_manifest_txt
from modules.txt2img.seed_utils import offset_seed


DEFAULT_FILENAME_PATTERN = "{index:05d}-{seed}"
_INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_LEADING_INDEX = re.compile(r"^(\d{5,})(?:[-_]|$)")
_TRAILING_INDEX = re.compile(r"(?:^|[-_])(\d{5,})$")


@dataclass
class SavedImageRecord:
    image_path: str
    txt_path: str | None = None
    json_path: str | None = None
    index: int | None = None
    seed: int | None = None


class GenerationOutputSaver:
    """Centralized save helper for txt2img outputs.

    ``prefix`` remains backward compatible with legacy callers. A plain value
    such as ``img`` produces ``img_0000001``. A value containing format fields
    is treated as a filename template. The default user-facing template is
    ``{index:05d}-{seed}``.

    Supported fields include: ``index``, ``seed``, ``datetime``, ``date``,
    ``time``, ``model``, ``model_name``, ``vae``, ``vae_name``, ``lora``,
    ``lora_names``, ``sampler``, ``scheduler``, ``width``, ``height``, and
    ``prefix``.
    """

    def __init__(
        self,
        output_dir: str | Path,
        prefix: str = DEFAULT_FILENAME_PATTERN,
        image_ext: str = ".png",
    ):
        self.output_dir = Path(output_dir)
        self.prefix = self._clean_prefix(prefix)
        self.image_ext = self._normalize_ext(image_ext)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _clean_prefix(prefix: str) -> str:
        value = str(prefix or DEFAULT_FILENAME_PATTERN).strip()
        return value or DEFAULT_FILENAME_PATTERN

    @staticmethod
    def _normalize_ext(image_ext: str) -> str:
        value = str(image_ext or ".png").strip().lower()
        if not value.startswith("."):
            value = f".{value}"
        return value

    @staticmethod
    def tensor_to_pil_images(images: torch.Tensor) -> list[Image.Image]:
        if images.ndim != 4:
            raise ValueError(f"Expected BCHW tensor, got shape {tuple(images.shape)}")

        batch = images.detach().float().cpu().clamp(0, 1)
        pil_images: list[Image.Image] = []
        for image in batch:
            image_hwc = image.permute(1, 2, 0)
            image_uint8 = (image_hwc * 255.0).round().to(torch.uint8).numpy()
            pil_images.append(Image.fromarray(image_uint8).convert("RGB"))
        return pil_images

    @staticmethod
    def _coerce_pil_images(images: torch.Tensor | Sequence[Image.Image]) -> list[Image.Image]:
        if torch.is_tensor(images):
            return GenerationOutputSaver.tensor_to_pil_images(images)

        output: list[Image.Image] = []
        for idx, image in enumerate(images):
            if not isinstance(image, Image.Image):
                raise TypeError(f"Item {idx} is not a PIL image: {type(image)}")
            output.append(image.convert("RGB"))
        return output

    @staticmethod
    def _safe_component(value: Any, fallback: str = "") -> str:
        text = str(value or fallback).strip()
        text = _INVALID_FILENAME_CHARS.sub("_", text)
        text = text.replace(".", "_")
        text = re.sub(r"\s+", "_", text)
        text = re.sub(r"_+", "_", text)
        return text.strip(" ._-")

    @staticmethod
    def _asset_label(asset: Any) -> str:
        if asset is None:
            return ""
        for name in (
            "resolved_display_name",
            "requested_display_name",
            "resolved_filename",
            "requested_filename",
            "resolved_path",
            "requested_path",
            "resolved_identifier",
            "requested_identifier",
        ):
            value = getattr(asset, name, "")
            if value:
                return Path(str(value)).stem
        return ""

    def _existing_indices(self) -> list[int]:
        found: set[int] = set()
        legacy_pattern = re.compile(
            rf"^{re.escape(self.prefix)}_(\d+)$"
        ) if "{" not in self.prefix else None

        for path in self.output_dir.glob(f"*{self.image_ext}"):
            stem = path.stem
            leading = _LEADING_INDEX.match(stem)
            if leading:
                found.add(int(leading.group(1)))
                continue
            trailing = _TRAILING_INDEX.search(stem)
            if trailing:
                found.add(int(trailing.group(1)))
                continue
            if legacy_pattern is not None:
                legacy = legacy_pattern.match(stem)
                if legacy:
                    found.add(int(legacy.group(1)))
        return sorted(found)

    def next_index(self) -> int:
        existing = self._existing_indices()
        if not existing:
            return 1
        return existing[-1] + 1

    @staticmethod
    def _manifest_copy(manifest: GenerationManifest) -> GenerationManifest:
        # Rehydrate from JSON-safe data rather than deepcopying runtime objects
        # such as mappingproxy, torch.device, or plugin descriptors.
        return GenerationManifest.from_dict(json_safe(manifest.to_dict()))

    @staticmethod
    def _resolve_image_seeds(
        manifest: GenerationManifest | None,
        image_count: int,
    ) -> list[int | None]:
        if manifest is None:
            return [None] * image_count

        raw = manifest.extra.get("resolved_seeds", [])
        if isinstance(raw, (list, tuple)) and len(raw) >= image_count:
            return [int(value) for value in raw[:image_count]]

        base_seed = int(manifest.required_for_rerun.seed)
        return [offset_seed(base_seed, index) for index in range(image_count)]

    def _template_values(
        self,
        *,
        index: int,
        seed: int | None,
        manifest: GenerationManifest | None,
        timestamp: datetime,
    ) -> dict[str, Any]:
        req = manifest.required_for_rerun if manifest is not None else None
        model_path = getattr(req, "model_path", "") if req is not None else ""
        model_name = Path(str(model_path)).stem if model_path else ""

        vae_name = self._asset_label(getattr(manifest, "vae", None)) if manifest else ""
        lora_names = []
        extra = dict(getattr(manifest, "extra", {}) or {}) if manifest is not None else {}
        if manifest is not None:
            lora_names = [
                self._asset_label(asset)
                for asset in getattr(manifest, "loras", [])
            ]
            lora_names = [name for name in lora_names if name]

        if not vae_name:
            vae_path = extra.get("vae_path") or extra.get("vae_name") or ""
            vae_name = Path(str(vae_path)).stem if vae_path else ""
        if not lora_names:
            raw_loras = extra.get("lora_paths") or extra.get("loras") or []
            if isinstance(raw_loras, str):
                raw_loras = [raw_loras]
            if isinstance(raw_loras, (list, tuple)):
                lora_names = [Path(str(value)).stem for value in raw_loras if value]

        legacy_prefix = self.prefix if "{" not in self.prefix else "img"
        values = {
            "index": int(index),
            "seed": "unknown" if seed is None else int(seed),
            "datetime": timestamp.strftime("%Y%m%d-%H%M%S-%f"),
            "date": timestamp.strftime("%Y%m%d"),
            "time": timestamp.strftime("%H%M%S-%f"),
            "model": self._safe_component(model_name, "model"),
            "model_name": self._safe_component(model_name, "model"),
            "vae": self._safe_component(vae_name, "vae"),
            "vae_name": self._safe_component(vae_name, "vae"),
            "lora": self._safe_component("+".join(lora_names), "no_lora"),
            "lora_names": self._safe_component("+".join(lora_names), "no_lora"),
            "sampler": self._safe_component(getattr(req, "sampler_name", ""), "sampler") if req else "sampler",
            "scheduler": self._safe_component(getattr(req, "scheduler_name", ""), "scheduler") if req else "scheduler",
            "width": int(getattr(req, "width", 0) or 0) if req else 0,
            "height": int(getattr(req, "height", 0) or 0) if req else 0,
            "prefix": self._safe_component(legacy_prefix, "img"),
            "prompt": self._safe_component(getattr(req, "prompt", ""), "prompt") if req else "prompt",
            "negative_prompt": self._safe_component(getattr(req, "negative_prompt", ""), "") if req else "",
            "steps": int(getattr(req, "steps", 0) or 0) if req else 0,
            "cfg_scale": getattr(req, "cfg_scale", 0) if req else 0,
        }
        for key, value in extra.items():
            if key in values or not str(key).isidentifier():
                continue
            if isinstance(value, (str, int, float, bool)):
                values[key] = self._safe_component(value) if isinstance(value, str) else value
            elif isinstance(value, (list, tuple)) and all(
                isinstance(item, (str, int, float, bool)) for item in value
            ):
                values[key] = self._safe_component("+".join(str(item) for item in value))
        return values

    def build_base_path(
        self,
        index: int,
        *,
        seed: int | None = None,
        manifest: GenerationManifest | None = None,
        timestamp: datetime | None = None,
    ) -> Path:
        timestamp = timestamp or datetime.now()
        if "{" in self.prefix:
            values = self._template_values(
                index=index,
                seed=seed,
                manifest=manifest,
                timestamp=timestamp,
            )
            try:
                filename = self.prefix.format_map(values)
            except (KeyError, ValueError) as exc:
                raise ValueError(
                    f"Invalid output filename pattern {self.prefix!r}: {exc}"
                ) from exc
        else:
            filename = f"{self.prefix}_{index:07d}"

        filename = self._safe_component(filename, f"{index:05d}-{seed}")
        if not filename:
            filename = f"{index:05d}-{seed}"
        return self.output_dir / filename

    def _avoid_collision(self, base_path: Path) -> Path:
        candidate = base_path
        suffix = 1
        while any(
            candidate.with_suffix(ext).exists()
            for ext in (self.image_ext, ".txt", ".json")
        ):
            candidate = base_path.with_name(f"{base_path.name}-{suffix:02d}")
            suffix += 1
        return candidate

    def save_batch(
        self,
        images: torch.Tensor | Sequence[Image.Image],
        manifest: GenerationManifest | None = None,
        save_txt: bool = True,
        save_json: bool = True,
        image_kwargs: dict[str, Any] | None = None,
    ) -> list[SavedImageRecord]:
        pil_images = self._coerce_pil_images(images)
        image_kwargs = dict(image_kwargs or {})
        seeds = self._resolve_image_seeds(manifest, len(pil_images))

        records: list[SavedImageRecord] = []
        next_idx = self.next_index()

        for image_offset, image in enumerate(pil_images):
            image_seed = seeds[image_offset]
            image_manifest = self._manifest_copy(manifest) if manifest is not None else None
            if image_manifest is not None and image_seed is not None:
                image_manifest.required_for_rerun.seed = int(image_seed)
                batch_seeds = list(image_manifest.extra.get("resolved_seeds", []) or [])
                image_manifest.extra["batch_resolved_seeds"] = batch_seeds
                image_manifest.extra["resolved_seeds"] = [int(image_seed)]
                image_manifest.extra["image_seed"] = int(image_seed)

            base_path = self._avoid_collision(
                self.build_base_path(
                    next_idx,
                    seed=image_seed,
                    manifest=image_manifest,
                )
            )
            image_path = base_path.with_suffix(self.image_ext)
            txt_path = base_path.with_suffix(".txt") if image_manifest is not None and save_txt else None
            json_path = base_path.with_suffix(".json") if image_manifest is not None and save_json else None

            image.save(image_path, **image_kwargs)

            if image_manifest is not None:
                image_manifest.update_runtime_paths(
                    image_path=str(image_path),
                    txt_path=None if txt_path is None else str(txt_path),
                    json_path=None if json_path is None else str(json_path),
                )
                # Both sidecars receive complete, self-consistent paths.
                if txt_path is not None:
                    save_manifest_txt(image_manifest, txt_path)
                if json_path is not None:
                    save_manifest_json(image_manifest, json_path)

            records.append(
                SavedImageRecord(
                    image_path=str(image_path),
                    txt_path=None if txt_path is None else str(txt_path),
                    json_path=None if json_path is None else str(json_path),
                    index=next_idx,
                    seed=image_seed,
                )
            )
            next_idx += 1

        return records


def save_generation_batch(
    images: torch.Tensor | Sequence[Image.Image],
    output_dir: str | Path,
    prefix: str = DEFAULT_FILENAME_PATTERN,
    manifest: GenerationManifest | None = None,
    save_txt: bool = True,
    save_json: bool = True,
    image_ext: str = ".png",
    image_kwargs: dict[str, Any] | None = None,
) -> list[SavedImageRecord]:
    saver = GenerationOutputSaver(
        output_dir=output_dir,
        prefix=prefix,
        image_ext=image_ext,
    )
    return saver.save_batch(
        images=images,
        manifest=manifest,
        save_txt=save_txt,
        save_json=save_json,
        image_kwargs=image_kwargs,
    )
