from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any, Sequence

from modules.project_context import (
    ProjectConfigurationError,
    ProjectContext,
    ProjectValidationError,
)


def _parse_json_dict(value: str | None) -> dict[str, Any]:
    if not value:
        return {}
    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise argparse.ArgumentTypeError("Expected a JSON object.")
    return parsed


def _add_context_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--project-root",
        help="Override the IMAGE_GEN project root. Defaults to the package location.",
    )
    parser.add_argument(
        "--project-config",
        help=(
            "Override the canonical project config. Relative paths are resolved "
            "from --project-root."
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="IMAGE_GEN txt2img runtime")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Run a txt2img generation")
    _add_context_arguments(run_parser)
    run_parser.add_argument("--config", dest="config_path", help="Generation request YAML/JSON")
    run_parser.add_argument("--manifest", dest="manifest_path")
    run_parser.add_argument("--infotext", dest="infotext_path")

    run_parser.add_argument("--prompt", dest="positive_prompt")
    run_parser.add_argument("--negative-prompt", dest="negative_prompt")
    run_parser.add_argument("--steps", type=int)
    run_parser.add_argument("--cfg-scale", type=float)
    run_parser.add_argument("--seed", type=int)
    run_parser.add_argument("--width", type=int)
    run_parser.add_argument("--height", type=int)
    run_parser.add_argument("--batch-size", type=int)
    run_parser.add_argument("--batch-count", type=int)
    run_parser.add_argument(
        "--unlimited",
        action="store_true",
        default=None,
        help="Repeat batches until Ctrl+C. Random seed mode chooses a new base seed per batch.",
    )
    run_parser.add_argument("--model", dest="model_path")
    run_parser.add_argument("--sampler", dest="sampler_name")
    run_parser.add_argument("--scheduler", dest="scheduler_name")
    run_parser.add_argument("--output-dir")
    run_parser.add_argument(
        "--prefix",
        "--filename-pattern",
        dest="output_prefix",
        help=(
            "Output filename prefix or template. Example: "
            "{index:05d}-{seed}-{model}-{lora}"
        ),
    )
    run_parser.add_argument("--scheduler-kwargs", type=_parse_json_dict)
    run_parser.add_argument("--sampler-kwargs", type=_parse_json_dict)
    run_parser.add_argument("--parser-kwargs", type=_parse_json_dict)
    run_parser.add_argument("--interactive", action="store_true")
    save_group = run_parser.add_mutually_exclusive_group()
    save_group.add_argument(
        "--save",
        dest="save_images",
        action="store_true",
        help="Persist generated images and metadata sidecars.",
    )
    save_group.add_argument(
        "--no-save",
        dest="save_images",
        action="store_false",
        help="Keep generated images in memory only.",
    )
    run_parser.set_defaults(save_images=None)
    run_parser.add_argument("--no-txt", action="store_true")
    run_parser.add_argument("--no-json", action="store_true")

    run_parser.add_argument(
        "--diagnostics",
        dest="diagnostic_verbosity",
        choices=("quiet", "normal", "verbose", "trace"),
        help="Set structured diagnostic console verbosity for this run.",
    )
    run_parser.add_argument(
        "--diagnostics-dir",
        help="Override the diagnostic artifact root for this run.",
    )
    run_parser.add_argument(
        "--export-diagnostic-events",
        action="store_true",
        help="Write successful-run events and timing summary under artifacts.",
    )
    run_parser.add_argument(
        "--tensor-summaries",
        action="store_true",
        help="Record tensor shape, dtype, device, and element count.",
    )
    run_parser.add_argument(
        "--tensor-statistics",
        action="store_true",
        help="Also record finite min/max/mean/std/norm statistics.",
    )
    run_parser.add_argument(
        "--sampler-trace",
        action="store_true",
        help="Enable the optional per-step sampler trace under artifacts.",
    )
    run_parser.add_argument("--no-failure-bundle", action="store_true")
    run_parser.add_argument("--no-progress", action="store_true")

    config_parser = subparsers.add_parser(
        "config",
        help="Inspect or validate the canonical project configuration",
    )
    config_subparsers = config_parser.add_subparsers(dest="config_command", required=True)

    show_parser = config_subparsers.add_parser("show", help="Print effective configuration")
    _add_context_arguments(show_parser)
    show_parser.add_argument("--json", action="store_true", dest="as_json")

    validate_parser = config_subparsers.add_parser(
        "validate",
        help="Validate configured model, tokenizer, output, and support paths",
    )
    _add_context_arguments(validate_parser)
    validate_parser.add_argument("--model", dest="model_path")
    validate_parser.add_argument("--output-dir")
    validate_parser.add_argument("--no-output", action="store_true")
    validate_parser.add_argument("--json", action="store_true", dest="as_json")

    return parser


def build_cli_overrides(args: argparse.Namespace) -> dict[str, Any]:
    diagnostic_overrides: dict[str, Any] = {}
    if getattr(args, "diagnostic_verbosity", None):
        diagnostic_overrides["verbosity"] = args.diagnostic_verbosity
    if getattr(args, "diagnostics_dir", None):
        diagnostic_overrides["artifacts_root"] = args.diagnostics_dir
    if getattr(args, "export_diagnostic_events", False):
        diagnostic_overrides["export_events"] = True
    if getattr(args, "tensor_summaries", False) or getattr(args, "tensor_statistics", False):
        diagnostic_overrides["tensor_summaries"] = True
    if getattr(args, "tensor_statistics", False):
        diagnostic_overrides["tensor_statistics"] = True
    if getattr(args, "sampler_trace", False):
        diagnostic_overrides["sampler_trace"] = {"enabled": True}
    if getattr(args, "no_failure_bundle", False):
        diagnostic_overrides["failure_bundles"] = False
    if getattr(args, "no_progress", False):
        diagnostic_overrides["progress"] = False

    overrides = {
        "positive_prompt": args.positive_prompt,
        "negative_prompt": args.negative_prompt,
        "steps": args.steps,
        "cfg_scale": args.cfg_scale,
        "seed": args.seed,
        "width": args.width,
        "height": args.height,
        "batch_size": args.batch_size,
        "batch_count": args.batch_count,
        "unlimited": args.unlimited,
        "model_path": args.model_path,
        "sampler_name": args.sampler_name,
        "scheduler_name": args.scheduler_name,
        "output_dir": args.output_dir,
        "output_prefix": args.output_prefix,
        "scheduler_kwargs": args.scheduler_kwargs,
        "sampler_kwargs": args.sampler_kwargs,
        "parser_kwargs": args.parser_kwargs,
        "diagnostics": diagnostic_overrides or None,
        "save_images": args.save_images,
    }
    return {key: value for key, value in overrides.items() if value is not None}


def _merge_interactive_overrides(
    base: dict[str, Any],
    interactive: dict[str, Any],
) -> dict[str, Any]:
    """Merge interactive values while preserving an explicitly blank negative prompt.

    Most blank interactive fields mean "keep the configured default". The negative
    prompt is different: pressing Enter means the user intentionally requested no
    negative conditioning, so the empty string must override any configured default.
    """
    merged = dict(base or {})
    for key, value in dict(interactive or {}).items():
        if value is None:
            continue
        if value == "" and key != "negative_prompt":
            continue
        merged[key] = value
    return merged


def _build_prompt_adapter(*, request=None, extras=None, state=None):
    from modules.adapters.prompt_conditioning_adapter import PromptConditioningAdapter

    return PromptConditioningAdapter()


def _load_context(args: argparse.Namespace) -> ProjectContext:
    return ProjectContext.load(
        project_root=getattr(args, "project_root", None),
        config_path=getattr(args, "project_config", None),
    )


def _print_effective_config(context: ProjectContext) -> None:
    effective = context.effective_config()
    print("IMAGE_GEN canonical project configuration")
    print(f"Project root: {effective['project_root']}")
    print(f"Config file:  {effective['config_path']}")
    print("\nPaths:")
    for name, value in effective["paths"].items():
        print(f"  {name}: {value}")
    print("\nGeneration defaults:")
    for name, value in effective["generation"].items():
        print(f"  {name}: {value}")
    print("\nRuntime defaults:")
    for name, value in effective["defaults"].items():
        print(f"  {name}: {value}")


def _run_config_command(args: argparse.Namespace) -> int:
    context = _load_context(args)
    if args.config_command == "show":
        if args.as_json:
            print(context.effective_config_json())
        else:
            _print_effective_config(context)
        return 0

    if args.config_command == "validate":
        report = context.validate(
            for_generation=True,
            model_path=args.model_path,
            output_dir=args.output_dir,
            require_output=not args.no_output,
        )
        if args.as_json:
            print(json.dumps(report.to_dict(), indent=2))
        else:
            print(report.format_text())
        return 0 if report.is_valid else 2

    raise ValueError(f"Unsupported config command: {args.config_command}")


def _normalize_payload_paths(payload: dict[str, Any], context: ProjectContext) -> dict[str, Any]:
    normalized = dict(payload)
    for key in ("model_path", "vae_path", "output_dir"):
        value = normalized.get(key)
        if value is not None and str(value).strip():
            normalized[key] = str(context.resolve_project_path(str(value)))
    diagnostics = normalized.get("diagnostics")
    if isinstance(diagnostics, dict) and diagnostics.get("artifacts_root"):
        diagnostics = dict(diagnostics)
        diagnostics["artifacts_root"] = str(
            context.resolve_project_path(str(diagnostics["artifacts_root"]))
        )
        normalized["diagnostics"] = diagnostics
    lora_paths = normalized.get("lora_paths")
    if isinstance(lora_paths, list):
        normalized["lora_paths"] = [
            str(context.resolve_project_path(str(path))) for path in lora_paths
        ]
    return normalized


def _run_generation(args: argparse.Namespace) -> int:
    from modules.load_safetensors_model import LoadModel
    from image_gen.systems.registry import RuntimeRegistrySystem
    from modules.txt2img.cli_interactive import (
        build_interactive_overrides,
        choose_from_registry,
    )
    from modules.txt2img.model_selector import resolve_cli_model_path
    from modules.txt2img.request_loader import (
        load_request_payload,
        payload_to_generation_request,
    )
    from modules.txt2img.txt2img_runner import Txt2ImgRunner

    context = _load_context(args)
    cli_overrides = build_cli_overrides(args)

    # Build the descriptor registry once and share it with selection and runtime.
    registry_system = RuntimeRegistrySystem(project_context=context)
    live_sampler_map = registry_system.legacy_map("sampler")
    live_scheduler_map = registry_system.legacy_map("scheduler")

    if args.interactive:
        interactive_overrides = build_interactive_overrides()
        sampler_entry = choose_from_registry("Sampler", live_sampler_map)
        scheduler_entry = choose_from_registry("Scheduler", live_scheduler_map)
        interactive_overrides["sampler_name"] = (
            sampler_entry.get("name") or sampler_entry.get("label")
        )
        interactive_overrides["scheduler_name"] = (
            scheduler_entry.get("name") or scheduler_entry.get("label")
        )
        cli_overrides = _merge_interactive_overrides(
            cli_overrides,
            interactive_overrides,
        )

    resolved_model_path = resolve_cli_model_path(
        cli_overrides.get("model_path"),
        interactive=args.interactive,
        project_context=context,
    )
    if resolved_model_path:
        cli_overrides["model_path"] = resolved_model_path

    payload = load_request_payload(
        config_path=args.config_path,
        manifest_path=args.manifest_path,
        infotext_path=args.infotext_path,
        base_payload=context.generation_defaults(),
        cli_overrides=cli_overrides,
    )
    payload = _normalize_payload_paths(payload, context)
    request, payload_extras = payload_to_generation_request(payload)

    if request.save_images:
        output_path = Path(request.output_dir or context.txt2img_output_root).expanduser()
        if not output_path.is_absolute():
            output_path = context.resolve_project_path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)
        request.output_dir = str(output_path.resolve())

    context.require_generation_ready(
        model_path=payload_extras.get("model_path"),
        output_dir=request.output_dir,
        require_output=bool(request.save_images),
    )

    model_loader = LoadModel(project_context=context)
    runner = Txt2ImgRunner(
        prompt_adapter_factory=_build_prompt_adapter,
        model_loader=model_loader,
        project_context=context,
        registry_system=registry_system,
    )

    extras = {
        "live_sampler_map": live_sampler_map,
        "live_scheduler_map": live_scheduler_map,
    }
    extras.update(payload_extras)

    from modules.txt2img.seed_utils import iter_batch_base_seeds, offset_seed

    batch_count = int(extras.pop("batch_count", 1) or 1)
    unlimited = bool(extras.pop("unlimited", False))
    if batch_count < 1:
        raise ValueError("batch_count must be at least 1")
    if request.batch_size < 1:
        raise ValueError("batch_size must be at least 1")

    requested_seed = request.seed
    print(f"Requested seed: {requested_seed}")
    base_seed_iterator = iter_batch_base_seeds(
        requested_seed,
        batch_size=request.batch_size,
    )
    completed_batches = 0
    total_saved = 0

    try:
        while unlimited or completed_batches < batch_count:
            batch_number = completed_batches + 1
            batch_request = replace(
                request,
                seed=next(base_seed_iterator),
                resolved_seeds=[],
                scheduler_kwargs=dict(request.scheduler_kwargs),
                sampler_kwargs=dict(request.sampler_kwargs),
                parser_kwargs=dict(request.parser_kwargs),
                diagnostics=dict(request.diagnostics),
            )
            mode_label = "unlimited" if unlimited else f"{batch_number}/{batch_count}"
            print(f"\n=== Starting batch {mode_label} ===")

            batch_extras = dict(extras)
            batch_extras.update(
                {
                    "batch_number": batch_number,
                    "batch_count": batch_count,
                    "unlimited": unlimited,
                    "generation_mode": "unlimited" if unlimited else "batch_count",
                }
            )
            result = runner.run_request(
                batch_request,
                batch_extras,
                save_txt=not args.no_txt,
                save_json=not args.no_json,
            )

            saved_paths = [record.image_path for record in result.saved_records]
            if result.request.save_images and not saved_paths:
                raise RuntimeError(
                    "Generation completed, but image saving was requested and no image was persisted."
                )

            if requested_seed is not None and int(requested_seed) >= 0:
                expected_base_seed = offset_seed(
                    int(requested_seed), completed_batches * int(request.batch_size)
                )
                if int(result.request.seed) != expected_base_seed:
                    raise RuntimeError(
                        "Fixed seed changed unexpectedly: "
                        f"requested batch base {expected_base_seed}, "
                        f"runtime used {result.request.seed}."
                    )
                expected_image_seeds = [
                    offset_seed(expected_base_seed, index)
                    for index in range(int(request.batch_size))
                ]
                if list(result.request.resolved_seeds or []) != expected_image_seeds:
                    raise RuntimeError(
                        "Fixed per-image seed sequence changed unexpectedly: "
                        f"expected {expected_image_seeds}, "
                        f"runtime used {result.request.resolved_seeds}."
                    )

            completed_batches += 1
            total_saved += len(saved_paths)
            print("=== txt2img batch complete ===")
            print(f"Run ID: {result.run_id}")
            print(f"Prompt: {result.request.positive_prompt}")
            print(f"Batch base seed: {result.request.seed}")
            print(f"Image seeds: {result.request.resolved_seeds}")
            print(f"Sampler: {result.request.sampler_name}")
            print(f"Scheduler: {result.request.scheduler_name}")
            print(f"Generation time (sec): {result.generation_time_sec:.3f}")
            if saved_paths:
                print(f"Saved images: {len(saved_paths)}")
                print(f"Output directory: {Path(saved_paths[0]).parent}")
                for record in result.saved_records:
                    seed_label = "unknown" if record.seed is None else str(record.seed)
                    print(f"  Image [seed {seed_label}]: {record.image_path}")
                    if record.txt_path:
                        print(f"  TXT:   {record.txt_path}")
                    if record.json_path:
                        print(f"  JSON:  {record.json_path}")
            else:
                print("Saving disabled; generation remained in memory only.")
    except KeyboardInterrupt:
        if not unlimited:
            raise
        print(
            f"\nUnlimited generation stopped after {completed_batches} "
            f"completed batch(es) and {total_saved} saved image(s)."
        )
        return 0

    print(
        f"\nCompleted {completed_batches} batch(es), "
        f"{completed_batches * request.batch_size} generated image(s), "
        f"and {total_saved} saved image(s)."
    )
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "config":
            return _run_config_command(args)
        if args.command == "run":
            return _run_generation(args)
        parser.error(f"Unsupported command: {args.command}")
    except Exception as exc:
        from image_gen.systems.diagnostics import PipelineStageError

        if isinstance(exc, PipelineStageError):
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        if isinstance(exc, (ProjectConfigurationError, ProjectValidationError)):
            print(f"ERROR: {exc}", file=sys.stderr)
            return 2
        raise
    except KeyboardInterrupt:
        print("Cancelled.", file=sys.stderr)
        return 130

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
