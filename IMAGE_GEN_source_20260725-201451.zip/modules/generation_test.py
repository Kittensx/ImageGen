#!/usr/bin/env python3
"""Compatibility launcher for the explicit real-checkpoint smoke test.

This module used to contain an incomplete example with nonexistent adapter
classes and unresolved placeholder names. The supported generation path now
lives in ``modules.txt2img.cli`` and the documented checkpoint smoke test lives
in ``scripts/tests/run_test_tier.py``.

The wrapper is intentionally retained for anyone who previously invoked
``python modules/generation_test.py``. It does not run without an explicitly
supplied checkpoint.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
from typing import Sequence


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT_RUNNER = PROJECT_ROOT / "scripts" / "tests" / "run_test_tier.py"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the IMAGE_GEN real-checkpoint smoke test through the canonical CLI."
    )
    parser.add_argument(
        "--model",
        required=True,
        help="Path to a compatible Stable Diffusion checkpoint.",
    )
    parser.add_argument("--project-root")
    parser.add_argument("--steps", type=int, default=2)
    parser.add_argument("--width", type=int, default=64)
    parser.add_argument("--height", type=int, default=64)
    parser.add_argument(
        "--diagnostics",
        choices=("quiet", "normal", "verbose", "trace"),
        default="normal",
    )
    return parser


def build_command(args: argparse.Namespace) -> list[str]:
    command = [
        sys.executable,
        str(CHECKPOINT_RUNNER),
        "checkpoint",
        "--model",
        str(Path(args.model).expanduser()),
        "--steps",
        str(args.steps),
        "--width",
        str(args.width),
        "--height",
        str(args.height),
        "--diagnostics",
        args.diagnostics,
    ]
    if args.project_root:
        command.extend(["--project-root", args.project_root])
    return command


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not CHECKPOINT_RUNNER.is_file():
        print(f"Checkpoint test runner was not found: {CHECKPOINT_RUNNER}", file=sys.stderr)
        return 2
    completed = subprocess.run(build_command(args), cwd=PROJECT_ROOT, check=False)
    return int(completed.returncode)


if __name__ == "__main__":
    raise SystemExit(main())
