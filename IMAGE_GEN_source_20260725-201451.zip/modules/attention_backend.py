from __future__ import annotations

import os
from typing import Any, Callable


_ALLOWED_BACKENDS = {"eager", "sdpa", "xformers", "default"}


def resolve_attention_backend(value: str | None = None) -> str:
    """Resolve the IMAGE_GEN attention backend.

    Eager is the temporary recovery default because the last coherent baseline
    predates the accelerated attention path now selected by the rebuilt venv.
    The installed xFormers/MSLK packages are not removed or modified.
    """

    selected = str(
        value if value is not None else os.environ.get("IMAGE_GEN_ATTENTION_BACKEND", "eager")
    ).strip().lower()
    aliases = {
        "vanilla": "eager",
        "classic": "eager",
        "math": "eager",
        "torch": "sdpa",
        "torch_sdpa": "sdpa",
        "memory_efficient": "xformers",
        "auto": "default",
        "unchanged": "default",
    }
    selected = aliases.get(selected, selected)
    if selected not in _ALLOWED_BACKENDS:
        raise ValueError(
            "IMAGE_GEN_ATTENTION_BACKEND must be one of: eager, sdpa, xformers, default."
        )
    return selected


def _processor_names(unet: Any) -> list[str]:
    processors = getattr(unet, "attn_processors", None)
    if isinstance(processors, dict):
        return sorted({type(processor).__name__ for processor in processors.values()})
    return []


def configure_unet_attention(
    unet: Any,
    *,
    backend: str | None = None,
    processor_factory: Callable[[str], Any] | None = None,
) -> dict[str, Any]:
    """Configure one Diffusers UNet attention implementation and report truthfully."""

    selected = resolve_attention_backend(backend)
    before = _processor_names(unet)
    applied = False

    if selected == "eager":
        setter = getattr(unet, "set_attn_processor", None)
        if not callable(setter):
            raise RuntimeError("UNet does not expose set_attn_processor for eager recovery mode.")
        if processor_factory is None:
            from diffusers.models.attention_processor import AttnProcessor

            processor = AttnProcessor()
        else:
            processor = processor_factory(selected)
        setter(processor)
        applied = True
    elif selected == "sdpa":
        setter = getattr(unet, "set_attn_processor", None)
        if not callable(setter):
            raise RuntimeError("UNet does not expose set_attn_processor for SDPA mode.")
        if processor_factory is None:
            from diffusers.models.attention_processor import AttnProcessor2_0

            processor = AttnProcessor2_0()
        else:
            processor = processor_factory(selected)
        setter(processor)
        applied = True
    elif selected == "xformers":
        enabler = getattr(unet, "enable_xformers_memory_efficient_attention", None)
        if not callable(enabler):
            raise RuntimeError(
                "UNet does not expose enable_xformers_memory_efficient_attention."
            )
        enabler()
        applied = True

    after = _processor_names(unet)
    report = {
        "requested_backend": selected,
        "applied": applied,
        "processor_types_before": before,
        "processor_types_after": after,
        "environment_variable": "IMAGE_GEN_ATTENTION_BACKEND",
        "xformers_installation_changed": False,
    }
    setattr(unet, "_image_gen_attention_backend_report", dict(report))
    return report


def attention_backend_report(unet: Any) -> dict[str, Any]:
    existing = getattr(unet, "_image_gen_attention_backend_report", None)
    if isinstance(existing, dict):
        return dict(existing)
    return {
        "requested_backend": "unreported",
        "applied": False,
        "processor_types_before": [],
        "processor_types_after": _processor_names(unet),
        "environment_variable": "IMAGE_GEN_ATTENTION_BACKEND",
        "xformers_installation_changed": False,
    }
