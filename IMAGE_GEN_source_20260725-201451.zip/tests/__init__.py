"""IMAGE_GEN focused test helpers and phase validation suites."""
