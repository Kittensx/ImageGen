from __future__ import annotations

import ast
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import torch

from modules.contracts import (
    AdapterConformanceError,
    ConditioningOutput,
    GenerationRequest,
    GenerationResult,
    SamplerCapabilities,
    SamplerOutput,
    SchedulerOutput,
    check_adapter_conformance,
    require_adapter_conformance,
)
from modules.pipeline.schedule_compat import validate_schedule_for_sampler
from modules.ss_registry.master_sampler import SamplerMap
from modules.ss_registry.master_scheduler import SchedulerMap
from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.kes_sampler_adapter import (
    KESSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.simple_euler import (
    SimpleEulerSamplerAdapter,
)
from modules.ss_registry.schedulers.simple_kes_sched.kes_scheduler_adapter import (
    SimpleKESSchedulerAdapter,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _assert_json_tree(test: unittest.TestCase, value) -> None:
    allowed = (type(None), str, int, float, bool)
    if isinstance(value, allowed):
        return
    if isinstance(value, list):
        for item in value:
            _assert_json_tree(test, item)
        return
    if isinstance(value, dict):
        for key, item in value.items():
            test.assertIsInstance(key, str)
            _assert_json_tree(test, item)
        return
    test.fail(f"Non-serializable runtime object remained: {type(value)!r}")


class Phase02AdapterContractTests(unittest.TestCase):
    def test_required_sampler_adapters_conform(self) -> None:
        for adapter in (
            KESSamplerAdapter,
            SimpleEulerSamplerAdapter,
            DPMPlusPlus2MSamplerAdapter,
        ):
            with self.subTest(adapter=adapter.__name__):
                result = check_adapter_conformance(adapter, "sampler")
                self.assertTrue(result.is_conformant, result.reason)

    def test_scheduler_adapter_conforms(self) -> None:
        result = check_adapter_conformance(SimpleKESSchedulerAdapter, "scheduler")
        self.assertTrue(result.is_conformant, result.reason)

    def test_capabilities_make_cfg_ownership_explicit(self) -> None:
        kes = KESSamplerAdapter.SAMPLER_CAPABILITIES
        self.assertEqual(kes.guidance_owner, "sampler")
        self.assertTrue(kes.uses_raw_model_fn)
        self.assertFalse(kes.uses_guided_model_fn)

        for adapter in (SimpleEulerSamplerAdapter, DPMPlusPlus2MSamplerAdapter):
            sampler = adapter().sampler
            capabilities = sampler.SAMPLER_CAPABILITIES
            self.assertEqual(capabilities.guidance_owner, "pipeline")
            self.assertFalse(capabilities.uses_raw_model_fn)
            self.assertTrue(capabilities.uses_guided_model_fn)

    def test_invalid_adapter_fails_at_sampler_registry_registration(self) -> None:
        class InvalidSamplerAdapter:
            def sample(self, latents):
                return latents

        class DummySampler:
            pass

        module = SimpleNamespace(
            meta={"name": "invalid", "label": "Invalid"},
            SAMPLER_ADAPTER_CLASS=InvalidSamplerAdapter,
            SAMPLER_CLASS=DummySampler,
            required_args={},
            optional_args={},
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            registry = SamplerMap(
                base_path=temp_dir,
                auto_generate=False,
                output_to_file=False,
            )
            with self.assertRaises(AdapterConformanceError):
                registry._register_sampler_module(
                    mod=module,
                    entry="invalid",
                    module_name="tests.invalid_sampler",
                    config_entry_name="invalid",
                    source_type="test",
                )

    def test_invalid_adapter_fails_at_scheduler_registry_registration(self) -> None:
        class InvalidSchedulerAdapter:
            def build_schedule(self):
                return None

        module = SimpleNamespace(
            meta={"name": "invalid", "label": "Invalid", "args": {}},
            SCHEDULER_ADAPTER_CLASS=InvalidSchedulerAdapter,
            SCHEDULER_CLASS=None,
            scheduler=None,
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            scheduler_dir = Path(temp_dir) / "invalid"
            scheduler_dir.mkdir()
            registry = SchedulerMap(
                base_path=temp_dir,
                scan_path=temp_dir,
                auto_generate=False,
                output_to_file=False,
                verbose=False,
            )
            with self.assertRaises(AdapterConformanceError):
                registry._register_scheduler_module(
                    mod=module,
                    entry="invalid",
                    module_name="tests.invalid_scheduler",
                    seen_labels=set(),
                    subdir=str(scheduler_dir),
                )


class Phase02RuntimeObjectTests(unittest.TestCase):
    def test_schedule_fields_are_explicit_serializable_and_validated(self) -> None:
        schedule = SchedulerOutput(
            sigmas=torch.tensor([1.0, 0.6, 0.2, 0.0]),
            timesteps=torch.tensor([999.0, 666.0, 333.0]),
            requested_steps=3,
            effective_steps=3,
            compatibility_mode="fixed_steps",
            metadata={"scheduler_name": "test", "tail_features_used": {}},
        )
        self.assertEqual(schedule.requested_steps, 3)
        self.assertEqual(schedule.effective_steps, 3)
        self.assertEqual(schedule.extra["requested_steps"], 3)
        self.assertNotIn("requested_steps", schedule.metadata)

        request = GenerationRequest(positive_prompt="test", steps=3)
        compatibility = validate_schedule_for_sampler(
            schedule,
            request,
            sampler_name="simple_euler",
        )
        self.assertTrue(compatibility.is_compatible, compatibility.reasons)
        json.dumps(schedule.to_serializable_dict())
        json.dumps(compatibility.to_serializable_dict())

    def test_expanded_schedule_is_allowed_for_kes_but_not_baseline(self) -> None:
        schedule = SchedulerOutput(
            sigmas=torch.tensor([1.0, 0.8, 0.5, 0.2, 0.0]),
            timesteps=torch.tensor([999.0, 750.0, 500.0, 250.0]),
            requested_steps=3,
            effective_steps=4,
            scheduler_step_override_applied=True,
            compatibility_mode="extended_steps",
            metadata={"tail_features_used": {"decay_tail": True}},
        )
        request = GenerationRequest(positive_prompt="test", steps=3)
        baseline = validate_schedule_for_sampler(schedule, request, sampler_name="simple_euler")
        kes = validate_schedule_for_sampler(schedule, request, sampler_name="kes")
        self.assertFalse(baseline.is_compatible)
        self.assertTrue(kes.is_compatible, kes.reasons)

    def test_pipeline_generate_returns_canonical_generation_result(self) -> None:
        from tests.phase00.harness import AuditedFakePipelineHarness

        harness = AuditedFakePipelineHarness()
        with contextlib.redirect_stdout(io.StringIO()):
            result = harness.pipeline.generate(harness.default_request())
        self.assertIsInstance(result, GenerationResult)
        self.assertIsNotNone(result.images)
        self.assertEqual(result.schedule.requested_steps, 3)
        self.assertEqual(result.sampler_extra["effective_steps"], 3)

    def test_generation_result_serializes_without_live_runtime_objects(self) -> None:
        request = GenerationRequest(
            positive_prompt="contract test",
            steps=2,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )
        conditioning = ConditioningOutput(
            cond=torch.zeros((1, 4, 4)),
            uncond=torch.ones((1, 4, 4)),
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([1.0, 0.5, 0.0]),
            timesteps=torch.tensor([999.0, 0.0]),
            requested_steps=2,
            effective_steps=2,
        )
        sampler = SamplerOutput(
            latents=torch.zeros((1, 4, 8, 8)),
            extra={"sampler_name": "test"},
        )
        result = GenerationResult(
            request=request,
            images=torch.zeros((1, 3, 64, 64)),
            latents=sampler.latents,
            conditioning=conditioning,
            schedule=schedule,
            sampler=sampler,
            metadata={"runtime_object": object()},
        )
        payload = result.to_serializable_dict()
        _assert_json_tree(self, payload)
        encoded = json.dumps(payload)
        self.assertIn('"runtime_type"', encoded)
        self.assertNotIn("tensor(", encoded)

    def test_old_contract_imports_are_identity_aliases(self) -> None:
        from modules.pipeline_builder import SchedulerOutput as OldSchedulerOutput
        from modules.pipeline.pipeline_builder import SamplerOutput as OlderSamplerOutput
        from modules.contracts import SamplerOutput as CanonicalSamplerOutput

        self.assertIs(OldSchedulerOutput, SchedulerOutput)
        self.assertIs(OlderSamplerOutput, CanonicalSamplerOutput)

    def test_runtime_contract_classes_are_defined_only_in_contract_package(self) -> None:
        names = {
            "GenerationRequest",
            "PipelineComponents",
            "ConditioningOutput",
            "SchedulerOutput",
            "SamplerOutput",
            "GenerationResult",
            "SamplerCapabilities",
            "SchedulerCompatibilityResult",
            "PromptAdapterProtocol",
            "SchedulerAdapterProtocol",
            "SamplerAdapterProtocol",
        }
        definitions: dict[str, list[str]] = {name: [] for name in names}
        roots = (PROJECT_ROOT / "modules", PROJECT_ROOT / "src" / "image_gen")
        for root in roots:
            for path in root.rglob("*.py"):
                try:
                    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
                except SyntaxError:
                    # Phase 00 classified sampler_advanced.py as an archived experiment,
                    # not active runtime source. Contract ownership is enforced across
                    # parseable runtime modules.
                    continue
                for node in ast.walk(tree):
                    if isinstance(node, ast.ClassDef) and node.name in names:
                        definitions[node.name].append(path.relative_to(PROJECT_ROOT).as_posix())

        expected = {
            "GenerationRequest": ["src/image_gen/contracts/runtime.py"],
            "PipelineComponents": ["src/image_gen/contracts/runtime.py"],
            "ConditioningOutput": ["src/image_gen/contracts/runtime.py"],
            "SchedulerOutput": ["src/image_gen/contracts/runtime.py"],
            "SamplerOutput": ["src/image_gen/contracts/runtime.py"],
            "GenerationResult": ["src/image_gen/contracts/runtime.py"],
            "SamplerCapabilities": ["src/image_gen/contracts/compatibility.py"],
            "SchedulerCompatibilityResult": ["src/image_gen/contracts/compatibility.py"],
            "PromptAdapterProtocol": ["src/image_gen/contracts/protocols.py"],
            "SchedulerAdapterProtocol": ["src/image_gen/contracts/protocols.py"],
            "SamplerAdapterProtocol": ["src/image_gen/contracts/protocols.py"],
        }
        self.assertEqual(definitions, expected)


if __name__ == "__main__":
    unittest.main()
