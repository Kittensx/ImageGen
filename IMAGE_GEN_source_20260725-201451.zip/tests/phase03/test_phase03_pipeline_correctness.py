from __future__ import annotations

import contextlib
import io
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import torch

from modules.contracts import (
    ConditioningOutput,
    GenerationRequest,
    PipelineComponents,
    SchedulerOutput,
)
from modules.pipeline_builder import CustomSDPipeline
from modules.shared_state import SharedState
from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.kes_sampler_adapter import (
    KESSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.simple_euler import (
    SimpleEulerSamplerAdapter,
)
from modules.ss_registry.schedulers.simple_kes_sched.simple_kes import SimpleKEScheduler
from modules.txt2img.output_saver import save_generation_batch
from modules.txt2img.seed_utils import create_torch_generator
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
    FakeTextEncoder,
    FakeTokenizer,
    FakeUNet,
    FakeVAE,
)


class RecordingUNet(torch.nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self.calls: list[dict[str, Any]] = []

    def forward(self, *, sample, timestep, encoder_hidden_states, **kwargs):
        del kwargs
        self.calls.append(
            {
                "sample": sample.detach().clone(),
                "timestep": timestep.detach().clone(),
                "conditioning": encoder_hidden_states.detach().clone(),
            }
        )
        return SimpleNamespace(sample=torch.zeros_like(sample))


class DummyPromptAdapter:
    def encode(self, components, request, state=None):
        del components, request, state
        return ConditioningOutput(
            cond=torch.ones((1, 2, 2)),
            uncond=torch.zeros((1, 2, 2)),
        )


class DummySchedulerAdapter:
    def build_schedule(self, request, state=None):
        del request, state
        return SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )


class DummySamplerAdapter:
    def sample(
        self,
        raw_model_fn,
        guided_model_fn,
        latents,
        schedule,
        conditioning,
        request,
        state=None,
    ):
        del raw_model_fn, guided_model_fn, schedule, conditioning, request, state
        from modules.contracts import SamplerOutput

        return SamplerOutput(latents=latents)


class TupleVAE(FakeVAE):
    def decode(self, latents, **kwargs):
        return (super().decode(latents, **kwargs),)


class ObjectVAE(FakeVAE):
    def decode(self, latents, **kwargs):
        return SimpleNamespace(sample=super().decode(latents, **kwargs))


class StepResolver:
    def __init__(self) -> None:
        self.requested_steps: list[int] = []

    def resolve(self, step_index: int):
        self.requested_steps.append(step_index)
        value = float(step_index + 1)
        return (
            torch.full((1, 2, 2), value),
            torch.zeros((1, 2, 2)),
        )


class Phase03PipelineCorrectnessTests(unittest.TestCase):
    def _pipeline(
        self,
        sampler_adapter=None,
        *,
        unet=None,
        vae=None,
        state=None,
    ) -> CustomSDPipeline:
        return CustomSDPipeline(
            components=PipelineComponents(
                unet=unet or FakeUNet(),
                vae=vae or FakeVAE(),
                text_encoder=FakeTextEncoder(),
                tokenizer=FakeTokenizer(),
            ),
            prompt_adapter=FakePromptAdapter(),
            scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
            sampler_adapter=sampler_adapter or SimpleEulerSamplerAdapter(),
            state=state,
            latent_scale_factor=8,
            vae_scaling_factor=1.0,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )

    @staticmethod
    def _request(*, seed: int | None = 1234, sampler_name: str = "simple_euler"):
        return GenerationRequest(
            positive_prompt="phase three",
            negative_prompt="",
            width=32,
            height=32,
            steps=3,
            cfg_scale=2.0,
            batch_size=1,
            seed=seed,
            device=torch.device("cpu"),
            dtype=torch.float32,
            scheduler_name="phase03_fake",
            sampler_name=sampler_name,
        )

    def test_raw_and_guided_callbacks_use_canonical_argument_order(self) -> None:
        unet = RecordingUNet()
        pipeline = self._pipeline(unet=unet)
        latents = torch.ones((1, 4, 2, 2))
        sigma = torch.tensor(3.0)
        timestep = torch.tensor(777.0)
        cond = torch.full((1, 2, 2), 4.0)
        uncond = torch.full((1, 2, 2), -2.0)

        raw = pipeline.predict_raw_noise(latents, sigma, timestep, cond)
        self.assertTrue(torch.equal(raw, torch.zeros_like(latents)))
        expected_input = latents / torch.sqrt(torch.tensor(10.0))
        self.assertTrue(torch.allclose(unet.calls[0]["sample"], expected_input))
        self.assertEqual(unet.calls[0]["timestep"].item(), 777.0)
        self.assertEqual(unet.calls[0]["conditioning"].mean().item(), 4.0)

        pipeline.predict_guided_noise(
            latents,
            sigma,
            timestep,
            cond,
            uncond,
            7.0,
        )
        self.assertEqual(len(unet.calls), 3)
        self.assertEqual(unet.calls[1]["conditioning"].mean().item(), -2.0)
        self.assertEqual(unet.calls[2]["conditioning"].mean().item(), 4.0)
        self.assertEqual(unet.calls[1]["timestep"].item(), 777.0)
        self.assertEqual(unet.calls[2]["timestep"].item(), 777.0)

    def test_schedule_length_direction_and_timestep_rules_are_enforced(self) -> None:
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )
        self.assertEqual(schedule.sigma_transitions, 2)
        self.assertEqual(schedule.initial_sigma, 2.0)
        self.assertEqual(schedule.timestep_for_step(1).item(), 100.0)

        with self.assertRaises(ValueError):
            SchedulerOutput(
                sigmas=torch.tensor([1.0, 2.0, 0.0]),
                timesteps=torch.tensor([900.0, 100.0]),
                requested_steps=2,
                effective_steps=2,
            )
        with self.assertRaises(ValueError):
            SchedulerOutput(
                sigmas=torch.tensor([2.0, 1.0, 0.0]),
                timesteps=torch.tensor([900.0]),
                requested_steps=2,
                effective_steps=2,
            )
        with self.assertRaises(ValueError):
            SchedulerOutput(
                sigmas=torch.tensor([2.0, 1.0, 0.0]),
                timesteps=torch.tensor([900.0, 100.0]),
                requested_steps=2,
                effective_steps=3,
            )

    def test_sd1_sigma_to_timestep_mapping_has_correct_direction(self) -> None:
        scheduler = SimpleKEScheduler.__new__(SimpleKEScheduler)
        scheduler.settings = {
            "num_train_timesteps": 1000,
            "beta_start": 0.00085,
            "beta_end": 0.012,
        }
        sigmas = torch.tensor([14.0, 1.0, 0.1, 0.0])
        timesteps = scheduler._sigmas_to_timesteps(sigmas)
        self.assertTrue(torch.all(timesteps[1:] <= timesteps[:-1]))
        self.assertGreater(timesteps[0].item(), timesteps[1].item())
        self.assertEqual(timesteps[-1].item(), 0.0)
        self.assertGreaterEqual(timesteps.min().item(), 0.0)
        self.assertLessEqual(timesteps.max().item(), 999.0)

    def test_initial_latents_use_fixed_seed_and_initial_sigma(self) -> None:
        pipeline = self._pipeline()
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.5, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )
        request_a = self._request(seed=42)
        request_b = self._request(seed=42)
        latents_a = pipeline.prepare_latents(request_a, schedule)
        latents_b = pipeline.prepare_latents(request_b, schedule)
        self.assertTrue(torch.equal(latents_a, latents_b))

        generator = create_torch_generator(42, device="cpu")
        expected = torch.randn(
            latents_a.shape,
            generator=generator,
            dtype=torch.float32,
        ) * 2.5
        self.assertTrue(torch.equal(latents_a, expected))
        self.assertEqual(request_a.seed, 42)

    def test_all_three_sampler_paths_complete_fake_generation(self) -> None:
        cases = [
            ("simple_euler", SimpleEulerSamplerAdapter(), None),
            ("dpmpp_2m", DPMPlusPlus2MSamplerAdapter(), None),
            ("kes", KESSamplerAdapter(shared_state=SharedState()), SharedState()),
        ]
        for sampler_name, adapter, state in cases:
            if sampler_name == "kes":
                state = adapter.state
            unet = FakeUNet()
            pipeline = self._pipeline(
                sampler_adapter=adapter,
                unet=unet,
                state=state,
            )
            request = self._request(seed=99, sampler_name=sampler_name)
            if sampler_name == "kes":
                request.sampler_kwargs = {
                    "sampler_type": "euler",
                    "add_noise": False,
                    "initial_noise_strength": 0.0,
                }
            result = pipeline.generate(request)
            self.assertEqual(tuple(result.images.shape), (1, 3, 32, 32))
            self.assertEqual(result.schedule.sigma_transitions, 3)
            self.assertEqual(len(unet.calls), 6)
            self.assertEqual(result.sampler.extra["model_prediction_type"], "epsilon")

    def test_baseline_samplers_receive_timestep_and_dpm_integrates_denoised(self) -> None:
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )
        conditioning = ConditioningOutput(
            cond=torch.ones((1, 2, 2)),
            uncond=torch.zeros((1, 2, 2)),
        )
        request = self._request(seed=1)
        request.steps = 2
        latents = torch.ones((1, 4, 2, 2))

        for adapter in (SimpleEulerSamplerAdapter(), DPMPlusPlus2MSamplerAdapter()):
            calls: list[float] = []

            def guided_model_fn(x, sigma, timestep, cond, uncond, cfg_scale, extra=None):
                del sigma, cond, uncond, cfg_scale, extra
                calls.append(float(timestep))
                return torch.zeros_like(x)

            def predict_denoised(x, sigma, timestep, cond, uncond, cfg_scale, extra=None):
                del sigma, cond, uncond, cfg_scale, extra
                calls.append(float(timestep))
                return x.float()

            guided_model_fn.predict_denoised = predict_denoised
            guided_model_fn.denoising_contract = lambda: {
                "prediction_type": "epsilon",
                "prediction_conversion": "test canonical epsilon to x0",
                "model_input_preconditioning": "test",
                "cfg_rescale": 0.0,
            }

            output = adapter.sample(
                raw_model_fn=lambda *args, **kwargs: None,
                guided_model_fn=guided_model_fn,
                latents=latents.clone(),
                schedule=schedule,
                conditioning=conditioning,
                request=request,
                state=None,
            )
            self.assertEqual(calls, [900.0, 100.0])
            self.assertTrue(torch.equal(output.latents, latents))

    def test_all_samplers_use_shared_step_conditioning_resolver(self) -> None:
        resolver = StepResolver()
        conditioning = ConditioningOutput(
            cond=torch.zeros((1, 2, 2)),
            uncond=torch.zeros((1, 2, 2)),
            extra={"resolver": resolver},
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([3.0, 2.0, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 600.0, 300.0]),
            requested_steps=3,
            effective_steps=3,
        )
        request = self._request(seed=1)
        seen: list[float] = []

        def guided_model_fn(x, sigma, timestep, cond, uncond, cfg_scale, extra=None):
            del sigma, timestep, uncond, cfg_scale, extra
            seen.append(float(cond.mean()))
            return torch.zeros_like(x)

        SimpleEulerSamplerAdapter().sample(
            raw_model_fn=lambda *args, **kwargs: None,
            guided_model_fn=guided_model_fn,
            latents=torch.zeros((1, 4, 2, 2)),
            schedule=schedule,
            conditioning=conditioning,
            request=request,
            state=None,
        )
        self.assertEqual(seen, [1.0, 2.0, 3.0])
        self.assertEqual(resolver.requested_steps, [0, 1, 2])

    def test_vae_decode_accepts_tensor_tuple_and_sample_object(self) -> None:
        latents = torch.zeros((1, 4, 4, 4))
        for vae in (FakeVAE(), TupleVAE(), ObjectVAE()):
            images = self._pipeline(vae=vae).decode_latents(latents)
            self.assertEqual(tuple(images.shape), (1, 3, 32, 32))
            self.assertTrue(torch.isfinite(images).all())

    def test_core_pipeline_never_writes_and_output_layer_writes_once(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            request = self._request(seed=7)
            request.save_images = True
            request.output_dir = temp_dir
            result = self._pipeline().generate(request)
            self.assertEqual(list(Path(temp_dir).iterdir()), [])
            self.assertEqual(result.saved_paths, [])
            self.assertEqual(result.metadata["output_owner"], "txt2img.output_saver")

            records = save_generation_batch(
                result.images,
                output_dir=temp_dir,
                prefix="phase03",
                manifest=None,
                save_txt=False,
                save_json=False,
            )
            self.assertEqual(len(records), 1)
            self.assertEqual(len(list(Path(temp_dir).glob("*.png"))), 1)
            self.assertEqual(len(list(Path(temp_dir).glob("*.txt"))), 0)
            self.assertEqual(len(list(Path(temp_dir).glob("*.json"))), 0)

    def test_fixed_seed_generation_is_reproducible_and_normal_run_is_quiet(self) -> None:
        pipeline = self._pipeline()
        with contextlib.redirect_stdout(io.StringIO()) as captured:
            first = pipeline.generate(self._request(seed=2026))
            second = pipeline.generate(self._request(seed=2026))
        self.assertTrue(torch.equal(first.latents, second.latents))
        self.assertTrue(torch.equal(first.images, second.images))
        self.assertNotIn("[DEBUG]", captured.getvalue())


if __name__ == "__main__":
    unittest.main()
