from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[2] / "scripts" / "validation" / "phase07_validate.py"
SPEC = importlib.util.spec_from_file_location("phase07_validate_script", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class Phase07OutputDirectoryTests(unittest.TestCase):
    def test_prepare_output_directories_creates_both_generation_targets(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir) / "validation-run"
            baseline_dir, comparison_dir = MODULE.prepare_validation_output_dirs(
                root,
                save_images=True,
            )

            self.assertEqual(baseline_dir, root / "images" / "baseline")
            self.assertEqual(comparison_dir, root / "images" / "kes")
            self.assertTrue(baseline_dir.is_dir())
            self.assertTrue(comparison_dir.is_dir())

    def test_no_save_mode_does_not_create_image_directories(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir) / "validation-run"
            baseline_dir, comparison_dir = MODULE.prepare_validation_output_dirs(
                root,
                save_images=False,
            )

            self.assertFalse(baseline_dir.exists())
            self.assertFalse(comparison_dir.exists())


if __name__ == "__main__":
    unittest.main()
