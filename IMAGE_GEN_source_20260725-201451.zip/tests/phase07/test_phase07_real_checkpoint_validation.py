from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import torch
from safetensors.torch import save_file

from image_gen.contracts import (
    ConditioningOutput,
    GenerationRequest,
    GenerationResult,
    SamplerOutput,
    SchedulerOutput,
)
from image_gen.systems.model_loading import ModelLoadingSystem
from image_gen.systems.validation import (
    RealCheckpointValidationSystem,
    ValidationProfile,
    capability_for,
)
from modules.checkpoint_inspector import CheckpointInspector


class FakeTokenizer:
    model_max_length = 77
    vocab_size = 49408
    bos_token_id = 49406
    eos_token_id = 49407
    pad_token_id = 49407

    def __len__(self):
        return self.vocab_size

    def __call__(self, prompt, padding, max_length, truncation, return_tensors):
        values = [self.bos_token_id]
        values.extend((ord(char) % 1000) + 10 for char in prompt[: max_length - 2])
        values.append(self.eos_token_id)
        values = values[:max_length]
        values.extend([self.pad_token_id] * (max_length - len(values)))
        return {"input_ids": torch.tensor([values], dtype=torch.int64)}


class Phase07CheckpointInspectionTests(unittest.TestCase):
    def test_inspector_uses_header_shapes_to_identify_sd1(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "sd1.safetensors"
            save_file(
                {
                    "model.diffusion_model.input_blocks.0.0.weight": torch.zeros(320, 4, 3, 3),
                    "model.diffusion_model.input_blocks.1.1.transformer_blocks.0.attn2.to_k.weight": torch.zeros(320, 768),
                    "first_stage_model.encoder.conv_in.weight": torch.zeros(128, 3, 3, 3),
                    "cond_stage_model.transformer.text_model.embeddings.token_embedding.weight": torch.zeros(16, 768),
                },
                str(path),
            )
            with mock.patch(
                "modules.checkpoint_inspector.load_file",
                side_effect=AssertionError("inspect must not materialize checkpoint tensors"),
            ):
                report = CheckpointInspector().inspect(str(path))
            self.assertEqual(report.architecture, "sd1.x")
            self.assertEqual(report.checkpoint_kind, "full")
            self.assertEqual(len(report.sha256), 64)
            self.assertEqual(report.dtype_summary["F32"], 4)
            self.assertTrue(report.tensor_shape_summary)

    def test_architecture_capabilities_are_explicit(self) -> None:
        self.assertTrue(capability_for("sd1.x").validation_supported)
        self.assertFalse(capability_for("sd2.x").generation_supported)
        self.assertIn("OpenCLIP", capability_for("sd2.x").reason)
        self.assertFalse(capability_for("sdxl").validation_supported)
        self.assertIn("dual text encoders", capability_for("sdxl").reason)

    def test_model_loading_rejects_unsupported_architecture_before_build(self) -> None:
        class Loader:
            def prepare_load_plan(self, model_path):
                return SimpleNamespace(
                    report=SimpleNamespace(architecture="sd2.x")
                )

            def build_components_from_plan(self, plan, dtype=None):
                raise AssertionError("unsupported architecture must not build components")

        with self.assertRaisesRegex(RuntimeError, "not enabled"):
            ModelLoadingSystem(Loader()).load(
                "sd2.safetensors", tokenizer=object(), dtype=torch.float32
            )


class Phase07ValidationReportTests(unittest.TestCase):
    @staticmethod
    def run_result(sampler: str, seed: int = 707):
        request = GenerationRequest(
            positive_prompt="phase seven",
            negative_prompt="",
            width=32,
            height=32,
            steps=2,
            cfg_scale=7.0,
            batch_size=1,
            seed=seed,
            sampler_name=sampler,
            scheduler_name="simple_kes",
        )
        conditioning = ConditioningOutput(
            cond=torch.ones((1, 77, 768), dtype=torch.float32),
            uncond=torch.zeros((1, 77, 768), dtype=torch.float32),
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([800.0, 400.0]),
            requested_steps=2,
            effective_steps=2,
        )
        latents = torch.full((1, 4, 4, 4), 0.25)
        images = torch.full((1, 3, 32, 32), 0.5)
        pipeline = GenerationResult(
            request=request,
            images=images,
            latents=latents,
            conditioning=conditioning,
            schedule=schedule,
            sampler=SamplerOutput(latents=latents, extra={"sampler_name": sampler}),
        )
        return SimpleNamespace(
            request=request,
            pipeline_result=pipeline,
            diagnostics={
                "tensor_summaries": {
                    "latent_preparation.latents": {
                        "shape": [1, 4, 4, 4],
                        "dtype": "torch.float32",
                        "device": "cpu",
                        "finite": True,
                    }
                },
                "timings": [],
            },
            saved_records=[],
            run_id=f"run-{sampler}",
            generation_time_sec=0.1,
        )

    def test_tokenizer_report_is_local_deterministic_and_fixed_length(self) -> None:
        validator = RealCheckpointValidationSystem(SimpleNamespace())
        report = validator.validate_tokenizer(FakeTokenizer(), ["hello", ""])
        self.assertTrue(report["passed"])
        self.assertEqual(report["model_max_length"], 77)
        self.assertTrue(all(row["deterministic"] for row in report["prompts"]))

    def test_report_records_coverage_reproducibility_and_sampler_comparison(self) -> None:
        validator = RealCheckpointValidationSystem(SimpleNamespace())
        profile = ValidationProfile(width=32, height=32, steps=2)
        checkpoint = SimpleNamespace(
            architecture="sd1.x",
            checkpoint_kind="full",
            to_dict=lambda: {
                "file_name": "test.safetensors",
                "sha256": "a" * 64,
                "architecture": "sd1.x",
                "checkpoint_kind": "full",
            },
        )
        coverage = {
            name: {
                "name": name,
                "success": True,
                "coverage_ratio": 1.0,
                "expected_keys": 10,
                "matched_keys": 10,
            }
            for name in ("unet", "vae", "text_encoder")
        }
        tokenizer = {"passed": True, "prompts": []}
        first = self.run_result("simple_euler")
        repeat = self.run_result("simple_euler")
        kes = self.run_result("kes")
        report = validator.build_report(
            profile=profile,
            checkpoint=checkpoint,
            tokenizer_report=tokenizer,
            component_coverage=coverage,
            baseline_first=first,
            baseline_repeat=repeat,
            comparison_run=kes,
        )
        self.assertTrue(report.passed)
        self.assertTrue(
            report.comparisons["fixed_seed_repeat"]["images"][
                "materially_equivalent"
            ]
        )
        self.assertEqual(len(report.runs), 3)
        with tempfile.TemporaryDirectory() as temp_dir:
            json_path, markdown_path = validator.write_report(report, temp_dir)
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertTrue(payload["passed"])
            self.assertTrue(markdown_path.is_file())


if __name__ == "__main__":
    unittest.main()
