from __future__ import annotations

import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import torch

from image_gen.contracts import GenerationRequest, GenerationResult
from image_gen.systems.diagnostics import (
    DiagnosticConfig,
    DiagnosticsSystem,
    PipelineStageError,
)
from image_gen.systems.diagnostics.serialization import json_safe
from image_gen.systems.output import OutputSystem
from image_gen.systems.registry import PluginDescriptor
from modules.txt2img.generation_manifest import GenerationManifest
from modules.txt2img.manifest_io import save_manifest_json, save_manifest_txt


def descriptor() -> PluginDescriptor:
    return PluginDescriptor(
        plugin_id="sampler.test_serialization",
        kind="sampler",
        name="test_serialization",
        label="Test Serialization",
        module="tests.phase07.test_phase07_serialization_resilience",
        adapter_class="Phase07SerializationResilienceTests",
        capabilities={"cfg_owner": "pipeline"},
        config_schema={
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": True,
        },
    )


class Phase07SerializationResilienceTests(unittest.TestCase):
    def test_registry_descriptor_serializes_without_mappingproxy_copy(self) -> None:
        payload = json_safe({"descriptor": descriptor()})
        self.assertEqual(
            payload["descriptor"]["plugin_id"],
            "sampler.test_serialization",
        )
        json.dumps(payload)

    def test_manifest_sidecars_normalize_torch_runtime_values(self) -> None:
        manifest = GenerationManifest()
        manifest.optional_for_rerun.scheduler_kwargs = {
            "device": torch.device("cpu"),
            "dtype": torch.float16,
        }
        manifest.extra["plugin"] = descriptor()

        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            json_path = save_manifest_json(manifest, root / "manifest.json")
            txt_path = save_manifest_txt(manifest, root / "manifest.txt")

            payload = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual(
                payload["optional_for_rerun"]["scheduler_kwargs"]["device"],
                "cpu",
            )
            self.assertEqual(
                payload["optional_for_rerun"]["scheduler_kwargs"]["dtype"],
                "torch.float16",
            )
            self.assertEqual(
                payload["extra"]["plugin"]["plugin_id"],
                "sampler.test_serialization",
            )
            self.assertIn('"device": "cpu"', txt_path.read_text(encoding="utf-8"))

    def test_output_system_saves_image_and_sidecars_with_runtime_objects(self) -> None:
        request = GenerationRequest(
            positive_prompt="serialization test",
            width=8,
            height=8,
            steps=1,
            seed=7,
            sampler_name="simple_euler",
            scheduler_name="simple_kes",
            scheduler_kwargs={"device": torch.device("cpu")},
            output_prefix="phase07",
        )
        pipeline_result = GenerationResult(
            request=request,
            images=torch.full((1, 3, 8, 8), 0.5),
        )
        output = OutputSystem()
        manifest = output.build_manifest(
            request=request,
            extras={
                "model_path": "test.safetensors",
                "plugin_compatibility": descriptor(),
            },
            pipeline_result=pipeline_result,
            device_name="cpu",
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            records = output.save(
                pipeline_result=pipeline_result,
                request=request,
                manifest=manifest,
                output_dir=temp_dir,
                save_txt=True,
                save_json=True,
            )
            self.assertEqual(len(records), 1)
            record = records[0]
            self.assertTrue(Path(record.image_path).is_file())
            payload = json.loads(Path(record.json_path).read_text(encoding="utf-8"))
            self.assertEqual(
                payload["optional_for_rerun"]["scheduler_kwargs"]["device"],
                "cpu",
            )
            self.assertEqual(
                payload["extra"]["plugin_compatibility"]["plugin_id"],
                "sampler.test_serialization",
            )

    def test_failure_bundle_preserves_original_error_with_descriptor_extras(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            diagnostics = DiagnosticsSystem(
                DiagnosticConfig(
                    verbosity="quiet",
                    artifacts_root=Path(temp_dir),
                ),
                console=io.StringIO(),
            )
            request = GenerationRequest(positive_prompt="failure test")
            session = diagnostics.start(
                request,
                request_extras={"descriptor": descriptor()},
            )

            with self.assertRaises(PipelineStageError) as captured:
                diagnostics.run_stage(
                    session,
                    "output",
                    "save",
                    lambda: (_ for _ in ()).throw(
                        TypeError("Object of type device is not JSON serializable")
                    ),
                )

            error = captured.exception
            self.assertEqual(error.system, "output")
            self.assertEqual(error.operation, "save")
            self.assertEqual(
                error.cause_message,
                "Object of type device is not JSON serializable",
            )
            self.assertIsNotNone(error.bundle_path)
            request_extras = json.loads(
                (Path(error.bundle_path) / "request_extras.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertEqual(
                request_extras["descriptor"]["plugin_id"],
                "sampler.test_serialization",
            )

    def test_failure_bundle_writer_cannot_mask_original_stage_error(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            console = io.StringIO()
            diagnostics = DiagnosticsSystem(
                DiagnosticConfig(
                    verbosity="quiet",
                    artifacts_root=Path(temp_dir),
                ),
                console=console,
            )
            session = diagnostics.start(
                GenerationRequest(positive_prompt="fallback test")
            )

            with mock.patch(
                "image_gen.systems.diagnostics.system.write_failure_bundle",
                side_effect=RuntimeError("bundle writer failed"),
            ):
                with self.assertRaises(PipelineStageError) as captured:
                    diagnostics.run_stage(
                        session,
                        "output",
                        "save",
                        lambda: (_ for _ in ()).throw(TypeError("original save error")),
                    )

            error = captured.exception
            self.assertEqual(error.cause_type, "TypeError")
            self.assertEqual(error.cause_message, "original save error")
            self.assertIn("preserving original TypeError", console.getvalue())
            self.assertIsNotNone(error.bundle_path)
            fallback_payload = json.loads(
                (Path(error.bundle_path) / "failure.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                fallback_payload["original_error_message"],
                "original save error",
            )
            self.assertEqual(
                fallback_payload["bundle_error_message"],
                "bundle writer failed",
            )


if __name__ == "__main__":
    unittest.main()
