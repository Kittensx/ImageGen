from __future__ import annotations

import unittest

import torch

from image_gen.contracts import GenerationRequest
from image_gen.systems.registry.discovery import PluginDiscovery
from modules.ss_registry.schedulers.standard_karras_sched import (
    StandardKarrasSchedulerAdapter,
)


class StandardKarrasSchedulerTests(unittest.TestCase):
    def _request(self, **scheduler_kwargs):
        return GenerationRequest(
            positive_prompt="standard scheduler control",
            steps=20,
            sampler_name="dpmpp_2m",
            scheduler_name="standard_karras",
            scheduler_kwargs=scheduler_kwargs,
            device="cpu",
        )

    def test_default_schedule_uses_model_training_bounds(self) -> None:
        output = StandardKarrasSchedulerAdapter().build_schedule(self._request())
        mapping = output.metadata["timestep_mapping"]
        self.assertEqual(output.sigmas.numel(), 21)
        self.assertEqual(output.timesteps.numel(), 21)
        self.assertEqual(output.sigma_transitions, 20)
        self.assertEqual(float(output.sigmas[-1]), 0.0)
        self.assertAlmostEqual(float(output.sigmas[0]), mapping["training_sigma_max"], places=4)
        self.assertAlmostEqual(float(output.sigmas[-2]), mapping["training_sigma_min"], places=5)
        self.assertEqual(mapping["clipped_high_count"], 0)
        self.assertEqual(mapping["clipped_low_count"], 0)

    def test_model_timesteps_decrease_without_initial_plateau(self) -> None:
        output = StandardKarrasSchedulerAdapter().build_schedule(self._request())
        transition_timesteps = output.timesteps[:-1]
        self.assertTrue(torch.all(transition_timesteps[1:] < transition_timesteps[:-1]))
        self.assertAlmostEqual(float(transition_timesteps[0]), 999.0, places=3)
        self.assertAlmostEqual(float(transition_timesteps[-1]), 0.0, places=3)

    def test_scheduler_is_plain_fixed_step_control(self) -> None:
        output = StandardKarrasSchedulerAdapter().build_schedule(self._request())
        self.assertEqual(output.requested_steps, 20)
        self.assertEqual(output.effective_steps, 20)
        self.assertFalse(output.scheduler_step_override_applied)
        self.assertEqual(output.compatibility_mode, "fixed_steps")
        self.assertEqual(output.metadata["active_blend_methods"], [])
        self.assertFalse(any(output.metadata["tail_features_used"].values()))
        self.assertFalse(output.metadata["prepass_used"])

    def test_out_of_model_range_requires_explicit_opt_in(self) -> None:
        with self.assertRaisesRegex(ValueError, "allow_out_of_range"):
            StandardKarrasSchedulerAdapter().build_schedule(
                self._request(sigma_max=50.0)
            )
        output = StandardKarrasSchedulerAdapter().build_schedule(
            self._request(sigma_max=50.0, allow_out_of_range=True)
        )
        self.assertGreater(output.metadata["timestep_mapping"]["clipped_high_count"], 0)

    def test_plugin_discovery_finds_standard_karras(self) -> None:
        discovery = PluginDiscovery("modules/ss_registry")
        candidates = discovery.candidates("scheduler")
        candidate = next(
            item for item in candidates if item.module_name.endswith("standard_karras_sched")
        )
        module = discovery.import_candidate(candidate)
        descriptor = discovery.descriptor_from_module(module, candidate)
        self.assertEqual(descriptor.plugin_id, "scheduler.standard_karras")
        self.assertEqual(descriptor.name, "standard_karras")
        self.assertFalse(descriptor.capabilities["supports_step_expansion"])


    def test_kes_pair_uses_requested_steps_with_capability_clamp(self) -> None:
        request = self._request()
        request.steps = 7
        request.sampler_name = "kes"
        request.scheduler_kwargs = {
            "pipeline_mode": "fixed_steps",
            "compatibility": {
                "requested_by_sampler": "kes",
                "scheduler_family": "standard",
                "negotiated_pipeline_mode": "fixed_steps",
                "step_expansion_clamped": True,
                "tail_metadata_clamped": True,
            },
        }
        output = StandardKarrasSchedulerAdapter().build_schedule(request)
        self.assertEqual(output.requested_steps, 7)
        self.assertEqual(output.effective_steps, 7)
        self.assertEqual(output.sigmas.numel() - 1, 7)
        clamp = output.extra["sampler_capability_clamp"]
        self.assertTrue(clamp["active"])
        self.assertTrue(clamp["step_expansion_clamped"])
        self.assertTrue(clamp["tail_metadata_clamped"])
        self.assertEqual(output.compatibility_mode, "fixed_steps")


if __name__ == "__main__":
    unittest.main()
