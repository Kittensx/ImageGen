from __future__ import annotations

import unittest

import torch

from image_gen.contracts import (
    GenerationRequest,
    GenerationResult,
    SamplerOutput,
    SchedulerOutput,
)
from image_gen.systems.denoising import DenoisingSystem
from image_gen.systems.output import OutputSystem
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSampler,
)
from modules.txt2img.generation_manifest import GenerationManifest


class RecordingUNet(torch.nn.Module):
    def __init__(self, *, output_mode: str = "conditioning", dtype: torch.dtype = torch.float32):
        super().__init__()
        self.marker = torch.nn.Parameter(torch.zeros((), dtype=dtype), requires_grad=False)
        self.output_mode = output_mode
        self.calls: list[dict[str, object]] = []

    def forward(self, sample, timestep, encoder_hidden_states, **kwargs):
        del kwargs
        self.calls.append(
            {
                "sample": sample.detach().clone(),
                "timestep": timestep.detach().clone(),
                "conditioning": encoder_hidden_states.detach().clone(),
            }
        )
        if self.output_mode == "conditioning":
            value = encoder_hidden_states.mean().to(device=sample.device, dtype=sample.dtype)
            output = torch.full_like(sample, value)
        elif self.output_mode == "sample":
            output = sample.clone()
        else:
            output = torch.zeros_like(sample)
        return type("UNetOutput", (), {"sample": output})()


class Phase08CCanonicalDenoisingTests(unittest.TestCase):
    def test_epsilon_to_x0_uses_solver_sample_and_exact_sigma(self) -> None:
        sample = torch.full((1, 1, 1, 1), 10.0)
        epsilon = torch.full_like(sample, 2.0)
        result = DenoisingSystem.convert_model_output_to_denoised(
            solver_sample=sample,
            sigma=torch.tensor(3.0),
            model_output=epsilon,
            prediction_type="epsilon",
        )
        self.assertEqual(result.dtype, torch.float32)
        self.assertTrue(torch.equal(result, torch.full_like(result, 4.0)))

    def test_v_prediction_to_x0_matches_karras_parameterization(self) -> None:
        sample = torch.full((1, 1, 1, 1), 10.0)
        velocity = torch.full_like(sample, 2.0)
        sigma = torch.tensor(3.0)
        expected = sample.float() / 10.0 - (3.0 / torch.sqrt(torch.tensor(10.0))) * 2.0
        result = DenoisingSystem.convert_model_output_to_denoised(
            solver_sample=sample,
            sigma=sigma,
            model_output=velocity,
            prediction_type="v_prediction",
        )
        self.assertTrue(torch.allclose(result, expected))

    def test_sample_and_x0_aliases_are_direct_predictions(self) -> None:
        sample = torch.full((1, 1, 1, 1), 10.0)
        predicted = torch.full_like(sample, 1.25)
        for prediction_type in ("sample", "x0", "predicted_x0"):
            result = DenoisingSystem.convert_model_output_to_denoised(
                solver_sample=sample,
                sigma=3.0,
                model_output=predicted,
                prediction_type=prediction_type,
            )
            self.assertEqual(result.dtype, torch.float32)
            self.assertTrue(torch.equal(result, predicted.float()))

    def test_cfg_is_applied_to_model_outputs_before_x0_conversion(self) -> None:
        unet = RecordingUNet()
        denoiser = DenoisingSystem(unet, prediction_type="epsilon")
        sample = torch.full((1, 1, 1, 1), 10.0)
        uncond = torch.full((1, 1, 1), 1.0)
        cond = torch.full((1, 1, 1), 3.0)

        result = denoiser.predict_denoised(
            sample,
            sigma=2.0,
            timestep=500.0,
            cond=cond,
            uncond=uncond,
            cfg_scale=2.0,
        )
        # guided epsilon = 1 + 2 * (3 - 1) = 5; x0 = 10 - 2 * 5 = 0.
        self.assertTrue(torch.equal(result, torch.zeros_like(result)))
        self.assertEqual(
            [float(call["conditioning"].mean()) for call in unet.calls],
            [1.0, 3.0],
        )

    def test_model_dtype_boundary_and_float32_solver_output(self) -> None:
        unet = RecordingUNet(output_mode="zero", dtype=torch.float16)
        denoiser = DenoisingSystem(unet, prediction_type="epsilon")
        sample = torch.full((1, 1, 1, 1), 7.0, dtype=torch.float32)
        conditioning = torch.ones((1, 1, 1), dtype=torch.float16)

        result = denoiser.predict_denoised(
            sample,
            sigma=3.0,
            timestep=900.0,
            cond=conditioning,
            uncond=conditioning,
            cfg_scale=1.0,
        )
        self.assertEqual(unet.calls[0]["sample"].dtype, torch.float16)
        self.assertEqual(result.dtype, torch.float32)
        self.assertTrue(torch.equal(result, sample))

    def test_conversion_uses_solver_sample_not_preconditioned_model_input(self) -> None:
        unet = RecordingUNet(output_mode="zero")
        denoiser = DenoisingSystem(unet, prediction_type="epsilon")
        sample = torch.full((1, 1, 1, 1), 10.0)
        conditioning = torch.ones((1, 1, 1))

        result = denoiser.predict_denoised(
            sample,
            sigma=3.0,
            timestep=999.0,
            cond=conditioning,
            uncond=conditioning,
            cfg_scale=1.0,
        )
        expected_model_input = sample / torch.sqrt(torch.tensor(10.0))
        self.assertTrue(torch.allclose(unet.calls[0]["sample"], expected_model_input))
        self.assertTrue(torch.equal(result, sample))
        self.assertFalse(torch.equal(result, expected_model_input))

    def test_trace_records_sigma_timestep_cfg_and_contract_truthfully(self) -> None:
        unet = RecordingUNet()
        denoiser = DenoisingSystem(
            unet,
            prediction_type="v_prediction",
            prediction_type_source="synthetic_test",
        )
        denoiser.configure_request(cfg_rescale=0.25)
        denoiser.set_guidance_trace_enabled(True)
        sample = torch.ones((1, 1, 1, 1))
        conditioning = torch.ones((1, 1, 1))
        denoiser.predict_denoised(
            sample,
            sigma=4.5,
            timestep=777.0,
            cond=conditioning * 2,
            uncond=conditioning,
            cfg_scale=6.0,
        )
        trace = denoiser.consume_guidance_trace()
        self.assertIsNotNone(trace)
        assert trace is not None
        self.assertEqual(trace["prediction_type"], "v_prediction")
        self.assertEqual(trace["prediction_type_source"], "synthetic_test")
        self.assertEqual(trace["sigma_used_for_prediction"], [4.5])
        self.assertEqual(trace["model_timestep"], [777.0])
        self.assertEqual(trace["cfg_scale"], 6.0)
        self.assertEqual(trace["cfg_rescale"], 0.25)
        self.assertEqual(trace["cfg_branch_order"], ["unconditional", "conditional", "guided"])
        self.assertEqual(trace["solver_dtype"], "torch.float32")

    def test_dpm_sampler_consumes_canonical_x0_and_never_calls_epsilon_callback(self) -> None:
        sampler = DPMPlusPlus2MSampler()
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([900.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )
        conditioning = type(
            "Conditioning",
            (),
            {
                "cond": torch.ones((1, 1, 1)),
                "uncond": torch.zeros((1, 1, 1)),
                "extra": {},
            },
        )()
        request = GenerationRequest(
            positive_prompt="canonical x0",
            steps=2,
            cfg_scale=7.0,
            sampler_kwargs={"solver_dtype": "float32"},
        )
        called_samples: list[torch.Tensor] = []

        def guided_model_fn(*args, **kwargs):
            raise AssertionError("epsilon callback must not be called by DPM++ 2M")

        def predict_denoised(sample, sigma, timestep, cond, uncond, cfg_scale):
            del sigma, timestep, cond, uncond, cfg_scale
            called_samples.append(sample.detach().clone())
            return sample.float()

        guided_model_fn.predict_denoised = predict_denoised
        guided_model_fn.denoising_contract = lambda: {
            "prediction_type": "epsilon",
            "prediction_conversion": "canonical test x0",
            "model_input_preconditioning": "test",
            "cfg_rescale": 0.0,
            "model_dtype": "torch.float16",
        }

        initial = torch.ones((1, 1, 1, 1), dtype=torch.float16)
        output = sampler.sample(
            raw_model_fn=None,
            guided_model_fn=guided_model_fn,
            latents=initial,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
        )
        self.assertEqual(len(called_samples), 2)
        self.assertTrue(all(item.dtype == torch.float32 for item in called_samples))
        self.assertTrue(torch.equal(output.latents, initial))
        self.assertEqual(
            output.extra["integration_prediction_type"],
            "canonical_predicted_x0",
        )

    def test_manifest_records_phase08c_contract_fields(self) -> None:
        request = GenerationRequest(
            positive_prompt="manifest",
            steps=2,
            cfg_scale=7.5,
            cfg_rescale=0.2,
            seed=123,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([3.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 100.0]),
            requested_steps=2,
            effective_steps=2,
        )
        sampler = SamplerOutput(
            latents=torch.zeros((1, 4, 2, 2)),
            extra={
                "effective_steps": 2,
                "sigma_used_for_prediction": [3.0, 1.0],
                "model_timestep": [999.0, 100.0],
            },
        )
        result = GenerationResult(
            request=request,
            latents=sampler.latents,
            schedule=schedule,
            sampler=sampler,
            metadata={
                "denoising_contract": {
                    "prediction_type": "epsilon",
                    "prediction_conversion": "x0 = solver_sample - sigma * guided_epsilon",
                    "model_input_preconditioning": "sample / sqrt(sigma^2 + 1)",
                    "cfg_rescale": 0.2,
                    "model_dtype": "torch.float16",
                    "solver_dtype": "torch.float32",
                }
            },
        )
        manifest = OutputSystem().build_manifest(
            request=request,
            extras={"model_path": "model.safetensors"},
            pipeline_result=result,
        )
        self.assertIsInstance(manifest, GenerationManifest)
        self.assertEqual(manifest.extra["prediction_type"], "epsilon")
        self.assertEqual(manifest.extra["cfg_scale"], 7.5)
        self.assertEqual(manifest.extra["cfg_rescale"], 0.2)
        self.assertEqual(manifest.extra["model_dtype"], "torch.float16")
        self.assertEqual(manifest.extra["solver_dtype"], "torch.float32")
        self.assertEqual(manifest.extra["sigma_used_for_prediction"], [3.0, 1.0])
        self.assertEqual(manifest.extra["model_timestep"], [999.0, 100.0])
        self.assertEqual(manifest.optional_for_rerun.guidance_rescale, 0.2)


if __name__ == "__main__":
    unittest.main()


    def test_guided_epsilon_adapter_reuses_guided_model_fn_path(self) -> None:
        unet = RecordingUNet(output_mode="zero", dtype=torch.float16)
        denoiser = DenoisingSystem(unet, prediction_type="epsilon")
        calls: list[torch.Tensor] = []

        def guided_model_fn(sample, sigma, timestep, cond, uncond, cfg_scale):
            del sigma, timestep, cond, uncond, cfg_scale
            calls.append(sample.detach().clone())
            return torch.full_like(sample, 2.0)

        adapter = denoiser.build_guided_epsilon_denoiser(guided_model_fn)
        solver_sample = torch.full((1, 1, 1, 1), 10.0, dtype=torch.float32)
        result = adapter(
            solver_sample,
            sigma=torch.tensor(3.0),
            timestep=torch.tensor(999.0),
            cond=torch.ones((1, 1, 1), dtype=torch.float16),
            uncond=torch.zeros((1, 1, 1), dtype=torch.float16),
            cfg_scale=7.0,
        )

        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0].dtype, torch.float16)
        self.assertEqual(result.dtype, torch.float32)
        self.assertTrue(torch.equal(result, torch.full_like(result, 4.0)))

    def test_guided_epsilon_adapter_contract_reports_epsilon_boundary(self) -> None:
        unet = RecordingUNet(output_mode="zero", dtype=torch.float16)
        denoiser = DenoisingSystem(
            unet,
            prediction_type="v_prediction",
            prediction_type_source="synthetic_test",
        )
        denoiser.configure_request(cfg_rescale=0.3)
        contract = denoiser.guided_epsilon_contract_metadata()
        self.assertEqual(contract["prediction_type"], "epsilon")
        self.assertEqual(
            contract["prediction_conversion"],
            "x0 = solver_sample - sigma * guided_epsilon",
        )
        self.assertEqual(
            contract["prediction_type_source"],
            "guided_epsilon_adapter_from_synthetic_test",
        )
        self.assertEqual(contract["cfg_rescale"], 0.3)
        self.assertEqual(contract["adapter_source"], "guided_model_fn")
