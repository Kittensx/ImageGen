from __future__ import annotations

import unittest

import torch

from image_gen.contracts import ConditioningOutput, GenerationRequest, SchedulerOutput
from modules.pipeline.step_trace_recorder import StepTraceRecorder, TraceRequest
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSampler,
)


class Phase08DFirstOrderValidationTests(unittest.TestCase):
    @staticmethod
    def _schedule() -> SchedulerOutput:
        return SchedulerOutput(
            sigmas=torch.tensor([4.0, 2.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 700.0, 100.0, 0.0]),
            requested_steps=3,
            effective_steps=3,
            compatibility_mode="fixed_steps",
        )

    @staticmethod
    def _conditioning(dtype: torch.dtype = torch.float32) -> ConditioningOutput:
        return ConditioningOutput(
            cond=torch.ones((1, 2, 3), dtype=dtype),
            uncond=torch.zeros((1, 2, 3), dtype=dtype),
        )

    @staticmethod
    def _guided_callbacks(epsilon_value: float = 0.125):
        calls = {"epsilon": 0, "canonical": 0, "canonical_dtypes": []}

        def guided(sample, sigma, timestep, cond, uncond, cfg_scale):
            del sigma, timestep, cond, uncond, cfg_scale
            calls["epsilon"] += 1
            return torch.full_like(sample, epsilon_value)

        def predict_denoised(sample, sigma, timestep, cond, uncond, cfg_scale):
            del timestep, cond, uncond, cfg_scale
            calls["canonical"] += 1
            calls["canonical_dtypes"].append(sample.dtype)
            return sample.float() - sigma.float() * epsilon_value

        guided.predict_denoised = predict_denoised
        guided.denoising_contract = lambda: {
            "prediction_type": "epsilon",
            "prediction_conversion": "x0 = solver_sample - sigma * guided_epsilon",
            "model_input_preconditioning": "sample / sqrt(sigma^2 + 1)",
            "cfg_rescale": 0.0,
            "model_dtype": "torch.float16",
            "solver_dtype": "torch.float32",
        }
        return guided, calls

    def _request(
        self,
        *,
        prediction_mode: str = "canonical_predicted_x0",
        recorder: StepTraceRecorder | None = None,
    ) -> GenerationRequest:
        kwargs = {
            "solver_dtype": "float32",
            "history_policy": "first_order_only",
            "prediction_mode": prediction_mode,
        }
        if prediction_mode == "legacy_sampler_local_epsilon":
            kwargs["phase08d_validation_mode"] = True
        if recorder is not None:
            kwargs["trace_recorder"] = recorder
        return GenerationRequest(
            positive_prompt="phase 8d",
            steps=3,
            cfg_scale=7.0,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
            sampler_kwargs=kwargs,
        )

    def test_first_order_only_never_accepts_or_reads_history(self) -> None:
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        guided, _ = self._guided_callbacks()
        result = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=torch.ones((1, 4, 2, 2)),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=self._request(recorder=recorder),
        )

        self.assertEqual(result.extra["history_policy"], "first_order_only")
        self.assertFalse(result.extra["history_enabled"])
        self.assertEqual(result.extra["history_state_read_count"], 0)
        self.assertEqual(result.extra["second_order_update_count"], 0)
        self.assertEqual(result.extra["first_order_update_count"], 2)
        self.assertEqual(result.extra["terminal_update_count"], 1)
        self.assertEqual(
            [record.extra["update_order"] for record in recorder.records],
            ["first_order", "first_order", "terminal_denoised"],
        )
        self.assertTrue(
            all(not record.extra["history_accepted"] for record in recorder.records)
        )
        self.assertTrue(
            all(not record.extra["used_old_denoised"] for record in recorder.records)
        )

    def test_first_order_update_ignores_supplied_history_objects(self) -> None:
        sampler = DPMPlusPlus2MSampler()
        sample = torch.tensor([[[[2.0]]]], dtype=torch.float32)
        denoised = torch.tensor([[[[0.5]]]], dtype=torch.float32)
        result = sampler._dpmpp_2m_update(
            x=sample,
            denoised=denoised,
            old_denoised=object(),  # would fail if read
            previous_t=object(),  # would fail if read
            sigma=torch.tensor(2.0),
            sigma_next=torch.tensor(1.0),
            history_policy="first_order_only",
        )
        h = -torch.log(torch.tensor(1.0)) - (-torch.log(torch.tensor(2.0)))
        expected = 0.5 * sample - torch.expm1(-h) * denoised
        self.assertTrue(torch.allclose(result, expected))

    def test_canonical_and_legacy_first_order_conversions_are_independent(self) -> None:
        initial = torch.full((1, 4, 2, 2), 0.75)
        canonical_guided, canonical_calls = self._guided_callbacks()
        canonical = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=canonical_guided,
            latents=initial.clone(),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=self._request(),
        )
        legacy_guided, legacy_calls = self._guided_callbacks()
        legacy = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=legacy_guided,
            latents=initial.clone(),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=self._request(prediction_mode="legacy_sampler_local_epsilon"),
        )

        self.assertEqual(canonical_calls["epsilon"], 0)
        self.assertEqual(canonical_calls["canonical"], 3)
        self.assertEqual(legacy_calls["epsilon"], 3)
        self.assertEqual(legacy_calls["canonical"], 0)
        self.assertTrue(torch.equal(canonical.latents, legacy.latents))
        self.assertEqual(
            canonical.extra["integration_prediction_type"],
            "canonical_predicted_x0",
        )
        self.assertEqual(
            legacy.extra["integration_prediction_type"],
            "legacy_sampler_local_epsilon",
        )

    def test_legacy_mode_is_restricted_to_phase08d_first_order_validation(self) -> None:
        request = GenerationRequest(
            positive_prompt="restricted",
            steps=3,
            sampler_kwargs={"prediction_mode": "legacy_sampler_local_epsilon"},
        )
        with self.assertRaisesRegex(ValueError, "diagnostic-only"):
            DPMPlusPlus2MSampler._resolve_prediction_mode(request, "multistep")

    def test_terminal_zero_returns_predicted_x0(self) -> None:
        sampler = DPMPlusPlus2MSampler()
        sample = torch.full((1, 1, 1, 1), 9.0)
        denoised = torch.full((1, 1, 1, 1), 1.25)
        result = sampler._dpmpp_2m_update(
            x=sample,
            denoised=denoised,
            old_denoised=None,
            previous_t=None,
            sigma=torch.tensor(1.0),
            sigma_next=torch.tensor(0.0),
            history_policy="first_order_only",
        )
        self.assertTrue(torch.equal(result, denoised))

    def test_float32_solver_returns_to_input_dtype_only_at_boundary(self) -> None:
        guided, calls = self._guided_callbacks()
        initial = torch.full((1, 4, 2, 2), 0.5, dtype=torch.float16)
        result = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=initial,
            schedule=self._schedule(),
            conditioning=self._conditioning(dtype=torch.float16),
            request=self._request(),
        )
        self.assertTrue(all(dtype == torch.float32 for dtype in calls["canonical_dtypes"]))
        self.assertEqual(result.extra["solver_dtype"], "torch.float32")
        self.assertEqual(result.extra["solver_state_return_dtype"], "torch.float16")
        self.assertEqual(result.latents.dtype, torch.float16)

    def test_trace_records_difference_from_euler_reference(self) -> None:
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        request = self._request(recorder=recorder)
        reference = {
            0: torch.full((1, 4, 2, 2), 0.25),
            1: torch.full((1, 4, 2, 2), 0.5),
            2: torch.full((1, 4, 2, 2), 0.75),
        }
        setattr(request, "_phase08d_euler_reference_latents", reference)
        guided, _ = self._guided_callbacks()
        DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=torch.ones((1, 4, 2, 2)),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=request,
        )
        for record in recorder.records:
            comparison = record.extra["difference_from_euler_reference"]
            self.assertTrue(comparison["available"])
            self.assertIsNotNone(comparison["difference_norm"])

    def test_validation_matrix_builds_locked_legacy_and_canonical_requests(self) -> None:
        from pathlib import Path

        from scripts.validation.phase08d_first_order import build_request

        case = {
            "case_id": "synthetic",
            "prompt": "test",
            "negative_prompt": "",
            "seed": 123,
            "width": 64,
            "height": 64,
            "steps": 3,
            "cfg_scale": 7.0,
        }
        legacy = build_request(
            case=case,
            scheduler_name="simple_kes",
            variant="dpm_first_order_legacy",
            run_dir=Path("artifacts/legacy"),
            save_images=False,
        )
        canonical = build_request(
            case=case,
            scheduler_name="simple_kes",
            variant="dpm_first_order_canonical",
            run_dir=Path("artifacts/canonical"),
            save_images=False,
        )
        self.assertEqual(legacy.sampler_kwargs["history_policy"], "first_order_only")
        self.assertTrue(legacy.sampler_kwargs["phase08d_validation_mode"])
        self.assertEqual(
            legacy.sampler_kwargs["prediction_mode"],
            "legacy_sampler_local_epsilon",
        )
        self.assertEqual(
            canonical.sampler_kwargs["prediction_mode"],
            "canonical_predicted_x0",
        )
        self.assertNotIn("phase08d_validation_mode", canonical.sampler_kwargs)
        self.assertTrue(
            canonical.diagnostics["sampler_trace"]["predicted_x0_previews"]
        )

    def test_fixed_inputs_are_repeatable(self) -> None:
        initial = torch.full((1, 4, 2, 2), 0.625)
        outputs = []
        for _ in range(2):
            guided, _ = self._guided_callbacks()
            outputs.append(
                DPMPlusPlus2MSampler().sample(
                    raw_model_fn=None,
                    guided_model_fn=guided,
                    latents=initial.clone(),
                    schedule=self._schedule(),
                    conditioning=self._conditioning(),
                    request=self._request(),
                ).latents
            )
        self.assertTrue(torch.equal(outputs[0], outputs[1]))


if __name__ == "__main__":
    unittest.main()
