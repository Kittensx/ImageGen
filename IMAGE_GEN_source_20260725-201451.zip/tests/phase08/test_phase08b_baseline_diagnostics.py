from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import torch

from image_gen.contracts import ConditioningOutput, GenerationRequest, SchedulerOutput
from image_gen.runtime import PipelineCompositionRoot
from image_gen.systems.diagnostics import DiagnosticConfig, DiagnosticsSystem
from modules.pipeline.step_trace_recorder import StepTraceRecorder, TraceRequest
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSampler,
    DPMPlusPlus2MSamplerAdapter,
)
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
)
from tests.fakes.deterministic_systems import fake_components


class _FailFirstDecode:
    def __init__(self, base) -> None:
        self.base = base
        self.calls = 0

    def decode(self, latents: torch.Tensor) -> torch.Tensor:
        self.calls += 1
        if self.calls == 1:
            raise RuntimeError("intentional preview decode failure")
        return self.base.decode(latents)


class Phase08BBaselineDiagnosticsTests(unittest.TestCase):
    @staticmethod
    def _schedule() -> SchedulerOutput:
        return SchedulerOutput(
            sigmas=torch.tensor([53.0, 30.0, 10.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 999.0, 500.0, 100.0, 0.0]),
            requested_steps=4,
            effective_steps=4,
            compatibility_mode="fixed_steps",
            metadata={"scheduler_name": "simple_kes", "native_sigma_max": 53.0},
        )

    @staticmethod
    def _conditioning() -> ConditioningOutput:
        return ConditioningOutput(
            cond=torch.ones((1, 2, 3), dtype=torch.float32),
            uncond=torch.zeros((1, 2, 3), dtype=torch.float32),
        )

    @staticmethod
    def _guided_with_trace():
        from image_gen.systems.denoising import DenoisingSystem
        from tests.phase00.fakes import FakeUNet

        denoising = DenoisingSystem(FakeUNet())
        denoising.set_guidance_trace_enabled(True)

        def guided(x, sigma, timestep, cond, uncond, cfg_scale):
            return denoising.predict_guided_noise(
                x, sigma, timestep, cond, uncond, cfg_scale
            )

        guided.predict_denoised = denoising.predict_denoised
        guided.consume_guidance_trace = denoising.consume_guidance_trace
        guided.denoising_contract = denoising.contract_metadata
        return guided

    def test_trace_is_optional_and_does_not_change_sampler_result(self) -> None:
        sampler = DPMPlusPlus2MSampler()
        latents = torch.full((1, 4, 2, 2), 0.25)
        common = dict(
            positive_prompt="phase 8b",
            steps=4,
            cfg_scale=7.0,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
            sampler_kwargs={"solver_dtype": "float32"},
        )
        without_trace = sampler.sample(
            raw_model_fn=None,
            guided_model_fn=self._guided_with_trace(),
            latents=latents.clone(),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=GenerationRequest(**common),
        )
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        traced_request = GenerationRequest(**common)
        traced_request.sampler_kwargs["trace_recorder"] = recorder
        with_trace = sampler.sample(
            raw_model_fn=None,
            guided_model_fn=self._guided_with_trace(),
            latents=latents.clone(),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=traced_request,
        )

        self.assertTrue(torch.equal(without_trace.latents, with_trace.latents))
        self.assertEqual(len(recorder.records), 4)

    def test_every_step_contains_phase08b_required_diagnostics(self) -> None:
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        request = GenerationRequest(
            positive_prompt="phase 8b diagnostics",
            steps=4,
            cfg_scale=7.0,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
            sampler_kwargs={
                "solver_dtype": "float32",
                "history_policy": "multistep",
                "trace_recorder": recorder,
            },
        )
        DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=self._guided_with_trace(),
            latents=torch.full((1, 4, 2, 2), 0.25),
            schedule=self._schedule(),
            conditioning=self._conditioning(),
            request=request,
        )

        required = {
            "timestep",
            "model_input",
            "solver_latent_before",
            "unconditional_model_output",
            "conditional_model_output",
            "guided_model_output",
            "prediction_type",
            "predicted_x0",
            "predicted_x0_comparison",
            "update_order",
            "history_accepted",
            "history_rejection_reason",
            "solver_latent_after",
            "finite_status",
        }
        for record in recorder.records:
            self.assertTrue(required.issubset(record.extra))
            self.assertTrue(record.extra["model_input"]["all_finite"])
            self.assertTrue(record.extra["predicted_x0"]["all_finite"])

        self.assertEqual(recorder.records[0].extra["update_order"], "first_order")
        self.assertFalse(recorder.records[0].extra["history_accepted"])
        self.assertTrue(recorder.records[1].extra["repeated_model_timestep"])
        self.assertEqual(recorder.records[1].extra["update_order"], "second_order")
        self.assertTrue(recorder.records[1].extra["history_accepted"])
        self.assertIsNotNone(
            recorder.records[1].extra["predicted_x0_comparison"]["cosine_similarity"]
        )

    def test_trace_metadata_is_strict_json_serializable(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            recorder = StepTraceRecorder(
                request=TraceRequest(
                    enabled=True,
                    export_json=True,
                    export_txt_summary=False,
                    output_dir=temp_dir,
                )
            )
            request = GenerationRequest(
                positive_prompt="serialization",
                steps=4,
                cfg_scale=7.0,
                sampler_kwargs={
                    "solver_dtype": "float32",
                    "trace_recorder": recorder,
                },
            )
            DPMPlusPlus2MSampler().sample(
                raw_model_fn=None,
                guided_model_fn=self._guided_with_trace(),
                latents=torch.full((1, 4, 2, 2), 0.25),
                schedule=self._schedule(),
                conditioning=self._conditioning(),
                request=request,
            )
            path = Path(recorder.export_requested_artifacts()["json"])
            payload = json.loads(path.read_text(encoding="utf-8"))
            json.dumps(payload, allow_nan=False)

    def test_predicted_x0_capture_uses_denoised_not_updated_solver_latent(self) -> None:
        recorder = StepTraceRecorder(
            request=TraceRequest(
                enabled=True,
                export_txt_summary=False,
                capture_latents=True,
                capture_latent_every_n=1,
                capture_predicted_x0_previews=True,
                predicted_x0_preview_steps=(0,),
            )
        )
        request = GenerationRequest(
            positive_prompt="preview source",
            steps=2,
            cfg_scale=1.0,
            sampler_kwargs={"trace_recorder": recorder, "solver_dtype": "float32"},
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([2.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 500.0, 0.0]),
            requested_steps=2,
            effective_steps=2,
        )

        def guided(x, sigma, timestep, cond, uncond, cfg_scale):
            del sigma, timestep, cond, uncond, cfg_scale
            return torch.full_like(x, 0.25)

        def predict_denoised(x, sigma, timestep, cond, uncond, cfg_scale):
            del timestep, cond, uncond, cfg_scale
            return x.float() - sigma.float() * 0.25

        guided.predict_denoised = predict_denoised
        guided.denoising_contract = lambda: {
            "prediction_type": "epsilon",
            "prediction_conversion": "test canonical epsilon to x0",
            "model_input_preconditioning": "test",
            "cfg_rescale": 0.0,
        }

        DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=torch.ones((1, 4, 2, 2)),
            schedule=schedule,
            conditioning=self._conditioning(),
            request=request,
        )
        captured = recorder.predicted_x0_latents[0]
        expected_denoised = torch.full_like(captured, 0.5)
        self.assertTrue(torch.equal(captured, expected_denoised))
        self.assertFalse(torch.equal(captured, recorder.latents[0]))

    def test_automatic_preview_selection_captures_plateau_boundaries(self) -> None:
        selected, metadata = DiagnosticsSystem._select_predicted_x0_preview_steps(
            SchedulerOutput(
                sigmas=torch.tensor([53.0, 45.0, 35.0, 20.0, 5.0, 1.0, 0.0]),
                timesteps=torch.tensor([999.0, 999.0, 999.0, 700.0, 400.0, 100.0, 0.0]),
                requested_steps=6,
                effective_steps=6,
            )
        )
        self.assertEqual(selected, [0, 2, 3, 4])
        self.assertIn("last_repeated_initial_timestep", metadata["labels"]["2"])
        self.assertIn("first_distinct_timestep_after_plateau", metadata["labels"]["3"])
        self.assertIn("penultimate_step", metadata["labels"]["4"])

    def test_selected_predicted_x0_previews_are_saved_separately(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            components = fake_components()
            diagnostics = DiagnosticsSystem(
                DiagnosticConfig.from_mapping(
                    {"progress": False}, artifacts_root=Path(temp_dir)
                )
            )
            pipeline = PipelineCompositionRoot(
                components=components,
                prompt_adapter=FakePromptAdapter(),
                scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
                sampler_adapter=DPMPlusPlus2MSamplerAdapter(),
                device=torch.device("cpu"),
                dtype=torch.float32,
                vae_scaling_factor=1.0,
                system_overrides={"diagnostics": diagnostics},
            ).build()
            trace_dir = Path(temp_dir) / "phase08b_case" / "traces"
            request = GenerationRequest(
                positive_prompt="preview persistence",
                width=32,
                height=32,
                steps=3,
                cfg_scale=2.0,
                batch_size=1,
                seed=809,
                device=torch.device("cpu"),
                dtype=torch.float32,
                sampler_name="dpmpp_2m",
                scheduler_name="simple_kes",
                sampler_kwargs={"solver_dtype": "float32"},
                diagnostics={
                    "sampler_trace": {
                        "enabled": True,
                        "export_json": True,
                        "export_txt_summary": False,
                        "predicted_x0_previews": True,
                        "predicted_x0_steps": [0, 1],
                        "output_dir": str(trace_dir),
                    }
                },
            )
            result = pipeline.generate(request)

            preview_root = Path(result.trace_exports["predicted_x0_root"])
            manifest_path = Path(result.trace_exports["predicted_x0_manifest"])
            self.assertEqual(preview_root, trace_dir.parent / "predicted_x0")
            payload = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(
                [record["step_index"] for record in payload["records"]], [0, 1]
            )
            self.assertTrue(all(record["status"] == "saved" for record in payload["records"]))
            for record in payload["records"]:
                self.assertTrue(all(Path(item).is_file() for item in record["paths"]))

    def test_preview_decode_failure_does_not_block_final_decode(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            components = fake_components()
            diagnostics = DiagnosticsSystem(
                DiagnosticConfig.from_mapping(
                    {"progress": False}, artifacts_root=Path(temp_dir)
                )
            )
            base_root = PipelineCompositionRoot(
                components=components,
                prompt_adapter=FakePromptAdapter(),
                scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
                sampler_adapter=DPMPlusPlus2MSamplerAdapter(),
                device=torch.device("cpu"),
                dtype=torch.float32,
                vae_scaling_factor=1.0,
                system_overrides={"diagnostics": diagnostics},
            )
            base_systems = base_root.create_systems()
            failing_decode = _FailFirstDecode(base_systems.decoding)
            pipeline = PipelineCompositionRoot(
                components=components,
                prompt_adapter=FakePromptAdapter(),
                scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
                sampler_adapter=DPMPlusPlus2MSamplerAdapter(),
                device=torch.device("cpu"),
                dtype=torch.float32,
                vae_scaling_factor=1.0,
                system_overrides={
                    "diagnostics": diagnostics,
                    "decoding": failing_decode,
                },
            ).build()
            request = GenerationRequest(
                positive_prompt="preview failure resilience",
                negative_prompt="",
                width=32,
                height=32,
                steps=3,
                cfg_scale=2.0,
                batch_size=1,
                seed=808,
                device=torch.device("cpu"),
                dtype=torch.float32,
                sampler_name="dpmpp_2m",
                scheduler_name="simple_kes",
                sampler_kwargs={"solver_dtype": "float32"},
                diagnostics={
                    "sampler_trace": {
                        "enabled": True,
                        "export_json": True,
                        "export_txt_summary": False,
                        "predicted_x0_previews": True,
                        "predicted_x0_steps": [0],
                    }
                },
            )
            result = pipeline.generate(request)

            self.assertIsNotNone(result.images)
            self.assertEqual(failing_decode.calls, 2)
            manifest_path = Path(result.trace_exports["predicted_x0_manifest"])
            payload = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["records"][0]["status"], "failed")
            self.assertEqual(payload["errors"][0]["step_index"], 0)

    def test_finite_checks_distinguish_nan_and_both_infinities(self) -> None:
        stats = DPMPlusPlus2MSampler._tensor_trace_stats(
            torch.tensor([0.0, float("nan"), float("inf"), float("-inf")])
        )
        self.assertFalse(stats["all_finite"])
        self.assertEqual(stats["nan_count"], 1)
        self.assertEqual(stats["pos_inf_count"], 1)
        self.assertEqual(stats["neg_inf_count"], 1)
        json.dumps(stats, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
