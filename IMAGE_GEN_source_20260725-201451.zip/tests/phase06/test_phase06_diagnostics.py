from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from image_gen.systems.diagnostics import PipelineStageError
from tests.fakes.deterministic_systems import build_fake_pipeline, fake_request


class Phase06DiagnosticsTests(unittest.TestCase):
    def test_every_generation_failure_is_assigned_to_a_named_system(self) -> None:
        expected = {
            "conditioning": "conditioning",
            "scheduling": "scheduling",
            "latent_preparation": "latent_preparation",
            "denoising": "denoising",
            "sampling": "sampling",
            "decoding": "decoding",
            "runtime": "runtime",
        }
        with tempfile.TemporaryDirectory() as temp_dir:
            for requested, assigned in expected.items():
                with self.subTest(system=requested):
                    pipeline, _ = build_fake_pipeline(
                        Path(temp_dir) / requested,
                        diagnostics={"progress": False},
                        fail_system=requested,
                    )
                    with self.assertRaises(PipelineStageError) as raised:
                        pipeline.generate(fake_request())
                    error = raised.exception
                    self.assertEqual(error.system, assigned)
                    self.assertTrue(error.operation)
                    self.assertTrue(error.run_id)
                    self.assertIsNotNone(error.bundle_path)
                    self.assertTrue(Path(error.bundle_path).is_dir())

    def test_failure_bundle_contains_reproduction_context(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            pipeline, diagnostics = build_fake_pipeline(
                temp_dir,
                diagnostics={
                    "progress": False,
                    "tensor_summaries": True,
                    "tensor_statistics": True,
                },
                fail_system="sampling",
            )
            request = fake_request()
            session = diagnostics.start(
                request,
                effective_config={
                    "project_root": "C:/IMAGE_GEN",
                    "config_path": "C:/IMAGE_GEN/user_config/user-config.yml",
                },
                request_extras={"model_path": "models/test.safetensors"},
                components=pipeline.components,
            )
            with self.assertRaises(PipelineStageError) as raised:
                pipeline.generate(request, diagnostic_session=session)

            bundle = Path(raised.exception.bundle_path)
            required = {
                "failure.json",
                "request.json",
                "request_extras.json",
                "effective_config.json",
                "components.json",
                "schedule.json",
                "sampler.json",
                "timings.json",
                "tensor_summaries.json",
                "events.jsonl",
                "traceback.txt",
                "reproduction_request.json",
                "reproduce_command.txt",
            }
            self.assertTrue(required.issubset({path.name for path in bundle.iterdir()}))
            failure = json.loads((bundle / "failure.json").read_text(encoding="utf-8"))
            self.assertEqual(failure["system"], "sampling")
            reproduction = json.loads(
                (bundle / "reproduction_request.json").read_text(encoding="utf-8")
            )
            self.assertEqual(reproduction["seed"], 606)
            self.assertEqual(reproduction["model_path"], "models/test.safetensors")
            self.assertIn("modules.txt2img.cli run", (bundle / "reproduce_command.txt").read_text())

    def test_normal_run_is_quiet_and_trace_is_disabled_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            pipeline, _ = build_fake_pipeline(
                temp_dir,
                diagnostics={"progress": False},
                trace_aware_sampler=True,
            )
            stdout = io.StringIO()
            stderr = io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                result = pipeline.generate(fake_request())
            self.assertEqual(stdout.getvalue(), "")
            self.assertEqual(stderr.getvalue(), "")
            self.assertEqual(result.trace_exports, {})
            self.assertFalse(Path(temp_dir).exists() and any(Path(temp_dir).rglob("*")))

    def test_verbose_run_emits_structured_events_timings_and_tensor_summaries(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            pipeline, diagnostics = build_fake_pipeline(
                temp_dir,
                diagnostics={
                    "verbosity": "verbose",
                    "export_events": True,
                    "tensor_summaries": True,
                    "progress": False,
                },
            )
            stderr = io.StringIO()
            diagnostics.console = stderr
            result = pipeline.generate(fake_request())
            output = stderr.getvalue()
            self.assertIn("run_id=", output)
            self.assertIn("system=conditioning", output)
            self.assertIn("operation=encode", output)
            summary = result.metadata["diagnostics"]
            self.assertGreaterEqual(len(summary["timings"]), 7)
            self.assertIn("latent_preparation.latents", summary["tensor_summaries"])
            run_dir = Path(temp_dir) / "runs" / summary["run_id"]
            self.assertTrue((run_dir / "events.jsonl").is_file())
            self.assertTrue((run_dir / "run_summary.json").is_file())

    def test_sampler_trace_is_opt_in_and_writes_outside_source_folders(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            pipeline, _ = build_fake_pipeline(
                temp_dir,
                diagnostics={"progress": False},
                trace_aware_sampler=True,
            )
            request = fake_request(
                diagnostics={
                    "sampler_trace": {
                        "enabled": True,
                        "export_json": True,
                        "export_txt_summary": True,
                    }
                }
            )
            result = pipeline.generate(request)
            self.assertIn("json", result.trace_exports)
            self.assertIn("summary", result.trace_exports)
            for exported in result.trace_exports.values():
                path = Path(exported).resolve()
                self.assertTrue(path.is_file())
                self.assertIn(Path(temp_dir).resolve(), path.parents)

    def test_failure_bundles_can_be_disabled_explicitly(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            pipeline, _ = build_fake_pipeline(
                temp_dir,
                diagnostics={"failure_bundles": False, "progress": False},
                fail_system="conditioning",
            )
            with self.assertRaises(PipelineStageError) as raised:
                pipeline.generate(fake_request())
            self.assertIsNone(raised.exception.bundle_path)
            self.assertFalse(Path(temp_dir).exists() and any(Path(temp_dir).rglob("*")))


if __name__ == "__main__":
    unittest.main()
