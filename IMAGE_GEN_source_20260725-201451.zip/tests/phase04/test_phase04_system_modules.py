from __future__ import annotations

import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import torch

from image_gen.contracts import (
    ConditioningOutput,
    GenerationRequest,
    GenerationResult,
    PipelineComponents,
    SamplerOutput,
    SchedulerOutput,
)
from image_gen.runtime import CustomSDPipeline, PipelineCompositionRoot
from image_gen.systems.conditioning import ConditioningSystem
from image_gen.systems.decoding import DecodingSystem
from image_gen.systems.denoising import DenoisingSystem
from image_gen.systems.model_loading import ModelLoadingSystem
from image_gen.systems.output import OutputSystem
from image_gen.systems.registry import RuntimeRegistrySystem
from image_gen.systems.sampling import LatentPreparationSystem, SamplingSystem
from image_gen.systems.scheduling import SchedulingSystem
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeSampler,
    FakeSamplerAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
    FakeTextEncoder,
    FakeTokenizer,
    FakeUNet,
    FakeVAE,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


class RecordingProxy:
    def __init__(self, target: Any) -> None:
        self.target = target
        self.calls: list[str] = []

    def __getattr__(self, name: str):
        value = getattr(self.target, name)
        if not callable(value):
            return value

        def wrapped(*args, **kwargs):
            self.calls.append(name)
            return value(*args, **kwargs)

        return wrapped


class Phase04SystemExtractionTests(unittest.TestCase):
    @staticmethod
    def components() -> PipelineComponents:
        return PipelineComponents(
            unet=FakeUNet(),
            vae=FakeVAE(),
            text_encoder=FakeTextEncoder(),
            tokenizer=FakeTokenizer(),
        )

    @staticmethod
    def request() -> GenerationRequest:
        return GenerationRequest(
            positive_prompt="phase four",
            negative_prompt="",
            width=32,
            height=32,
            steps=3,
            cfg_scale=2.0,
            batch_size=1,
            seed=404,
            device=torch.device("cpu"),
            dtype=torch.float32,
            sampler_name="fake",
            scheduler_name="fake",
        )

    def test_contracts_moved_and_old_imports_are_identity_facades(self) -> None:
        from image_gen.contracts import GenerationRequest as CanonicalRequest
        from modules.contracts import GenerationRequest as OldRequest
        from modules.contracts.runtime import GenerationResult as OldResult
        from modules.pipeline_builder import CustomSDPipeline as OldPipeline

        self.assertIs(OldRequest, CanonicalRequest)
        self.assertIs(OldResult, GenerationResult)
        self.assertIs(OldPipeline, CustomSDPipeline)
        self.assertEqual(CanonicalRequest.__module__, "image_gen.contracts.runtime")

    def test_conditioning_and_scheduling_systems_validate_adapter_boundaries(self) -> None:
        components = self.components()
        request = self.request()
        conditioning = ConditioningSystem(FakePromptAdapter()).encode(components, request)
        schedule = SchedulingSystem(FakeSchedulerAdapter(FakeScheduler())).build(request)
        self.assertIsInstance(conditioning, ConditioningOutput)
        self.assertEqual(schedule.sigma_transitions, request.steps)

        class BadPrompt:
            def encode(self, components, request, state=None):
                return {"cond": 1}

        with self.assertRaises(TypeError):
            ConditioningSystem(BadPrompt()).encode(components, request)

    def test_denoising_and_decoding_are_independent_of_orchestration(self) -> None:
        unet = FakeUNet()
        denoising = DenoisingSystem(unet)
        latents = torch.ones((1, 4, 4, 4))
        cond = torch.ones((1, 8, 4))
        epsilon = denoising.predict_raw_noise(latents, 1.0, 500.0, cond)
        self.assertEqual(epsilon.shape, latents.shape)
        self.assertEqual(len(unet.calls), 1)

        images = DecodingSystem(FakeVAE(), vae_scaling_factor=1.0).decode(latents)
        self.assertEqual(tuple(images.shape), (1, 3, 32, 32))

    def test_latent_preparation_and_sampling_are_independent_systems(self) -> None:
        request = self.request()
        schedule = FakeScheduler().build(request.steps, torch.device("cpu"), torch.float32)
        latents = LatentPreparationSystem(
            latent_scale_factor=8,
            device=torch.device("cpu"),
            dtype=torch.float32,
        ).prepare(request, schedule)
        conditioning = ConditioningOutput(
            cond=torch.ones((1, 8, 4)),
            uncond=torch.zeros((1, 8, 4)),
        )
        denoiser = DenoisingSystem(FakeUNet())
        sampled = SamplingSystem(FakeSamplerAdapter(FakeSampler())).sample(
            raw_model_fn=denoiser.predict_raw_noise,
            guided_model_fn=denoiser.predict_guided_noise,
            latents=latents,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
        )
        self.assertIsInstance(sampled, SamplerOutput)
        self.assertEqual(sampled.latents.shape, latents.shape)

    def test_composition_root_can_replace_every_generation_system(self) -> None:
        system_names = {
            "conditioning": "encode",
            "scheduling": "build",
            "latent_preparation": "prepare",
            "denoising": "predict_guided_noise",
            "sampling": "sample",
            "decoding": "decode",
            "diagnostics": "start",
        }
        for system_name, expected_call in system_names.items():
            with self.subTest(system=system_name):
                root = PipelineCompositionRoot(
                    components=self.components(),
                    prompt_adapter=FakePromptAdapter(),
                    scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
                    sampler_adapter=FakeSamplerAdapter(FakeSampler()),
                    device=torch.device("cpu"),
                    dtype=torch.float32,
                    vae_scaling_factor=1.0,
                )
                base = root.create_systems()
                proxy = RecordingProxy(getattr(base, system_name))
                pipeline = PipelineCompositionRoot(
                    components=self.components(),
                    prompt_adapter=FakePromptAdapter(),
                    scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
                    sampler_adapter=FakeSamplerAdapter(FakeSampler()),
                    device=torch.device("cpu"),
                    dtype=torch.float32,
                    vae_scaling_factor=1.0,
                    system_overrides={system_name: proxy},
                ).build()
                result = pipeline.generate(self.request())
                self.assertEqual(tuple(result.images.shape), (1, 3, 32, 32))
                self.assertIn(expected_call, proxy.calls)

    def test_registry_system_resolves_entries_and_constructs_adapter(self) -> None:
        module_name = "tests.phase04._temporary_registry_plugin"
        module = types.ModuleType(module_name)

        class TempAdapter:
            def __init__(self, state=None):
                self.state = state

        module.TempAdapter = TempAdapter
        sys.modules[module_name] = module
        try:
            registry = RuntimeRegistrySystem(state="phase04-state")
            entry = {
                "id": "temp",
                "name": "temp_sampler",
                "label": "Temporary",
                "module": module_name,
                "adapter_class": "TempAdapter",
            }
            resolved = registry.resolve_entry("Temporary", {"temp": entry}, kind="sampler")
            self.assertIs(resolved, entry)
            adapter = registry.instantiate_adapter(resolved)
            self.assertEqual(adapter.state, "phase04-state")
        finally:
            sys.modules.pop(module_name, None)

    def test_model_loading_system_delegates_without_changing_loader_order(self) -> None:
        call_order: list[str] = []
        components = self.components()
        built = SimpleNamespace(
            unet=components.unet,
            vae=components.vae,
            text_encoder=components.text_encoder,
            unet_result=SimpleNamespace(success=True, error=None),
            text_encoder_result=SimpleNamespace(success=True, error=None),
            vae_result=SimpleNamespace(success=True, error=None),
        )

        class FakeLoader:
            MODEL_PATH = "default.safetensors"

            def prepare_load_plan(self, model_path):
                call_order.append(f"plan:{model_path}")
                return "plan"

            def build_components_from_plan(self, plan, dtype=None):
                call_order.append(f"build:{plan}:{dtype}")
                return built

        loaded = ModelLoadingSystem(FakeLoader()).load(
            "model.safetensors",
            tokenizer=components.tokenizer,
            dtype=torch.float32,
        )
        self.assertEqual(call_order, ["plan:model.safetensors", "build:plan:torch.float32"])
        self.assertIs(loaded.components.unet, components.unet)

    def test_output_system_is_the_only_file_writer(self) -> None:
        request = self.request()
        result = GenerationResult(
            request=request,
            images=torch.zeros((1, 3, 32, 32)),
            latents=torch.zeros((1, 4, 4, 4)),
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            records = OutputSystem().save(
                pipeline_result=result,
                request=request,
                manifest=None,
                output_dir=temp_dir,
                save_txt=False,
                save_json=False,
            )
            self.assertEqual(len(records), 1)
            self.assertTrue(Path(records[0].image_path).is_file())


    def test_txt2img_runner_is_a_use_case_coordinator_with_injected_systems(self) -> None:
        from image_gen.runtime.txt2img_runner import Txt2ImgRunner

        components = self.components()

        class FakeContext:
            txt2img_output_root = PROJECT_ROOT / "artifacts" / "phase04_test"

            def require_generation_ready(self, **kwargs):
                self.validation_kwargs = kwargs

        class FakeModelLoading:
            default_model_path = "fake-model.safetensors"

            def load(self, model_path, *, tokenizer, dtype=None):
                self.call = (model_path, tokenizer, dtype)
                return SimpleNamespace(components=components)

        class FakeOutput:
            def build_manifest(self, **kwargs):
                self.build_kwargs = kwargs
                return {"phase": 4}

            def save(self, **kwargs):
                raise AssertionError("save must not be called when save_images is false")

        context = FakeContext()
        model_system = FakeModelLoading()
        output_system = FakeOutput()
        runner = Txt2ImgRunner(
            prompt_adapter=FakePromptAdapter(),
            scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
            sampler_adapter=FakeSamplerAdapter(FakeSampler()),
            model_loader=SimpleNamespace(context=context),
            project_context=context,
            tokenizer=components.tokenizer,
            device=torch.device("cpu"),
            dtype=torch.float32,
            vae_scaling_factor=1.0,
            model_loading_system=model_system,
            output_system=output_system,
        )
        result = runner.run_request(
            self.request(),
            {"model_path": "fake-model.safetensors"},
            save_images=False,
        )
        self.assertEqual(tuple(result.pipeline_result.images.shape), (1, 3, 32, 32))
        self.assertEqual(result.manifest, {"phase": 4})
        self.assertEqual(model_system.call[0], "fake-model.safetensors")
        self.assertFalse(result.saved_records)

    def test_core_runtime_import_does_not_pull_registry_output_or_model_loading(self) -> None:
        code = (
            "import sys; "
            "from modules.pipeline_builder import CustomSDPipeline; "
            "blocked=['image_gen.systems.registry.system','image_gen.systems.output.system',"
            "'image_gen.systems.model_loading.system']; "
            "assert not [x for x in blocked if x in sys.modules], [x for x in blocked if x in sys.modules]"
        )
        completed = subprocess.run(
            [sys.executable, "-c", code],
            cwd=PROJECT_ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr or completed.stdout)


if __name__ == "__main__":
    unittest.main()
