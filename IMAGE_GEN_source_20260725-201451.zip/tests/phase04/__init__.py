"""Focused Phase 04 system-extraction tests."""
