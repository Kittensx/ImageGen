from __future__ import annotations

import importlib.util
import random
import unittest
from pathlib import Path
from types import SimpleNamespace

from image_gen.systems.output import OutputSystem
from modules.generation_test import build_command, build_parser
from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.sampler_advanced import (
    SamplerAdvanced,
)


PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Phase00BaselineRepairTests(unittest.TestCase):
    def test_checkpoint_compatibility_launcher_builds_canonical_command(self) -> None:
        args = build_parser().parse_args(["--model", "model.safetensors"])
        command = build_command(args)
        self.assertIn("scripts/tests/run_test_tier.py", command[1].replace("\\", "/"))
        self.assertIn("checkpoint", command)
        self.assertIn("model.safetensors", command)

    def test_archived_sampler_helper_is_importable_and_deterministic_when_seeded(self) -> None:
        cfg = SimpleNamespace(
            heun_blend_style="adaptive_step",
            heun_adaptive_curve="linear",
            heun_blend_weight=0.5,
            settings={},
        )
        helper = SamplerAdvanced(sampler_state=SimpleNamespace(cfg=cfg))
        self.assertAlmostEqual(helper.resolve_heun_blend_weight(2, 4), 0.5)
        left = helper.resolve_randomized_value(0.5, 0.0, 1.0, 0.1, rng=random.Random(7))
        right = helper.resolve_randomized_value(0.5, 0.0, 1.0, 0.1, rng=random.Random(7))
        self.assertEqual(left, right)

    def test_research_sketch_is_utf8_and_compiles(self) -> None:
        path = PROJECT_ROOT / "docs" / "ideas" / "more_mem_optim.py"
        source = path.read_text(encoding="utf-8")
        compile(source, str(path), "exec")

    def test_output_system_boundary_is_present(self) -> None:
        self.assertTrue(callable(OutputSystem))
        spec = importlib.util.find_spec("image_gen.systems.output.system")
        self.assertIsNotNone(spec)


if __name__ == "__main__":
    unittest.main()
