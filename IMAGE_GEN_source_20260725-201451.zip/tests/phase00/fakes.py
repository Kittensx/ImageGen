from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any, Optional

import torch
import torch.nn.functional as functional

from modules.contracts import (
    ConditioningOutput,
    GenerationRequest,
    SamplerOutput,
    SchedulerOutput,
)


class InjectedFailure(RuntimeError):
    """Raised by a fake component when a named failure is requested."""


class FakeTokenizer:
    """Small deterministic tokenizer used only by the Phase 00 harness."""

    model_max_length = 8

    def __init__(self, fail_stage: Optional[str] = None) -> None:
        self.fail_stage = fail_stage

    def __call__(
        self,
        text: str,
        *,
        padding: str = "max_length",
        max_length: Optional[int] = None,
        truncation: bool = True,
        return_tensors: str = "pt",
        **_: Any,
    ) -> dict[str, torch.Tensor]:
        del padding, truncation, return_tensors
        if self.fail_stage == "conditioning.tokenizer":
            raise InjectedFailure("Injected tokenizer failure")

        length = int(max_length or self.model_max_length)
        values = [((ord(char) % 31) + 1) for char in text][:length]
        values.extend([0] * (length - len(values)))
        return {"input_ids": torch.tensor([values], dtype=torch.long)}


class FakeTextEncoder(torch.nn.Module):
    """Deterministic text encoder with a real module parameter for device inference."""

    def __init__(self, fail_stage: Optional[str] = None, hidden_size: int = 4) -> None:
        super().__init__()
        self.fail_stage = fail_stage
        self.hidden_size = hidden_size
        self.anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)

    def forward(self, input_ids: torch.Tensor, **_: Any) -> SimpleNamespace:
        if self.fail_stage == "conditioning.text_encoder":
            raise InjectedFailure("Injected text-encoder failure")

        encoded = input_ids.to(device=self.anchor.device, dtype=self.anchor.dtype).unsqueeze(-1)
        scales = torch.arange(
            1,
            self.hidden_size + 1,
            device=encoded.device,
            dtype=encoded.dtype,
        ).view(1, 1, -1)
        return SimpleNamespace(last_hidden_state=(encoded + 1.0) / scales)


class FakeUNet(torch.nn.Module):
    """Predictable UNet stand-in that records every denoising call."""

    def __init__(self, fail_stage: Optional[str] = None) -> None:
        super().__init__()
        self.fail_stage = fail_stage
        self.anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self.calls: list[dict[str, Any]] = []

    def forward(
        self,
        *,
        sample: torch.Tensor,
        timestep: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        **_: Any,
    ) -> SimpleNamespace:
        if self.fail_stage == "denoising.unet":
            raise InjectedFailure("Injected UNet failure")

        self.calls.append(
            {
                "sample_shape": list(sample.shape),
                "timestep_shape": list(timestep.shape),
                "conditioning_shape": list(encoder_hidden_states.shape),
            }
        )
        conditioning_strength = encoder_hidden_states.mean().to(sample.dtype)
        timestep_strength = timestep.float().mean().to(sample.dtype) * 0.0001
        predicted = sample * 0.05 + conditioning_strength * 0.001 + timestep_strength
        return SimpleNamespace(sample=predicted)


class FakeVAE(torch.nn.Module):
    """Latent decoder that returns a BCHW tensor suitable for pipeline validation."""

    def __init__(self, fail_stage: Optional[str] = None, scale_factor: int = 8) -> None:
        super().__init__()
        self.fail_stage = fail_stage
        self.scale_factor = scale_factor
        self.anchor = torch.nn.Parameter(torch.zeros(1), requires_grad=False)
        self.decode_calls = 0

    def decode(self, latents: torch.Tensor, **_: Any) -> torch.Tensor:
        if self.fail_stage == "decoding.vae":
            raise InjectedFailure("Injected VAE failure")

        self.decode_calls += 1
        rgb = latents[:, :3]
        rgb = functional.interpolate(
            rgb,
            scale_factor=self.scale_factor,
            mode="nearest",
        )
        return torch.tanh(rgb)


class FakePromptAdapter:
    """Uses the fake tokenizer and text encoder through the current prompt contract."""

    def encode(self, components, request: GenerationRequest, state=None) -> ConditioningOutput:
        del state
        tokenizer = components.tokenizer
        text_encoder = components.text_encoder

        cond_tokens = tokenizer(
            request.positive_prompt,
            max_length=tokenizer.model_max_length,
            return_tensors="pt",
        )["input_ids"]
        uncond_tokens = tokenizer(
            request.negative_prompt,
            max_length=tokenizer.model_max_length,
            return_tensors="pt",
        )["input_ids"]

        cond = text_encoder(cond_tokens).last_hidden_state
        uncond = text_encoder(uncond_tokens).last_hidden_state
        return ConditioningOutput(cond=cond, uncond=uncond, extra={"source": "phase00_fake"})


@dataclass
class FakeScheduler:
    fail_stage: Optional[str] = None

    def build(self, steps: int, device: torch.device, dtype: torch.dtype) -> SchedulerOutput:
        if self.fail_stage == "scheduling":
            raise InjectedFailure("Injected scheduler failure")

        sigmas = torch.linspace(1.0, 0.0, steps + 1, device=device, dtype=dtype)
        timesteps = torch.linspace(999.0, 0.0, steps + 1, device=device, dtype=torch.float32)
        return SchedulerOutput(
            sigmas=sigmas,
            timesteps=timesteps,
            requested_steps=steps,
            effective_steps=steps,
            metadata={"scheduler_name": "phase00_fake_scheduler"},
        )


class FakeSchedulerAdapter:
    def __init__(self, scheduler: FakeScheduler) -> None:
        self.scheduler = scheduler

    def build_schedule(self, request: GenerationRequest, state=None) -> SchedulerOutput:
        del state
        device = request.device or torch.device("cpu")
        dtype = request.dtype or torch.float32
        return self.scheduler.build(request.steps, device, dtype)


@dataclass
class FakeSampler:
    fail_stage: Optional[str] = None

    def sample(
        self,
        *,
        guided_model_fn,
        latents: torch.Tensor,
        schedule: SchedulerOutput,
        conditioning: ConditioningOutput,
        request: GenerationRequest,
    ) -> SamplerOutput:
        if self.fail_stage == "sampling":
            raise InjectedFailure("Injected sampler failure")

        if schedule.timesteps is None:
            raise ValueError("Fake sampler requires timesteps")

        x = latents
        model_calls = 0
        for index in range(schedule.sigmas.numel() - 1):
            sigma = schedule.sigmas[index]
            sigma_next = schedule.sigmas[index + 1]
            timestep = schedule.timesteps[index]
            guided_noise = guided_model_fn(
                x,
                sigma,
                timestep,
                conditioning.cond,
                conditioning.uncond,
                request.cfg_scale,
            )
            model_calls += 2
            x = x + guided_noise * (sigma_next - sigma)

        return SamplerOutput(
            latents=x,
            extra={
                "sampler_name": "phase00_fake_sampler",
                "model_calls": model_calls,
                "effective_steps": schedule.sigmas.numel() - 1,
            },
        )


class FakeSamplerAdapter:
    def __init__(self, sampler: FakeSampler) -> None:
        self.sampler = sampler

    def sample(
        self,
        raw_model_fn,
        guided_model_fn,
        latents,
        schedule,
        conditioning,
        request,
        state=None,
    ) -> SamplerOutput:
        del raw_model_fn, state
        return self.sampler.sample(
            guided_model_fn=guided_model_fn,
            latents=latents,
            schedule=schedule,
            conditioning=conditioning,
            request=request,
        )
