from __future__ import annotations

import contextlib
import io
from dataclasses import dataclass
from typing import Any, Callable, Optional

import torch

from modules.contracts import GenerationRequest, PipelineComponents
from modules.pipeline_builder import CustomSDPipeline
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeSampler,
    FakeSamplerAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
    FakeTextEncoder,
    FakeTokenizer,
    FakeUNet,
    FakeVAE,
    InjectedFailure,
)


STAGE_OWNERS = {
    "conditioning": "conditioning",
    "scheduling": "scheduling",
    "latent_preparation": "runtime",
    "sampling": "sampling",
    "denoising": "denoising",
    "decoding": "decoding",
    "result_validation": "runtime",
}


@dataclass
class StageFailure(RuntimeError):
    stage: str
    owner: str
    cause_type: str
    cause_message: str

    def __str__(self) -> str:
        return f"{self.stage} [{self.owner}]: {self.cause_type}: {self.cause_message}"

    def to_dict(self) -> dict[str, str]:
        return {
            "stage": self.stage,
            "owner": self.owner,
            "cause_type": self.cause_type,
            "cause_message": self.cause_message,
        }


@dataclass
class FakePipelineRun:
    request: GenerationRequest
    images: torch.Tensor
    latents: torch.Tensor
    schedule_extra: dict[str, Any]
    sampler_extra: dict[str, Any]
    unet_calls: int
    vae_decode_calls: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "image_shape": list(self.images.shape),
            "latent_shape": list(self.latents.shape),
            "schedule_extra": dict(self.schedule_extra),
            "sampler_extra": dict(self.sampler_extra),
            "unet_calls": self.unet_calls,
            "vae_decode_calls": self.vae_decode_calls,
        }


class AuditedFakePipelineHarness:
    """Runs the current pipeline contract with test-only components and stage labels."""

    def __init__(self, fail_stage: Optional[str] = None) -> None:
        self.fail_stage = fail_stage

        component_failure = fail_stage if fail_stage in {
            "conditioning.tokenizer",
            "conditioning.text_encoder",
            "denoising.unet",
            "decoding.vae",
        } else None

        self.tokenizer = FakeTokenizer(component_failure)
        self.text_encoder = FakeTextEncoder(component_failure)
        self.unet = FakeUNet(component_failure)
        self.vae = FakeVAE(component_failure)
        self.scheduler = FakeScheduler(fail_stage if fail_stage == "scheduling" else None)
        self.sampler = FakeSampler(fail_stage if fail_stage == "sampling" else None)

        self.pipeline = CustomSDPipeline(
            components=PipelineComponents(
                unet=self.unet,
                vae=self.vae,
                text_encoder=self.text_encoder,
                tokenizer=self.tokenizer,
            ),
            prompt_adapter=FakePromptAdapter(),
            scheduler_adapter=FakeSchedulerAdapter(self.scheduler),
            sampler_adapter=FakeSamplerAdapter(self.sampler),
            state=None,
            latent_scale_factor=8,
            vae_scaling_factor=1.0,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )

    @staticmethod
    def default_request() -> GenerationRequest:
        return GenerationRequest(
            positive_prompt="phase zero baseline",
            negative_prompt="failure",
            width=32,
            height=32,
            steps=3,
            cfg_scale=2.0,
            batch_size=1,
            seed=1234,
            device=torch.device("cpu"),
            dtype=torch.float32,
            scheduler_name="phase00_fake_scheduler",
            sampler_name="phase00_fake_sampler",
            return_latents=False,
            save_images=False,
        )

    def _stage(self, stage: str, action: Callable[[], Any]) -> Any:
        owner = STAGE_OWNERS[stage.split(".", 1)[0]]
        try:
            return action()
        except StageFailure:
            raise
        except Exception as exc:
            raise StageFailure(
                stage=stage,
                owner=owner,
                cause_type=type(exc).__name__,
                cause_message=str(exc),
            ) from exc

    def run(self, request: Optional[GenerationRequest] = None) -> FakePipelineRun:
        request = request or self.default_request()

        conditioning_stage = (
            self.fail_stage
            if self.fail_stage in {"conditioning.tokenizer", "conditioning.text_encoder"}
            else "conditioning"
        )
        conditioning = self._stage(
            conditioning_stage,
            lambda: self.pipeline.prompt_adapter.encode(
                components=self.pipeline.components,
                request=request,
                state=self.pipeline.state,
            ),
        )

        schedule = self._stage(
            "scheduling",
            lambda: self.pipeline.scheduler_adapter.build_schedule(
                request=request,
                state=self.pipeline.state,
            ),
        )

        def prepare_latents() -> torch.Tensor:
            if self.fail_stage == "latent_preparation":
                raise InjectedFailure("Injected latent-preparation failure")
            return self.pipeline.prepare_latents(request)

        latents = self._stage("latent_preparation", prepare_latents)

        sampling_stage = "denoising.unet" if self.fail_stage == "denoising.unet" else "sampling"
        sample_output = self._stage(
            sampling_stage,
            lambda: self.pipeline.sampler_adapter.sample(
                raw_model_fn=self.pipeline.predict_raw_noise,
                guided_model_fn=self.pipeline.predict_guided_noise,
                latents=latents,
                schedule=schedule,
                conditioning=conditioning,
                request=request,
                state=self.pipeline.state,
            ),
        )

        images = self._stage(
            "decoding.vae" if self.fail_stage == "decoding.vae" else "decoding",
            lambda: self.pipeline.decode_latents(sample_output.latents),
        )

        def validate_result() -> None:
            if self.fail_stage == "result_validation":
                raise InjectedFailure("Injected result-validation failure")
            expected = (request.batch_size, 3, request.height, request.width)
            if tuple(images.shape) != expected:
                raise ValueError(f"Expected decoded image shape {expected}, got {tuple(images.shape)}")
            if not torch.isfinite(images).all():
                raise ValueError("Decoded image contains non-finite values")

        self._stage("result_validation", validate_result)

        return FakePipelineRun(
            request=request,
            images=images,
            latents=sample_output.latents,
            schedule_extra=dict(schedule.extra or {}),
            sampler_extra=dict(sample_output.extra or {}),
            unet_calls=len(self.unet.calls),
            vae_decode_calls=self.vae.decode_calls,
        )


def run_fake_pipeline_checks() -> dict[str, Any]:
    """Run the no-checkpoint baseline and all intentional stage-failure checks."""

    with contextlib.redirect_stdout(io.StringIO()):
        successful_run = AuditedFakePipelineHarness().run()

    failure_cases = [
        "conditioning.tokenizer",
        "conditioning.text_encoder",
        "scheduling",
        "latent_preparation",
        "sampling",
        "denoising.unet",
        "decoding.vae",
        "result_validation",
    ]
    captured: list[dict[str, str]] = []

    for requested_stage in failure_cases:
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                AuditedFakePipelineHarness(fail_stage=requested_stage).run()
        except StageFailure as exc:
            record = exc.to_dict()
            record["requested_stage"] = requested_stage
            record["matched"] = exc.stage == requested_stage
            captured.append(record)
        else:
            captured.append(
                {
                    "requested_stage": requested_stage,
                    "stage": "",
                    "owner": "",
                    "cause_type": "",
                    "cause_message": "No failure was raised",
                    "matched": False,
                }
            )

    failures_identified = all(bool(item["matched"]) for item in captured)
    expected_model_calls = successful_run.request.steps * 2
    success = (
        list(successful_run.images.shape)
        == [
            successful_run.request.batch_size,
            3,
            successful_run.request.height,
            successful_run.request.width,
        ]
        and successful_run.unet_calls == expected_model_calls
        and successful_run.vae_decode_calls == 1
        and failures_identified
    )

    return {
        "status": "pass" if success else "fail",
        "successful_run": successful_run.to_dict(),
        "expected_unet_calls": expected_model_calls,
        "intentional_failures": captured,
        "all_failure_stages_identified": failures_identified,
    }
