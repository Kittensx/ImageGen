from __future__ import annotations

import contextlib
import io
import unittest

from tests.phase00.harness import AuditedFakePipelineHarness, StageFailure


class Phase00FakePipelineTests(unittest.TestCase):
    def test_fake_request_reaches_decoded_image(self) -> None:
        with contextlib.redirect_stdout(io.StringIO()):
            result = AuditedFakePipelineHarness().run()
        self.assertEqual(tuple(result.images.shape), (1, 3, 32, 32))
        self.assertEqual(result.unet_calls, 6)
        self.assertEqual(result.vae_decode_calls, 1)
        self.assertEqual(result.sampler_extra["effective_steps"], 3)

    def test_each_injected_failure_identifies_its_stage(self) -> None:
        stages = (
            "conditioning.tokenizer",
            "conditioning.text_encoder",
            "scheduling",
            "latent_preparation",
            "sampling",
            "denoising.unet",
            "decoding.vae",
            "result_validation",
        )
        for stage in stages:
            with self.subTest(stage=stage):
                with self.assertRaises(StageFailure) as captured:
                    with contextlib.redirect_stdout(io.StringIO()):
                        AuditedFakePipelineHarness(fail_stage=stage).run()
                self.assertEqual(captured.exception.stage, stage)
                self.assertTrue(captured.exception.owner)


if __name__ == "__main__":
    unittest.main()
