"""Deterministic fake systems used by focused local and CI tests."""
