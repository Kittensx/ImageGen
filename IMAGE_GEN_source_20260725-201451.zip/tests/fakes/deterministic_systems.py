from __future__ import annotations

from pathlib import Path
from typing import Any

import torch

from image_gen.contracts import GenerationRequest, PipelineComponents, SamplerOutput
from image_gen.runtime import PipelineCompositionRoot
from image_gen.systems.diagnostics import DiagnosticConfig, DiagnosticsSystem
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeSampler,
    FakeSamplerAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
    FakeTextEncoder,
    FakeTokenizer,
    FakeUNet,
    FakeVAE,
)


class IntentionalSystemFailure(RuntimeError):
    pass


class FailingSystemProxy:
    """Replace one system operation with a deterministic intentional failure."""

    def __init__(self, target: Any, operation: str, label: str) -> None:
        self.target = target
        self.operation = operation
        self.label = label

    def __getattr__(self, name: str):
        value = getattr(self.target, name)
        if name != self.operation or not callable(value):
            return value

        def fail(*args, **kwargs):
            del args, kwargs
            raise IntentionalSystemFailure(f"intentional {self.label} failure")

        return fail


class WrongShapeDecodingSystem:
    """Return finite image data that fails only runtime result validation."""

    def decode(self, latents: torch.Tensor) -> torch.Tensor:
        return torch.zeros(
            (latents.shape[0], 3, 16, 16),
            device=latents.device,
            dtype=latents.dtype,
        )


class TraceAwareFakeSamplerAdapter:
    """Deterministic fake sampler that exercises the optional trace recorder."""

    def sample(
        self,
        raw_model_fn,
        guided_model_fn,
        latents,
        schedule,
        conditioning,
        request,
        state=None,
    ) -> SamplerOutput:
        del raw_model_fn, state
        recorder = dict(request.sampler_kwargs or {}).get("trace_recorder")
        x = latents
        for index in range(schedule.sigma_transitions):
            before = x.detach()
            sigma = schedule.sigmas[index]
            sigma_next = schedule.sigmas[index + 1]
            timestep = schedule.timestep_for_step(index)
            noise = guided_model_fn(
                x,
                sigma,
                timestep,
                conditioning.cond,
                conditioning.uncond,
                request.cfg_scale,
            )
            x = x + noise * (sigma_next - sigma)
            if recorder is not None:
                recorder.record_step(
                    step_index=index,
                    sigma=sigma,
                    sigma_next=sigma_next,
                    latent_before=before,
                    latent_after=x,
                    guided_noise=noise,
                    cfg_scale=request.cfg_scale,
                    extra={"source": "phase06_fake"},
                )
        return SamplerOutput(
            latents=x,
            extra={
                "sampler_name": "phase06_trace_fake",
                "requested_steps": request.steps,
                "effective_steps": schedule.sigma_transitions,
            },
        )


def fake_components(*, unet_failure: bool = False) -> PipelineComponents:
    return PipelineComponents(
        unet=FakeUNet("denoising.unet" if unet_failure else None),
        vae=FakeVAE(),
        text_encoder=FakeTextEncoder(),
        tokenizer=FakeTokenizer(),
    )


def fake_request(*, diagnostics: dict[str, Any] | None = None) -> GenerationRequest:
    return GenerationRequest(
        positive_prompt="phase six deterministic diagnostics",
        negative_prompt="failure",
        width=32,
        height=32,
        steps=3,
        cfg_scale=2.0,
        batch_size=1,
        seed=606,
        device=torch.device("cpu"),
        dtype=torch.float32,
        sampler_name="phase06_fake_sampler",
        scheduler_name="phase06_fake_scheduler",
        diagnostics=dict(diagnostics or {}),
    )


def build_fake_pipeline(
    artifacts_root: str | Path,
    *,
    diagnostics: dict[str, Any] | None = None,
    fail_system: str | None = None,
    trace_aware_sampler: bool = False,
):
    components = fake_components(unet_failure=fail_system == "denoising")
    config = DiagnosticConfig.from_mapping(
        diagnostics or {}, artifacts_root=Path(artifacts_root)
    )
    diagnostic_system = DiagnosticsSystem(config)
    sampler_adapter = (
        TraceAwareFakeSamplerAdapter()
        if trace_aware_sampler
        else FakeSamplerAdapter(FakeSampler())
    )

    base_root = PipelineCompositionRoot(
        components=components,
        prompt_adapter=FakePromptAdapter(),
        scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
        sampler_adapter=sampler_adapter,
        device=torch.device("cpu"),
        dtype=torch.float32,
        vae_scaling_factor=1.0,
        system_overrides={"diagnostics": diagnostic_system},
    )
    base = base_root.create_systems()
    overrides: dict[str, Any] = {"diagnostics": diagnostic_system}
    operations = {
        "conditioning": "encode",
        "scheduling": "build",
        "latent_preparation": "prepare",
        "sampling": "sample",
        "decoding": "decode",
    }
    if fail_system in operations:
        overrides[fail_system] = FailingSystemProxy(
            getattr(base, fail_system), operations[fail_system], fail_system
        )
    elif fail_system == "runtime":
        overrides["decoding"] = WrongShapeDecodingSystem()

    pipeline = PipelineCompositionRoot(
        components=components,
        prompt_adapter=FakePromptAdapter(),
        scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
        sampler_adapter=sampler_adapter,
        device=torch.device("cpu"),
        dtype=torch.float32,
        vae_scaling_factor=1.0,
        system_overrides=overrides,
    ).build()
    return pipeline, diagnostic_system
