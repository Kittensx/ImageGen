from __future__ import annotations

import contextlib
import io
import os
import tempfile
import unittest
from pathlib import Path

import yaml

from modules.config_options import ConfigOptions
from modules.project_context import ProjectContext
from modules.ss_registry.master_sampler import SamplerMap
from modules.ss_registry.master_scheduler import SchedulerMap
from modules.txt2img.cli import main as cli_main
from modules.txt2img.request_loader import load_request_payload


class Phase01ProjectContextTests(unittest.TestCase):
    def _make_project(self, *, complete: bool = True) -> Path:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)

        (root / "modules").mkdir(parents=True)
        (root / "modules" / "local_configs").mkdir(parents=True)
        (root / "modules" / "ss_registry").mkdir(parents=True)
        (root / "user_config").mkdir(parents=True)

        paths = {
            "models_root": "models/StableDiffusion",
            "checkpoints_dir": "models/StableDiffusion/CheckPoints",
            "local_config_dir": "modules/local_configs",
            "tokenizer_dir": "modules/local_tokenizers/clip-vit-large-patch14",
            "data_dir": "data",
            "registry_db_path": "data/asset_registry.db",
            "output_dir": "output",
            "txt2img_output_dir": "output/txt2image",
            "cache_dir": "data/cache",
            "temporary_dir": "data/tmp",
        }
        config = {
            "paths": paths,
            "defaults": {
                "model_path": "models/StableDiffusion/CheckPoints/test.safetensors",
                "device": "auto",
                "dtype": "auto",
            },
            "generation": {
                "prompt": "phase one default prompt",
                "negative_prompt": "",
                "steps": 12,
                "cfg_scale": 5.5,
                "width": 64,
                "height": 64,
                "sampler": "Euler",
                "scheduler": "simple_kes",
                "batch_size": 1,
            },
        }
        (root / "user_config" / "user-config.yml").write_text(
            yaml.safe_dump(config, sort_keys=False),
            encoding="utf-8",
        )

        if complete:
            checkpoint_root = root / "models" / "StableDiffusion" / "CheckPoints"
            checkpoint_root.mkdir(parents=True)
            (checkpoint_root / "test.safetensors").write_bytes(b"phase01")

            tokenizer_root = root / "modules" / "local_tokenizers" / "clip-vit-large-patch14"
            tokenizer_root.mkdir(parents=True)
            for filename in ("tokenizer.json", "tokenizer_config.json", "vocab.json", "merges.txt"):
                (tokenizer_root / filename).write_text("{}", encoding="utf-8")

            (root / "output" / "txt2image").mkdir(parents=True)
            (root / "data" / "cache").mkdir(parents=True)
            (root / "data" / "tmp").mkdir(parents=True)

        return root

    def test_context_is_identical_from_another_working_directory(self) -> None:
        root = self._make_project()
        original_cwd = Path.cwd()
        other = root / "unrelated-working-directory"
        other.mkdir()
        try:
            first = ProjectContext.load(project_root=root)
            os.chdir(other)
            second = ProjectContext.load(project_root=root)
        finally:
            os.chdir(original_cwd)

        self.assertEqual(first.project_root, second.project_root)
        self.assertEqual(first.checkpoints_dir, second.checkpoints_dir)
        self.assertEqual(first.tokenizer_root, second.tokenizer_root)
        self.assertEqual(first.generation_defaults(), second.generation_defaults())

    def test_config_options_constructor_has_no_directory_creation_side_effects(self) -> None:
        root = self._make_project(complete=False)
        context = ProjectContext.load(project_root=root)
        ConfigOptions(project_context=context)

        self.assertFalse((root / "models").exists())
        self.assertFalse((root / "data").exists())
        self.assertFalse((root / "output").exists())

    def test_validation_detects_missing_model_tokenizer_and_output(self) -> None:
        root = self._make_project(complete=False)
        context = ProjectContext.load(project_root=root)
        report = context.validate(for_generation=True)
        codes = {issue.code for issue in report.errors}

        self.assertFalse(report.is_valid)
        self.assertIn("MODEL_FILE_MISSING", codes)
        self.assertIn("TOKENIZER_ROOT_MISSING", codes)
        self.assertIn("OUTPUT_ROOT_MISSING", codes)
        self.assertIn("CHECKPOINT_ROOT_MISSING", codes)

    def test_visible_user_config_supplies_generation_defaults(self) -> None:
        root = self._make_project()
        context = ProjectContext.load(project_root=root)
        defaults = context.generation_defaults()

        self.assertEqual(defaults["positive_prompt"], "phase one default prompt")
        self.assertEqual(defaults["steps"], 12)
        self.assertEqual(defaults["cfg_scale"], 5.5)
        self.assertEqual(defaults["model_path"], str(root / "models" / "StableDiffusion" / "CheckPoints" / "test.safetensors"))

    def test_project_defaults_are_base_not_an_override_of_request_sources(self) -> None:
        root = self._make_project()
        context = ProjectContext.load(project_root=root)
        request_path = root / "request.yml"
        request_path.write_text(
            yaml.safe_dump({"steps": 31, "model_path": "external/request-model.safetensors"}),
            encoding="utf-8",
        )

        payload = load_request_payload(
            config_path=request_path,
            base_payload=context.generation_defaults(),
            cli_overrides={"steps": 42},
        )

        self.assertEqual(payload["positive_prompt"], "phase one default prompt")
        self.assertEqual(payload["model_path"], "external/request-model.safetensors")
        self.assertEqual(payload["steps"], 42)

    def test_registry_paths_do_not_depend_on_process_cwd(self) -> None:
        root = self._make_project()
        context = ProjectContext.load(project_root=root)
        original_cwd = Path.cwd()
        other = root / "other-cwd"
        other.mkdir()
        try:
            os.chdir(other)
            sampler = SamplerMap(project_context=context, auto_generate=False)
            scheduler = SchedulerMap(project_context=context, auto_generate=False)
        finally:
            os.chdir(original_cwd)

        expected = str((root / "modules" / "ss_registry").resolve())
        self.assertEqual(sampler.base_path, expected)
        self.assertEqual(scheduler.base_path, expected)

    def test_config_cli_show_and_validate_work_from_another_cwd(self) -> None:
        root = self._make_project()
        original_cwd = Path.cwd()
        other = root / "cli-cwd"
        other.mkdir()
        stdout = io.StringIO()
        try:
            os.chdir(other)
            with contextlib.redirect_stdout(stdout):
                show_code = cli_main(["config", "show", "--project-root", str(root)])
                validate_code = cli_main(["config", "validate", "--project-root", str(root)])
        finally:
            os.chdir(original_cwd)

        self.assertEqual(show_code, 0)
        self.assertEqual(validate_code, 0)
        output = stdout.getvalue()
        self.assertIn("phase one default prompt", output)
        self.assertIn("Project configuration validation: PASS", output)


if __name__ == "__main__":
    unittest.main()
