"""Focused tests for Phase 01 project context and launcher convergence."""
