from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import yaml

from image_gen.contracts import GenerationRequest
from image_gen.runtime.txt2img_runner import (
    _prepare_output_directory,
    _verify_saved_records,
)
from modules.project_context import ProjectContext
from modules.txt2img.cli import build_cli_overrides, build_parser
from modules.txt2img.output_saver import SavedImageRecord


class RunOutputPersistenceHotfixTests(unittest.TestCase):
    def _context(self, *, save_images=None) -> ProjectContext:
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        root = Path(temp.name)
        (root / "modules" / "local_configs").mkdir(parents=True)
        (root / "modules" / "ss_registry").mkdir(parents=True)
        (root / "modules" / "local_tokenizers" / "clip-vit-large-patch14").mkdir(parents=True)
        (root / "user_config").mkdir(parents=True)

        generation = {
            "prompt": "a kitten",
            "negative_prompt": "",
            "steps": 12,
            "cfg_scale": 7.0,
            "width": 64,
            "height": 64,
            "sampler": "simple_euler",
            "scheduler": "simple_kes",
            "batch_size": 1,
        }
        if save_images is not None:
            generation["save_images"] = save_images

        config = {
            "paths": {
                "local_config_dir": "modules/local_configs",
                "tokenizer_dir": "modules/local_tokenizers/clip-vit-large-patch14",
                "txt2img_output_dir": "output/txt2image",
            },
            "defaults": {},
            "generation": generation,
        }
        (root / "user_config" / "user-config.yml").write_text(
            yaml.safe_dump(config, sort_keys=False),
            encoding="utf-8",
        )
        return ProjectContext.load(project_root=root)

    def test_user_facing_generation_defaults_to_saving(self) -> None:
        context = self._context()
        defaults = context.generation_defaults()
        self.assertTrue(defaults["save_images"])
        self.assertEqual(defaults["output_dir"], str(context.txt2img_output_root))
        self.assertEqual(defaults["output_prefix"], "{index:05d}-{seed}")

    def test_configuration_can_explicitly_disable_saving(self) -> None:
        context = self._context(save_images=False)
        self.assertFalse(context.generation_defaults()["save_images"])

    def test_runner_creates_output_directory_before_validation(self) -> None:
        context = self._context()
        target = context.project_root / "custom" / "images"
        request = GenerationRequest(
            positive_prompt="a kitten",
            save_images=True,
            output_dir=str(target),
        )

        prepared = _prepare_output_directory(context, request, should_save=True)

        self.assertEqual(prepared, target.resolve())
        self.assertTrue(target.is_dir())
        self.assertTrue(request.save_images)
        self.assertEqual(request.output_dir, str(target.resolve()))

    def test_saving_requested_requires_a_real_image_path(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "no saved records"):
            _verify_saved_records([])

        with tempfile.TemporaryDirectory() as temp_dir:
            missing = Path(temp_dir) / "missing.png"
            record = SavedImageRecord(image_path=str(missing))
            with self.assertRaisesRegex(RuntimeError, "do not exist"):
                _verify_saved_records([record])

            image_path = Path(temp_dir) / "saved.png"
            image_path.write_bytes(b"png")
            records = [SavedImageRecord(image_path=str(image_path))]
            self.assertIs(_verify_saved_records(records), records)

    def test_run_bat_explicitly_requests_persistence(self) -> None:
        project_root = Path(__file__).resolve().parents[2]
        run_bat = (project_root / "run.bat").read_text(encoding="utf-8")
        self.assertIn("run --interactive --save", run_bat)

        args = build_parser().parse_args(["run", "--interactive", "--save"])
        self.assertTrue(build_cli_overrides(args)["save_images"])

        args = build_parser().parse_args(["run", "--no-save"])
        self.assertFalse(build_cli_overrides(args)["save_images"])


if __name__ == "__main__":
    unittest.main()
