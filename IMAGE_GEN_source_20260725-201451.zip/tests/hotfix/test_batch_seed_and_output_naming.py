from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import torch

from image_gen.contracts import GenerationRequest
from image_gen.systems.sampling import LatentPreparationSystem
from modules.txt2img.generation_manifest import GenerationManifest, RequiredForRerun
from modules.txt2img.output_saver import GenerationOutputSaver
from modules.txt2img.seed_utils import iter_batch_base_seeds, resolve_seed_sequence


class BatchSeedAndOutputNamingTests(unittest.TestCase):
    def test_batch_uses_explicit_sequential_seeds_and_is_individually_reproducible(self) -> None:
        system = LatentPreparationSystem(
            latent_scale_factor=8,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )
        schedule = SimpleNamespace(initial_sigma=1.0)
        batch_request = GenerationRequest(
            positive_prompt="test",
            width=16,
            height=16,
            batch_size=3,
            seed=100,
        )
        batch_latents = system.prepare(batch_request, schedule)

        self.assertEqual(batch_request.resolved_seeds, [100, 101, 102])
        for image_index, seed in enumerate(batch_request.resolved_seeds):
            single_request = GenerationRequest(
                positive_prompt="test",
                width=16,
                height=16,
                batch_size=1,
                seed=seed,
            )
            single_latent = system.prepare(single_request, schedule)
            self.assertTrue(torch.equal(batch_latents[image_index : image_index + 1], single_latent))

    def test_fixed_batch_count_continues_seed_sequence(self) -> None:
        seeds = iter_batch_base_seeds(1000, batch_size=2)
        self.assertEqual([next(seeds) for _ in range(3)], [1000, 1002, 1004])

    def test_random_batch_count_gets_new_base_each_batch(self) -> None:
        with mock.patch(
            "modules.txt2img.seed_utils.secrets.randbelow",
            side_effect=[10, 200, 3000],
        ):
            seeds = iter_batch_base_seeds(-1, batch_size=2)
            self.assertEqual([next(seeds) for _ in range(3)], [10, 200, 3000])

    def test_resolve_seed_sequence_is_sequential(self) -> None:
        self.assertEqual(resolve_seed_sequence(77, 4), [77, 78, 79, 80])

    def test_default_template_names_and_sidecars_use_each_image_seed(self) -> None:
        manifest = GenerationManifest(
            required_for_rerun=RequiredForRerun(
                prompt="test",
                seed=500,
                width=8,
                height=8,
                sampler_name="simple_euler",
                scheduler_name="simple_kes",
                model_path="models/Test.Model.safetensors",
            )
        )
        manifest.extra["resolved_seeds"] = [500, 501]
        images = torch.stack(
            [torch.zeros((3, 8, 8)), torch.ones((3, 8, 8))],
            dim=0,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            saver = GenerationOutputSaver(temp_dir, prefix="{index:05d}-{seed}")
            records = saver.save_batch(images, manifest=manifest)

            self.assertEqual(Path(records[0].image_path).name, "00001-500.png")
            self.assertEqual(Path(records[1].image_path).name, "00002-501.png")
            self.assertEqual([record.seed for record in records], [500, 501])

            for record, expected_seed in zip(records, [500, 501]):
                payload = json.loads(Path(record.json_path).read_text(encoding="utf-8"))
                self.assertEqual(payload["required_for_rerun"]["seed"], expected_seed)
                self.assertEqual(payload["extra"]["image_seed"], expected_seed)
                self.assertEqual(payload["runtime_info"]["output_image_path"], record.image_path)
                self.assertEqual(payload["runtime_info"]["output_txt_path"], record.txt_path)
                self.assertEqual(payload["runtime_info"]["output_json_path"], record.json_path)
                txt = Path(record.txt_path).read_text(encoding="utf-8")
                self.assertIn(f"Seed: {expected_seed}", txt)

            more = saver.save_batch(images[:1], manifest=manifest)
            self.assertEqual(Path(more[0].image_path).name, "00003-500.png")

    def test_default_template_continues_from_legacy_img_numbering(self) -> None:
        manifest = GenerationManifest(
            required_for_rerun=RequiredForRerun(seed=700, width=8, height=8)
        )
        manifest.extra["resolved_seeds"] = [700]
        with tempfile.TemporaryDirectory() as temp_dir:
            Path(temp_dir, "img_0000006.png").write_bytes(b"old")
            saver = GenerationOutputSaver(temp_dir, prefix="{index:05d}-{seed}")
            records = saver.save_batch(
                torch.zeros((1, 3, 8, 8)),
                manifest=manifest,
                save_txt=False,
                save_json=False,
            )
            self.assertEqual(Path(records[0].image_path).name, "00007-700.png")

    def test_custom_template_supports_model_and_runtime_fields(self) -> None:
        manifest = GenerationManifest(
            required_for_rerun=RequiredForRerun(
                prompt="test",
                seed=9,
                width=640,
                height=960,
                sampler_name="dpmpp_2m",
                scheduler_name="karras",
                model_path="models/Nautica.safetensors",
            )
        )
        manifest.extra["resolved_seeds"] = [9]
        manifest.extra["vae_path"] = "models/VAE/ClearVAE.safetensors"
        manifest.extra["lora_paths"] = ["models/Lora/Painterly.safetensors"]
        with tempfile.TemporaryDirectory() as temp_dir:
            saver = GenerationOutputSaver(
                temp_dir,
                prefix=(
                    "{index:05d}-{seed}-{model}-{lora}-{vae}-"
                    "{sampler}-{width}x{height}"
                ),
            )
            records = saver.save_batch(
                torch.zeros((1, 3, 8, 8)),
                manifest=manifest,
                save_txt=False,
                save_json=False,
            )
            self.assertEqual(
                Path(records[0].image_path).name,
                "00001-9-Nautica-Painterly-ClearVAE-dpmpp_2m-640x960.png",
            )


if __name__ == "__main__":
    unittest.main()
