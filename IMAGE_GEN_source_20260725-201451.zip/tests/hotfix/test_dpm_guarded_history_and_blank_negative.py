from __future__ import annotations

import unittest

import torch

from image_gen.contracts import ConditioningOutput, GenerationRequest, SchedulerOutput
from modules.pipeline.step_trace_recorder import StepTraceRecorder, TraceRequest
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSampler,
)
from modules.ss_registry.samplers.simple_samplers.simple_euler import SimpleEulerSampler
from modules.txt2img.cli import _merge_interactive_overrides


class TargetedDPMHistoryHotfixTests(unittest.TestCase):
    @staticmethod
    def _conditioning(dtype: torch.dtype = torch.float32) -> ConditioningOutput:
        return ConditioningOutput(
            cond=torch.ones((1, 2, 3), dtype=dtype),
            uncond=torch.zeros((1, 2, 3), dtype=dtype),
        )

    @staticmethod
    def _guided(epsilon_value: float = 0.125):
        def guided(sample, sigma, timestep, cond, uncond, cfg_scale):
            del sigma, timestep, cond, uncond, cfg_scale
            return torch.full_like(sample, epsilon_value)

        def predict_denoised(sample, sigma, timestep, cond, uncond, cfg_scale):
            del timestep, cond, uncond, cfg_scale
            sigma_value = torch.as_tensor(
                sigma,
                device=sample.device,
                dtype=torch.float32,
            )
            return sample.float() - sigma_value * epsilon_value

        guided.predict_denoised = predict_denoised
        guided.denoising_contract = lambda: {
            "prediction_type": "epsilon",
            "prediction_conversion": "x0 = solver_sample - sigma * guided_epsilon",
            "model_input_preconditioning": "sample / sqrt(sigma^2 + 1)",
            "cfg_rescale": 0.0,
            "model_dtype": "torch.float16",
            "solver_dtype": "torch.float32",
        }
        return guided

    def test_dpm_defaults_to_float32_and_timestep_guarded_history(self) -> None:
        request = GenerationRequest(
            positive_prompt="defaults",
            steps=2,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
            sampler_kwargs={},
        )
        self.assertEqual(
            DPMPlusPlus2MSampler._resolve_solver_dtype(request, torch.float16),
            torch.float32,
        )
        self.assertEqual(
            DPMPlusPlus2MSampler._resolve_history_policy(request),
            "model_timestep_guarded",
        )

    def test_repeated_model_timesteps_reset_and_block_multistep_history(self) -> None:
        recorder = StepTraceRecorder(
            request=TraceRequest(enabled=True, export_txt_summary=False)
        )
        schedule = SchedulerOutput(
            sigmas=torch.tensor([6.0, 5.0, 4.0, 3.0, 2.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 999.0, 999.0, 900.0, 800.0, 700.0, 0.0]),
            requested_steps=6,
            effective_steps=6,
        )
        request = GenerationRequest(
            positive_prompt="guard history",
            steps=6,
            cfg_scale=7.0,
            sampler_name="dpmpp_2m",
            scheduler_name="simple_kes",
            sampler_kwargs={"trace_recorder": recorder},
        )
        result = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=self._guided(),
            latents=torch.ones((1, 4, 2, 2), dtype=torch.float16),
            schedule=schedule,
            conditioning=self._conditioning(dtype=torch.float16),
            request=request,
        )

        self.assertEqual(result.extra["solver_dtype"], "torch.float32")
        self.assertEqual(result.extra["history_policy"], "model_timestep_guarded")
        self.assertEqual(result.extra["history_reset_count"], 2)
        self.assertEqual(result.extra["history_guard_rejection_count"], 3)
        self.assertEqual(result.extra["history_state_read_count"], 1)
        self.assertEqual(result.extra["second_order_update_count"], 1)
        self.assertEqual(
            [record.extra["update_order"] for record in recorder.records],
            [
                "first_order",
                "first_order",
                "first_order",
                "first_order",
                "second_order",
                "terminal_denoised",
            ],
        )
        self.assertEqual(
            [record.extra["history_rejection_reason"] for record in recorder.records],
            [
                "history_unavailable",
                "repeated_model_timestep",
                "repeated_model_timestep",
                "history_reset_after_timestep_plateau",
                None,
                "terminal_sigma",
            ],
        )

    def test_first_order_dpm_matches_euler_with_same_guided_epsilon(self) -> None:
        schedule = SchedulerOutput(
            sigmas=torch.tensor([4.0, 2.0, 1.0, 0.0]),
            timesteps=torch.tensor([999.0, 700.0, 100.0, 0.0]),
            requested_steps=3,
            effective_steps=3,
        )
        conditioning = self._conditioning()
        initial = torch.randn((1, 4, 3, 3), generator=torch.Generator().manual_seed(42))
        guided = self._guided(epsilon_value=0.2)

        euler = SimpleEulerSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=initial.clone(),
            schedule=schedule,
            conditioning=conditioning,
            request=GenerationRequest(
                positive_prompt="equivalence",
                steps=3,
                cfg_scale=7.0,
                sampler_name="simple_euler",
                scheduler_name="simple_kes",
            ),
        )
        dpm = DPMPlusPlus2MSampler().sample(
            raw_model_fn=None,
            guided_model_fn=guided,
            latents=initial.clone(),
            schedule=schedule,
            conditioning=conditioning,
            request=GenerationRequest(
                positive_prompt="equivalence",
                steps=3,
                cfg_scale=7.0,
                sampler_name="dpmpp_2m",
                scheduler_name="simple_kes",
                sampler_kwargs={
                    "solver_dtype": "float32",
                    "history_policy": "first_order_only",
                },
            ),
        )
        self.assertTrue(torch.allclose(dpm.latents, euler.latents, atol=1e-6, rtol=1e-6))


class InteractiveNegativePromptHotfixTests(unittest.TestCase):
    def test_blank_interactive_negative_prompt_overrides_config_default(self) -> None:
        merged = _merge_interactive_overrides(
            {
                "negative_prompt": (
                    "blurry, distorted, low resolution, sepia, black and white, "
                    "kodak photograph"
                ),
                "model_path": "configured-model.safetensors",
            },
            {
                "negative_prompt": "",
                "model_path": "",
            },
        )
        self.assertEqual(merged["negative_prompt"], "")
        self.assertEqual(merged["model_path"], "configured-model.safetensors")


if __name__ == "__main__":
    unittest.main()
