from __future__ import annotations

import os
import unittest
from unittest.mock import patch

from modules.attention_backend import (
    attention_backend_report,
    configure_unet_attention,
    resolve_attention_backend,
)


class _Processor:
    def __init__(self, name: str) -> None:
        self.name = name


class _FakeUNet:
    def __init__(self) -> None:
        self.attn_processors = {"a": _Processor("initial")}
        self.xformers_enabled = False

    def set_attn_processor(self, processor) -> None:
        self.attn_processors = {"a": processor, "b": processor}

    def enable_xformers_memory_efficient_attention(self) -> None:
        self.xformers_enabled = True
        self.attn_processors = {"a": type("XFormersAttnProcessor", (), {})()}


class AttentionBackendRecoveryTests(unittest.TestCase):
    def test_recovery_default_is_eager(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            self.assertEqual(resolve_attention_backend(), "eager")

    def test_eager_processor_is_forced_without_uninstalling_xformers(self) -> None:
        unet = _FakeUNet()
        report = configure_unet_attention(
            unet,
            backend="eager",
            processor_factory=lambda backend: type("AttnProcessor", (), {})(),
        )
        self.assertEqual(report["requested_backend"], "eager")
        self.assertEqual(report["processor_types_after"], ["AttnProcessor"])
        self.assertFalse(report["xformers_installation_changed"])
        self.assertEqual(attention_backend_report(unet), report)

    def test_xformers_remains_explicit_opt_in(self) -> None:
        unet = _FakeUNet()
        report = configure_unet_attention(unet, backend="xformers")
        self.assertTrue(unet.xformers_enabled)
        self.assertEqual(report["processor_types_after"], ["XFormersAttnProcessor"])

    def test_default_mode_leaves_processor_unchanged(self) -> None:
        unet = _FakeUNet()
        before = list(unet.attn_processors.values())
        report = configure_unet_attention(unet, backend="default")
        self.assertFalse(report["applied"])
        self.assertEqual(list(unet.attn_processors.values()), before)


if __name__ == "__main__":
    unittest.main()
