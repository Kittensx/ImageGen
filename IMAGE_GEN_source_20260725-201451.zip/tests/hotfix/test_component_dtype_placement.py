from __future__ import annotations

import unittest
import unittest.mock

import torch

from image_gen.contracts import PipelineComponents
from image_gen.runtime.composition import PipelineCompositionRoot
from modules.component_placement import devices_equivalent, place_component


class GuardedModule(torch.nn.Module):
    """Fails if its overridden dtype-aware ``to`` method is used."""

    def __init__(self) -> None:
        super().__init__()
        self.linear = torch.nn.Linear(4, 4)
        self.to_calls: list[tuple[tuple, dict]] = []

    def to(self, *args, **kwargs):
        self.to_calls.append((args, dict(kwargs)))
        if "dtype" in kwargs or any(isinstance(arg, torch.dtype) for arg in args):
            raise AssertionError("dtype must bypass the model-specific to() override")
        return super().to(*args, **kwargs)


class MixedPrecisionModule(GuardedModule):
    _keep_in_fp32_modules = ["sensitive"]

    def __init__(self) -> None:
        super().__init__()
        self.sensitive = torch.nn.Linear(4, 4)


class ComponentDtypePlacementTests(unittest.TestCase):
    def test_unindexed_cuda_matches_current_concrete_cuda_device(self) -> None:
        with unittest.mock.patch("torch.cuda.current_device", return_value=0):
            self.assertTrue(devices_equivalent("cuda:0", "cuda"))
            self.assertTrue(devices_equivalent("cuda", "cuda:0"))
            self.assertFalse(devices_equivalent("cuda:1", "cuda"))

    def test_explicit_cuda_indexes_must_match(self) -> None:
        self.assertTrue(devices_equivalent("cuda:1", "cuda:1"))
        self.assertFalse(devices_equivalent("cuda:0", "cuda:1"))

    def test_dtype_cast_bypasses_model_specific_to_override(self) -> None:
        module = GuardedModule()
        report = place_component(
            module,
            device="cpu",
            dtype=torch.float16,
            owner="test",
            component_name="unet",
        )

        self.assertEqual(module.to_calls, [])
        self.assertTrue(report.verified)
        self.assertEqual(next(module.parameters()).dtype, torch.float16)
        self.assertEqual(report.after_dtypes, ["torch.float16"])

    def test_keep_in_fp32_patterns_are_restored_after_cast(self) -> None:
        module = MixedPrecisionModule()
        report = place_component(
            module,
            device="cpu",
            dtype=torch.float16,
            owner="test",
            component_name="unet",
        )

        self.assertEqual(module.linear.weight.dtype, torch.float16)
        self.assertEqual(module.sensitive.weight.dtype, torch.float32)
        self.assertIn("sensitive.weight", report.kept_in_fp32_names)
        self.assertEqual(
            report.after_dtypes,
            ["torch.float16", "torch.float32"],
        )

    def test_composition_does_not_recast_already_placed_components(self) -> None:
        unet = GuardedModule()
        vae = GuardedModule()
        text_encoder = GuardedModule()
        for name, module in (
            ("unet", unet),
            ("vae", vae),
            ("text_encoder", text_encoder),
        ):
            place_component(
                module,
                device="cpu",
                dtype=torch.float32,
                owner="ComponentBuilder",
                component_name=name,
            )

        root = PipelineCompositionRoot(
            components=PipelineComponents(
                unet=unet,
                vae=vae,
                text_encoder=text_encoder,
            ),
            prompt_adapter=None,
            scheduler_adapter=None,
            sampler_adapter=None,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )
        root.prepare_components()

        self.assertEqual(unet.to_calls, [])
        self.assertEqual(vae.to_calls, [])
        self.assertEqual(text_encoder.to_calls, [])
        self.assertFalse(unet.training)
        self.assertFalse(vae.training)
        self.assertFalse(text_encoder.training)

    def test_composition_compatibility_repair_uses_safe_placement(self) -> None:
        unet = GuardedModule().half()
        vae = GuardedModule().half()
        text_encoder = GuardedModule().half()
        # ``half`` uses PyTorch's separate method and does not exercise to().
        unet.to_calls.clear()
        vae.to_calls.clear()
        text_encoder.to_calls.clear()

        components = PipelineComponents(
            unet=unet,
            vae=vae,
            text_encoder=text_encoder,
        )
        root = PipelineCompositionRoot(
            components=components,
            prompt_adapter=None,
            scheduler_adapter=None,
            sampler_adapter=None,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )
        root.prepare_components()

        self.assertEqual(next(unet.parameters()).dtype, torch.float32)
        self.assertEqual(unet.to_calls, [])
        metadata = components.placement_metadata()
        self.assertEqual(
            metadata["unet"]["owner"],
            "PipelineCompositionRoot.compatibility_repair",
        )
        self.assertTrue(metadata["unet"]["verified"])

    def test_pipeline_component_description_reports_final_dtypes(self) -> None:
        unet = GuardedModule()
        vae = GuardedModule()
        text_encoder = GuardedModule()
        for name, module in (
            ("unet", unet),
            ("vae", vae),
            ("text_encoder", text_encoder),
        ):
            place_component(
                module,
                device="cpu",
                dtype=torch.float32,
                owner="ComponentBuilder",
                component_name=name,
            )

        description = PipelineComponents(
            unet=unet,
            vae=vae,
            text_encoder=text_encoder,
        ).describe()

        placement = description["component_placement"]
        self.assertEqual(placement["unet"]["after_dtypes"], ["torch.float32"])
        self.assertEqual(placement["unet"]["owner"], "ComponentBuilder")


if __name__ == "__main__":
    unittest.main()
