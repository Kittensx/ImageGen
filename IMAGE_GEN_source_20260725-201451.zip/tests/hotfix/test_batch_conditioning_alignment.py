from __future__ import annotations

import unittest

import torch

from modules.contracts import ConditioningOutput, GenerationRequest, PipelineComponents
from modules.pipeline.conditioning_utils import (
    align_conditioning_batch,
    resolve_static_conditioning,
    resolve_step_conditioning,
)
from modules.pipeline_builder import CustomSDPipeline
from modules.shared_state import SharedState
from modules.ss_registry.samplers.kes_sampler.simple_kes_sampler.kes_sampler_adapter import (
    KESSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.dpmpp_2m_sampler import (
    DPMPlusPlus2MSamplerAdapter,
)
from modules.ss_registry.samplers.simple_samplers.simple_euler import (
    SimpleEulerSamplerAdapter,
)
from tests.phase00.fakes import (
    FakePromptAdapter,
    FakeScheduler,
    FakeSchedulerAdapter,
    FakeTextEncoder,
    FakeTokenizer,
    FakeUNet,
    FakeVAE,
)


class SingletonStepResolver:
    def resolve(self, step_index: int):
        value = float(step_index + 1)
        return (
            torch.full((1, 3, 4), value),
            torch.zeros((1, 3, 4)),
        )


class BatchConditioningAlignmentTests(unittest.TestCase):
    def test_singleton_conditioning_broadcasts_to_latent_batch(self) -> None:
        source = torch.arange(12, dtype=torch.float32).reshape(1, 3, 4)
        aligned = align_conditioning_batch(source, 4, name="positive")

        self.assertEqual(tuple(aligned.shape), (4, 3, 4))
        self.assertTrue(aligned.is_contiguous())
        for batch_index in range(4):
            self.assertTrue(torch.equal(aligned[batch_index], source[0]))

    def test_matching_batch_is_preserved_and_ambiguous_mismatch_fails(self) -> None:
        matching = torch.zeros((4, 3, 4))
        self.assertIs(
            align_conditioning_batch(matching, 4, name="positive"),
            matching,
        )

        with self.assertRaisesRegex(ValueError, "only singleton conditioning"):
            align_conditioning_batch(
                torch.zeros((2, 3, 4)),
                4,
                name="positive",
            )

    def test_static_and_stepwise_conditioning_both_align(self) -> None:
        latents = torch.zeros((4, 4, 8, 8), dtype=torch.float32)
        conditioning = ConditioningOutput(
            cond=torch.ones((1, 3, 4), dtype=torch.float64),
            uncond=torch.zeros((1, 3, 4), dtype=torch.float64),
            extra={"resolver": SingletonStepResolver()},
        )

        static_cond, static_uncond = resolve_static_conditioning(
            conditioning,
            latents=latents,
        )
        step_cond, step_uncond = resolve_step_conditioning(
            conditioning,
            step_index=1,
            latents=latents,
        )

        for value in (static_cond, static_uncond, step_cond, step_uncond):
            self.assertEqual(value.shape[0], 4)
            self.assertEqual(value.dtype, latents.dtype)
            self.assertEqual(value.device, latents.device)
        self.assertEqual(float(step_cond.mean()), 2.0)

    @staticmethod
    def _pipeline(sampler_adapter, state=None):
        unet = FakeUNet()
        pipeline = CustomSDPipeline(
            components=PipelineComponents(
                unet=unet,
                vae=FakeVAE(),
                text_encoder=FakeTextEncoder(),
                tokenizer=FakeTokenizer(),
            ),
            prompt_adapter=FakePromptAdapter(),
            scheduler_adapter=FakeSchedulerAdapter(FakeScheduler()),
            sampler_adapter=sampler_adapter,
            state=state,
            latent_scale_factor=8,
            vae_scaling_factor=1.0,
            device=torch.device("cpu"),
            dtype=torch.float32,
        )
        return pipeline, unet

    @staticmethod
    def _request(sampler_name: str) -> GenerationRequest:
        request = GenerationRequest(
            positive_prompt="four batch test images",
            negative_prompt="",
            width=32,
            height=32,
            steps=3,
            cfg_scale=2.0,
            batch_size=4,
            seed=1234,
            device=torch.device("cpu"),
            dtype=torch.float32,
            scheduler_name="batch_test_scheduler",
            sampler_name=sampler_name,
        )
        if sampler_name == "kes":
            request.sampler_kwargs = {
                "sampler_type": "euler",
                "add_noise": False,
                "initial_noise_strength": 0.0,
            }
        if sampler_name == "dpmpp_2m":
            request.sampler_kwargs = {"solver_dtype": "float32"}
        return request

    def test_all_registered_sampler_paths_generate_batch_four(self) -> None:
        cases = [
            ("simple_euler", SimpleEulerSamplerAdapter(), None),
            ("dpmpp_2m", DPMPlusPlus2MSamplerAdapter(), None),
            ("kes", KESSamplerAdapter(shared_state=SharedState()), None),
        ]

        for sampler_name, adapter, state in cases:
            with self.subTest(sampler=sampler_name):
                if sampler_name == "kes":
                    state = adapter.state
                pipeline, unet = self._pipeline(adapter, state=state)
                result = pipeline.generate(self._request(sampler_name))

                self.assertEqual(tuple(result.latents.shape), (4, 4, 4, 4))
                self.assertEqual(tuple(result.images.shape), (4, 3, 32, 32))
                self.assertGreater(len(unet.calls), 0)
                for call in unet.calls:
                    self.assertEqual(call["sample_shape"][0], 4)
                    self.assertEqual(call["conditioning_shape"][0], 4)
                    self.assertEqual(call["timestep_shape"][0], 4)


if __name__ == "__main__":
    unittest.main()
